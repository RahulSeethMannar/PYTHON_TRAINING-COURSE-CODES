﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Services.Results
{
    public enum ResultType
    {
        Ok,
        Failed,
        Invalid,
        Unauthorized,
        PartialOk,
        NotFound,
        PermissionDenied,
        Unexpected
    }

    public abstract class ResultBase<T>
    {
        protected int _internalErrorId = 0;

        public abstract ResultType ResultType { get; }
        public abstract List<string> Errors { get; set; }
        public abstract T Data { get; }

        public int InternalErrorId
        {
            get
            {
                return _internalErrorId;
            }
        }
    }
}
