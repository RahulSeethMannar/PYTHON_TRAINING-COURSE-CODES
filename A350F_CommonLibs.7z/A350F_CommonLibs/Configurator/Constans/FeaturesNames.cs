﻿
namespace A350F_CommonLibs.Configurator.Constants
{
    public class FeaturesNames
    {
        public const string StructureReference = "Structure Reference";
        public const string HoleSymbols = "Hole Symbols";
        public const string FastenerSymbols = "Fastener Symbols";
        public const string Callout = "Callout";
        public const string Callouts = "Callouts";
        public const string PartNumberCallout = "Part Number Callout";
        public const string ItemNumberCallout = "Item Number Callout";
        public const string StructureReferenceCallout = "Structure Reference Callout";
        public const string StampSymbols = "Stamp Symbols";
        public const string BOM = "BOM";
        public const string BondingDetail = "Bonding View Face";
        public const string BondingSymbol = "Bonding Symbol";
        public const string BondingTable = "BondingTable";
        public const string FlagNote = "Flag Note";
        public const string GeneralNote = "General Note";
        public const string Components2D = "2D Components";
        public const string Component2D = "2D Component";
        public const string Notes = "Notes";
        public const string HoleGrouping = "Hole Grouping";
        public const string IPPoints = "IP Points";
        public const string ToolingHoles = "Tooling Holes";
        public const string LightningHolesDatum = "Lightning Holes Datum";
        public const string HNFHoles = "Hnf Holes";
        public const string Tables = "Tables";
        public const string Texts = "Texts";
        public const string Table = "Table";
        public const string Text = "Text";
        public const string DrawingText = "Drawing Text";
        public const string HtzText = "HTZ Text";
        public const string Profiles = "Profiles";
    }
}
