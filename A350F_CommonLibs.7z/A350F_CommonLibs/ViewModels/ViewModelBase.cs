﻿using System.ComponentModel;
using System.Windows.Input;

using A350F_CommonLibs.Commands;
using A350F_CommonLibs.Stores;

namespace A350F_CommonLibs.ViewModels
{
    public class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public NavigationStoreBase NavigationStore { get; set; }

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
