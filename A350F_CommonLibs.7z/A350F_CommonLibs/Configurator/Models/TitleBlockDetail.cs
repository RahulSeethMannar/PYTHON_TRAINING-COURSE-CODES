﻿
using Newtonsoft.Json;
using System;

namespace A350F_CommonLibs.Configurator.Models
{
    public class TitleBlockDetail
    {
        public string PartNumber { get; set; }
        public string SheetNumber { get; set; }
        public string SheetSize { get; set; }
        public string SheetScale { get; set; }
        public string Issue { get; set; }
        public string DO_Origin { get; set; }
        public string LimitsNotStated { get; set; }
        public string IdentificationMarkingPref { get; set; }
        public string IdentificationMarkingPrefLocation { get; set; }
        public string SurfaceFinish { get; set; }
        public string Title { get; set; }
        public string EngTitle { get; set; }
        public bool InterchangablePart { get; set; }

        #region Constructor
        public TitleBlockDetail()
        {

        }
        #endregion

        #region GetClone
        public TitleBlockDetail GetClone()
        {
            return Clone();
        }
        #endregion

        #region Clone
        public TitleBlockDetail Clone()
        {
            TitleBlockDetail clone = new TitleBlockDetail();

            try
            {
                string allLines = JsonConvert.SerializeObject(this, Formatting.Indented);
                clone = JsonConvert.DeserializeObject<TitleBlockDetail>(allLines);
            }
            catch (Exception ex) { }


            return clone;
        }
        #endregion

    }
}
