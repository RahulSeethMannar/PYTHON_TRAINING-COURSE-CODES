﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;

using A350F_CommonLibs.Services.Results;

using Dapper;

using Serilog;

namespace A350F_CommonLibs.Services.InputProviders
{
    public abstract class DatabaseInputProvider : IInputProvider
    {
        public string DbConnectionString { get; set; }

        public DatabaseInputProvider()
        {
            // Initialize dapper type mapping for annotations of mapping db columns
            // Dapper hasn't implemented it and we did it ourselves
            // Please add project DTO namespace as shown below
            //TypeMapper.Initialize("A350F_IpValidation.Dtos");

            // Defined in mainframe app.config
            //Example DB string definition - DbConnectionString = "Server=COREA350,10001;Integrated security=yes;Database=DATA";
            //Another one - DbConnectionString = "server=(localdb)\\MSSQLLocalDB;Integrated security=yes; Database=DBWITEST_001";
            DbConnectionString = ConfigurationManager.ConnectionStrings["coreallprod"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(DbConnectionString))
            {
                try
                {
                    connection.Open();
                }
                catch(Exception e)
                {
                    Log.Error($"No access to COREALL: {e.ToString()}");
                    DbConnectionString = ConfigurationManager.ConnectionStrings["localdbtest"].ConnectionString;
                }
            }
        }

        /// <summary>
        /// Query Database using dapper async query. This method also accept query parameters.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="sqlFile"></param>
        /// <param name="sqlParameters"></param>
        /// <returns></returns>
        protected async Task<ResultBase<IEnumerable<T>>> QueryDatabase<T>(Object callingClass, string sqlFile, DynamicParameters sqlParameters=null)
        {

            IEnumerable<T> resultList = default;
            //using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(sqlFile))
            //using (Stream stream = Assembly.GetAssembly(callingClass.GetType()).GetManifestResourceStream(sqlFile))
            Uri sqlUrl = new Uri($"pack://application:,,,/{Assembly.GetAssembly(callingClass.GetType()).GetName().Name};component/{sqlFile}");
            using (Stream stream = Application.GetResourceStream(sqlUrl).Stream)
            {
                if (stream is null)
                {
                    return null;
                }

                using (StreamReader reader = new StreamReader(stream))
                {
                    string sql = reader.ReadToEnd();

                    Log.Debug($"SQL for queue db: {sql}");
                    try
                    {
                        using (SqlConnection connection = new SqlConnection(DbConnectionString))
                        {
                            await connection.OpenAsync();
                            if (sqlParameters is null)
                            {
                                resultList = await connection.QueryAsync<T>(sql);
                            }
                            else
                            {
                                resultList = await connection.QueryAsync<T>(sql, sqlParameters);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Log.Error($"Exeption happens by connection to COREALLDB: {e.ToString()}");
                        ResultBase<IEnumerable<T>> result;

                        if (e.Message.ToLower().Contains("login failed"))
                        {
                            string userName = e.Message.Substring(21);
                            result = new UnauthorizedResult<IEnumerable<T>>(userName);
                        }
                        else
                        {
                            result = new UnexpectedResult<IEnumerable<T>>();
                        }

                        result.Errors.Add(e.Message);
                        result.Errors.Add(e.StackTrace);
                        result.Errors.Add(e.Source);
                        result.Errors.Add(e.ToString());
                        return result;
                    }

                }
            }

            var logResults = resultList.Take(10);
            Log.Debug($"SQL results(first 10): {string.Join(Environment.NewLine, logResults)}");

            return new SuccessResult<IEnumerable<T>>(resultList);
        }
    }
}
