﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using INFITF;
using KnowledgewareTypeLib;
using MECMOD;

namespace A350F_CommonLibs.CatiaUtils
{
    public class CatiaHnfUtils
    {

        public const string FASTENER_DIAMETER_PARAMETER_NAME = "Fastener_Diameter";
        public const string HOLE_DEPTH_PARAMETER_NAME = "Hole_Depth";
        public const string DRILLING_POINT = "Drilling_Point";
        public const string END_POINT = "End_Point";
        public const string DRILLING_AXIS = "Drilling_Axis";

        public HybridShapeInstance hsi;

        public CatiaHnfUtils(AnyObject searchSelectionItem)
        {
            // CREATE HYBRID SHAPE INSTANCE FOR HnF
            hsi = (HybridShapeInstance)searchSelectionItem;
        }

        public override string ToString()
        {
            return hsi.get_Name();
        }

        public double GetValueOfHnfParameter(string parameterName)
        {
            double value = 0.00;
            try
            {
                AnyObject anyObject = hsi.GetParameter(parameterName);
                Parameter parameter = (Parameter)anyObject;
                RealParam realParameter = (RealParam)parameter;
                value = realParameter.Value; // String, Bool, Float
            }
            catch (Exception)
            {
                //return;
            }
            return value;
        }

        public object GetOutputOfHnf(string outputName)
        {
            try
            {
                AnyObject anyObject = hsi.GetOutput(outputName);
                return anyObject;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
