﻿using A350F_CommonLibs.Configurator.Constants;
using A350F_CommonLibs.Configurator.Models;
using DRAFTINGITF;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Utils
{
    public class CommonUtils
    {
        public CommonUtils()
        {

        }

        public string GetRainbowRootFolder()
        {
            string localAppDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            return Path.Combine(localAppDataPath, "RainbowFloorGrid");
        }

        public string GetRainbowStressRootFolder(string partNum)
        {
            string rootFolder = GetRainbowRootFolder();
            return Path.Combine(rootFolder, "StressData", partNum);
        }

        #region Added For Configurator

        // Added For Configurator
        public static string MyDocumentsFolder => GetMyDocumentsFolder();

        public static string ToolLibFolder => GetToolLibsFolder();


        private static class SystemFolderNames
        {
            public static readonly string Users = "Users";
            public static readonly string Desktop = "Desktop";
            public static readonly string Documents = "Documents";
        }

        #region GetToolLibsFolder
        private static string tooLibFolder = "";
        private static string GetToolLibsFolder()
        {
            if (!String.IsNullOrEmpty(tooLibFolder)) return tooLibFolder;

            String resultName = GetHostName();
            if (resultName.ToLower().Contains(IDs.Accenture.ToLower()))
            {
                tooLibFolder = GetMyDocumentsFolder();
            }
            else
            {
                tooLibFolder = @"\\res.airbus.corp\ace_soft\FFA\IDAS\PROF\Win10\CADLIB\CATIAV5_ToolLib_R27\Business_Only\GreenHouse\Rainbow_Template\";

                // Please Update the Toollib Folder Location 
                // Use file "Paths.txt" available in A350F_CommonLibs/Resources
            }

            return tooLibFolder;
        }
        #endregion

        #region GetHostName
        public static string GetHostName()
        {
            return System.Net.Dns.GetHostEntry(System.Environment.MachineName).HostName;
        }
        #endregion

        #region GetMyDocumentsFolder

        public static string GetMyDocumentsFolder()
        {
            GetMyDocumentsFolder(out string myDocumentsFolderPath, out string desktopFolderPath);
            return myDocumentsFolderPath;
        }

        public static void GetMyDocumentsFolder(out string myDocumentsFolderPath, out string desktopFolderPath)
        {
            string userProfilePath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string userProfile_DesktopPath = System.IO.Path.Combine(userProfilePath, SystemFolderNames.Desktop);

            string userNamePath = System.IO.Path.Combine(System.IO.Path.GetPathRoot(Environment.SystemDirectory), SystemFolderNames.Users, Environment.UserName);
            string userName_DesktopPath = System.IO.Path.Combine(userNamePath, SystemFolderNames.Desktop);

            myDocumentsFolderPath = desktopFolderPath = "";
            if (System.IO.Directory.Exists(userProfile_DesktopPath) && System.IO.Directory.Exists(userName_DesktopPath))
            {
                // both Folder exists
                // Ususally this happens only when I.T creates recreates profiles or
                // during some form of troubleshooting
                desktopFolderPath = userProfile_DesktopPath;
            }
            else
            {
                if (System.IO.Directory.Exists(userName_DesktopPath))
                    desktopFolderPath = userName_DesktopPath;
                else
                {
                    //This case has to be handled
                }
            }

            if (System.IO.Directory.Exists(userProfilePath) && System.IO.Directory.Exists(userNamePath))
            {
                if (System.IO.Directory.Exists(userProfile_DesktopPath) && System.IO.Directory.Exists(userName_DesktopPath))
                {
                    //This has to be handled-
                    myDocumentsFolderPath = System.IO.Path.Combine(userNamePath, SystemFolderNames.Documents);
                }
                else if (System.IO.Directory.Exists(userProfile_DesktopPath) && !System.IO.Directory.Exists(userName_DesktopPath))
                    myDocumentsFolderPath = System.IO.Path.Combine(userProfilePath, SystemFolderNames.Documents);
                else if (!System.IO.Directory.Exists(userProfile_DesktopPath) && System.IO.Directory.Exists(userName_DesktopPath))
                    myDocumentsFolderPath = System.IO.Path.Combine(userNamePath, SystemFolderNames.Documents);
            }
            else
            {
                if (System.IO.Directory.Exists(userNamePath))
                    myDocumentsFolderPath = System.IO.Path.Combine(userNamePath, SystemFolderNames.Documents);
                else if (System.IO.Directory.Exists(userProfilePath))
                    myDocumentsFolderPath = System.IO.Path.Combine(userProfilePath, SystemFolderNames.Documents);
                else
                {
                    // This case needs to be handled.
                }
            }
        }

        #endregion GetMyDocumentsFolder

        #region SetOwnerAndShowLocation
        public static void SetOwnerAndShowLocation(System.Windows.Window window)
        {
            window.Owner = GetAppMainWindow();
            if (window.Owner != null) window.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterOwner;
        }
        #endregion

        #region GetAppMainWindow
        public static System.Windows.Window GetAppMainWindow()
        {
            System.Windows.Application currentApplication = null;
            System.Windows.Window mainWindow = null;

            try
            {
                currentApplication = System.Windows.Application.Current;
            }
            catch (Exception) { mainWindow = null; }

            try
            {
                mainWindow = currentApplication?.MainWindow;
            }
            catch (Exception) { mainWindow = null; }

            if (mainWindow is null)
            {
                try
                {
                    Process currentProcess = Process.GetCurrentProcess();
                    var hwnd = currentProcess?.MainWindowHandle;
                    var window = System.Windows.Interop.HwndSource.FromHwnd((IntPtr)hwnd);
                    dynamic customWindow = window?.RootVisual;
                    mainWindow = customWindow as System.Windows.Window;
                }
                catch (Exception) { mainWindow = null; }
            }

            return mainWindow;
        }
        #endregion

        #region ConvertViewTypeToOrientationCommand
        public string ConvertViewTypeToOrientationCommand(string viewType)
        {
            switch (viewType)
            {
                case DrawingViewNames.FrontView:
                    return "* front";
                case DrawingViewNames.RearView:
                    return "* back";
                case DrawingViewNames.LeftView:
                    return "* left";
                case DrawingViewNames.RightView:
                    return "* right";
                case DrawingViewNames.TopView:
                    return "* top";
                case DrawingViewNames.BottomView:
                    return "* bottom";
                case DrawingViewNames.IsometricView:
                    return "* iso";
                default:
                    return "";
            }
        }

        #endregion

        #region ConvertViewTypeAsString
        public string ConvertViewTypeAsString(CatDrawingViewType viewType)
        {
            switch (viewType)
            {
                case CatDrawingViewType.catViewFront:
                    return DrawingViewNames.FrontView;

                case CatDrawingViewType.catViewRear:
                    return DrawingViewNames.RearView;

                case CatDrawingViewType.catViewLeft:
                    return DrawingViewNames.LeftView;

                case CatDrawingViewType.catViewRight:
                    return DrawingViewNames.RightView;

                case CatDrawingViewType.catViewTop:
                    return DrawingViewNames.TopView;

                case CatDrawingViewType.catViewBottom:
                    return DrawingViewNames.BottomView;

                case CatDrawingViewType.catViewDetail:
                    return DrawingViewNames.DetailView;

                case CatDrawingViewType.catViewSection:
                    return DrawingViewNames.SectionView;

                case CatDrawingViewType.catViewSectionCut:
                    return DrawingViewNames.SectionCut;

                case CatDrawingViewType.catViewAuxiliary:
                    return DrawingViewNames.AuxiliaryView;

                case CatDrawingViewType.catViewBackground:
                    return DrawingViewNames.BackgroundView;

                case CatDrawingViewType.catViewMain:
                    return DrawingViewNames.MainView;

                default:
                    return DrawingViewNames.UnIdentified;
            }
        }
        #endregion

        #region GetProjectionViewType
        public CatProjViewType GetProjectionViewType(string sViewName)
        {
            CatProjViewType projectionType;

            switch (sViewName)
            {
                case DrawingViewNames.LeftView:
                    projectionType = CatProjViewType.catLeftView;
                    break;

                case DrawingViewNames.RightView:
                    projectionType = CatProjViewType.catRightView;
                    break;

                case DrawingViewNames.TopView:
                    projectionType = CatProjViewType.catTopView;
                    break;

                case DrawingViewNames.BottomView:
                    projectionType = CatProjViewType.catBottomView;
                    break;

                case DrawingViewNames.RearView:
                    projectionType = CatProjViewType.catRearView;
                    break;

                default:
                    projectionType = CatProjViewType.catRightView;
                    break;
            }

            return projectionType;
        }
        #endregion

        #region CheckAndUpdateDigitsCountInSheetNumber
        public string CheckAndUpdateDigitsCountInSheetNumber(string sheetNumber)
        {
            bool converted = Int32.TryParse(sheetNumber, out int sheetNumberConverted);

            if (converted) sheetNumber = sheetNumberConverted.ToString();

            sheetNumber = sheetNumber.Length == 1 ? "0" + sheetNumber : sheetNumber;

            return sheetNumber;
        }
        #endregion

        #region ExtractNumbersFrom
        public string ExtractNumbersFrom(string input, int numberOfDigits, bool withDecimal, string defaultValueIfEmpty = "01")
        {
            string decimalSeparator = "";

            #region Check the Decimal Character
            string currentDecimalSeparator = System.Globalization.CultureInfo.CurrentUICulture.NumberFormat.NumberDecimalSeparator;
            if (!input.Contains(currentDecimalSeparator))
                decimalSeparator = (currentDecimalSeparator == ".") ? "," : ".";
            else decimalSeparator = currentDecimalSeparator;

            if (!withDecimal && input.Contains(decimalSeparator))
                input = input.Replace(decimalSeparator, "");
            #endregion
            var inputd = (from t in input where (char.IsDigit(t) || t.ToString() == decimalSeparator) select t).ToArray();
            input = String.Join("", inputd);
            if (input.StartsWith(decimalSeparator)) input = "0" + input;
            input = withDecimal ? Regex.Match(input, @"\d+\.*\d*", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(500)).Value :
                                  Regex.Match(input, @"\d+", RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(500)).Value;
            if (input.Length < numberOfDigits) numberOfDigits = input.Length;
            input = input.Length > 2 ? input.Substring(0, numberOfDigits) : input;
            input = input.Length == 1 ? "0" + input : input;
            input = String.IsNullOrEmpty(input) ? defaultValueIfEmpty : input;

            return input;
        }
        #endregion

        #region GetDefaultTreeItem
        public  ViewItem GetDefaultTreeItem(TemplateDetails templateDetails)
        {
            ViewItem defalutView = new ViewItem(TreeIDs.TreeViewRootElementName, sheetSize: IDs.NA, itemType: TreeIDs.TreeViewRootElementType, DeleteButtonIsVisible: 1);
            for (int i = 0; i < Int32.Parse(templateDetails.ProjectDetail.SheetCount); i++)
            {
                string sheetName = $"{IDs.Sheet} " +  CheckAndUpdateDigitsCountInSheetNumber(templateDetails.ProjectDetail.SheetNumber);
                defalutView.ViewItems.Add(new ViewItem(name: sheetName,
                                                       sheetSize: templateDetails.ProjectDetail.SheetSize,
                                                       itemType: IDs.Sheet,
                                                       DeleteButtonIsVisible: 0));
            }
            return defalutView;
        }
        #endregion

        #region RenameSheets
        public void RenameSheets(ViewItem viewItem, int sheetStartIndex = 0)
        {
            for (int i = 0; i < viewItem.ViewItems.Count; i++)
            {
                ViewItem viewItemCurrent = viewItem.ViewItems[i];

                string sheetNameOld = viewItemCurrent.ItemName;
                string prefix = (viewItemCurrent.ItemType == IDs.SummarySheet) ? $"{IDs.SummarySheet} " : $"{IDs.Sheet} ";
                string sheetNameNew = prefix + CheckAndUpdateDigitsCountInSheetNumber((sheetStartIndex + i).ToString());
                sheetNameNew = (sheetNameOld.StartsWith(prefix)) ? sheetNameNew : sheetNameNew.ToUpper();

                viewItem.ViewItems[i].ItemName = sheetNameNew;
            }
        }
        #endregion

        #region RenameSheets
        public ViewItem RenameSheets(ViewItem rootItem, string newSheetNumber)
        {
            if (rootItem is null || String.IsNullOrEmpty(newSheetNumber)) return rootItem;

            newSheetNumber = CheckAndUpdateDigitsCountInSheetNumber(newSheetNumber);

            ViewItem newRootItem = rootItem;
            if (rootItem.ViewItems != null && rootItem.ViewItems.Count == 0) return rootItem;
            ViewItem firstSheetViewItem = rootItem.ViewItems?[0];
            if (firstSheetViewItem is null) return newRootItem;

            string firstSheetNumber = GetSheetNumber(firstSheetViewItem.ItemName).ToString();
            firstSheetNumber = CheckAndUpdateDigitsCountInSheetNumber(firstSheetNumber);

            if (newSheetNumber == firstSheetNumber) return newRootItem;

            int.TryParse(newSheetNumber, out int sheetStartIndex);

            RenameSheets(rootItem, sheetStartIndex);

            return newRootItem;
        }
        #endregion

        #region GetSheetNumber
        public int GetSheetNumber(string sheetOrDrawingDocumentName)
        {
            string sheetNumber = "0";
            try
            {
                string patternSheetNumber = @"\d+";
                Regex regex = new Regex(patternSheetNumber, RegexOptions.None, TimeSpan.FromSeconds(500));
                Match match = regex.Match(sheetOrDrawingDocumentName);
                sheetNumber = match.Success ? match.Value : "0";
                if (!String.IsNullOrEmpty(sheetNumber) && sheetNumber.Length == 1) sheetNumber = "0" + sheetNumber;
            }
            catch (Exception ex) { }

            return Int32.Parse(sheetNumber);
        }
        #endregion

        #region RemoveEmptyEntriesFromList
        public void RemoveEmptyEntriesFromList(ref List<string> list)
        {
            for (int rowNumber = list.Count - 1; rowNumber >= 0; rowNumber--)
            {
                string rowLine = list[rowNumber];
                if (String.IsNullOrEmpty(rowLine))
                    list.RemoveAt(rowNumber);
            }
        }
        #endregion

        #region BringCatiaToFront
        public static void BringCatiaToFront()
        {
            IntPtr handle;
            System.Diagnostics.Process[] catiaProcesses = System.Diagnostics.Process.GetProcessesByName("CNEXT");
            catiaProcesses = catiaProcesses?.OrderBy(catiaProcess => catiaProcess.StartTime).ToArray();
            if (catiaProcesses.Length > 0)
            {
                handle = catiaProcesses[0].MainWindowHandle;
                CommonUtils.BringToFront(handle);
            }
        }
        #endregion

        #region BringMainWindowToFront
        public static void BringMainWindowToFront(bool useProcess = false)
        {
            IntPtr mainWindowHandle = IntPtr.Zero;
            if (!useProcess)
            {
                System.Windows.Window mainWindow = GetAppMainWindow();
                if (mainWindow is null) return;
                try
                {
                    mainWindowHandle = new System.Windows.Interop.WindowInteropHelper(mainWindow).Handle;
                }
                catch (Exception ex) { Console.WriteLine(ex.ToString()); return; }
            }
            else if (useProcess)
            {
                Process currentProcess = Process.GetCurrentProcess();
                mainWindowHandle = currentProcess is null ? IntPtr.Zero : currentProcess.MainWindowHandle;
            }
            if (mainWindowHandle != IntPtr.Zero) CommonUtils.BringToFront(mainWindowHandle);
        }
        #endregion

        #region BringToFront
        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(IntPtr handle);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        [return: System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.Bool)]
        static extern bool IsIconic(IntPtr hWnd);

        public static void BringToFront(IntPtr hWnd)
        {
            const int SW_RESTORE = 9;
            if (hWnd == IntPtr.Zero) return;
            SetForegroundWindow(hWnd);
            if (IsIconic(hWnd))
                ShowWindow(hWnd, SW_RESTORE);
        }
        #endregion

        #endregion
    }
}
