﻿using System.Collections.Generic;
using System.Threading.Tasks;

using A350F_CommonLibs.Services.Results;

namespace A350F_CommonLibs.Services.InputProviders
{
    public interface IInputProvider
    {
    }
}
