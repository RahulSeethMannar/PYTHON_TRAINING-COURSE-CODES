﻿namespace A350F_CommonLibs.Configurator.Constants
{
    public static class DrawingViewNames
    {
        public const string AuxiliaryView = "Auxiliary View";
        public const string BackgroundView = "BackgroundView";
        public const string BottomView = "Bottom View";
        public const string DetailView = "Detail View";
        public const string DetailViewCircular = "Detail View Circular";
        public const string FrontView = "Front View";
        public const string IsometricView = "Isometric View";
        public const string MainView = "Main View";
        public const string RearView = "Rear View";
        public const string LeftView = "Left View";
        public const string RightView = "Right View";
        public const string SectionView = "Section View";
        public const string SectionCut = "Section Cut";
        public const string TopView = "Top View";
        public const string UnIdentified = "UnIdentified";
    }
}
