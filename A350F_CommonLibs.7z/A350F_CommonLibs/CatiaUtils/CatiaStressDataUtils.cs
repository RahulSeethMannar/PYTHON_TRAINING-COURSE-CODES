﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using A350F_CommonLibs.Stores;
using A350F_CommonLibs.Utils;

using INFITF;

using MECMOD;

using ProductStructureTypeLib;

using Serilog;

namespace A350F_CommonLibs.CatiaUtils
{
    public class CatiaStressDataUtils
    {
        public static string Extract3DStressDataToStpFile(string ipPartNumber, NotificationStoreBase notificationStore)
        {
            Log.Information($"StressDataPreparation: start preparing stress data for IP ({ipPartNumber})");

            if (!CatiaCommonUtils.CanGetActiveRootProd() || !CatiaCommonUtils.CanGetActiveDoc())
            {
                return "";
            }

            Document activeDocument = CatiaCommonUtils.GetActiveDoc();
            Selection selection = activeDocument.Selection;
            selection.Clear();

            // Ask user to select the product to convert to stp file format
            string info = "Please select parts for stress data and then click \"Finish\" on Tools Palette";
            notificationStore.FooterInfo = info;
            object[] filters = new object[1] { "Product" };
            string status = activeDocument.Selection.SelectElement3(filters, info, true,
                CATMultiSelectionMode.CATMultiSelTriggWhenUserValidatesSelection, true);

            if (status == "Cancel" || selection.Count2 == 0)
            {
                notificationStore.FooterInfo = "Cancelled by User";
                return "";
            }
            notificationStore.FooterInfo = "Processing extraction of stress data";

            List<Product> productsToExport = new List<Product>();
            for (int i = 1; i <= selection.Count2; i++)
            {
                Product singleProd = (Product)selection.Item(i).Value;
                productsToExport.Add(singleProd);
            }

            string activeDocName = CatiaCommonUtils.GetNameActiveDoc();
            string prodPartNumber = Path.GetFileNameWithoutExtension(activeDocName);
            string dateString = DateTime.Now.ToString("yyyyMMddhhmmss");
            prodPartNumber = $"{prodPartNumber}-{dateString}";

            // create stress data without clean up
            string rootPath = ExportStressDataProductStructure(ipPartNumber, productsToExport, prodPartNumber, dateString, false);

            // create stress data with clean up
            prodPartNumber = $"{prodPartNumber}_Simplified_Data-{dateString}";
            rootPath = ExportStressDataProductStructure(ipPartNumber, productsToExport, prodPartNumber, dateString, true);

            notificationStore.FooterInfo = "Extraction Completed";
            return rootPath;
        }

        private static string ExportStressDataProductStructure(string ipPartNumber, List<Product> productsToExport,
                                string prodPartNumber, string dateString, bool isCleanUpData)
        {
            // Add temp product and open in new window
            ProductDocument newDoc = CatiaProdUtils.AddNewProduct(prodPartNumber, true);
            Selection selection = newDoc.Selection;
            selection.Clear();

            foreach (Product prod in productsToExport)
            {
                prod.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                string partNumber = prod.get_PartNumber();
                selection.Add(prod);
                selection.Copy();
                selection.Clear();
                selection.Add(newDoc.Product);
                selection.PasteSpecial("CATSpecBreakLink");
                Product tempProd = (Product)selection.Item(1).Value;
                //// Rename the original product to avoid part number conflict, they will be changed back
                //prod.set_PartNumber("orig" + partNumber);
                //tempProd.set_PartNumber(partNumber);
                if (isCleanUpData)
                {
                    StressDataCleanUp(tempProd);
                }
                selection.Clear();
                newDoc.Product.Update();
                Log.Information($"StressDataPreparation: copied {partNumber} to new product structure");
            }

            // save stress data created
            string rootFolder = SaveProductAsStp(newDoc, ipPartNumber, isCleanUpData);

            // Try to close the window for the new root product with timestamp
            newDoc.Close();

            //// After closing the export product, we can rename back the part number for original ones
            //foreach (Product prod in productsToExport)
            //{
            //    string partNumber = prod.get_PartNumber();
            //    prod.set_PartNumber(partNumber.Substring(4));
            //}

            return rootFolder;
        }

        public static string SaveProductAsStp(ProductDocument prdDoc, string ipPartNumber, bool isCleanUpData)
        {
            Application catiaInst = CatiaCommonUtils.GetCatia();
            CommonUtils commUtils = new CommonUtils();

            //Create folder
            string rootPath = commUtils.GetRainbowStressRootFolder(ipPartNumber);
            string pathFolder = rootPath;
            if (isCleanUpData)
            {
                pathFolder = Path.Combine(pathFolder, "SimplifiedData");
            }

            Directory.CreateDirectory(pathFolder);

            // Find all possible step files under the folder if this folder already exists and delete them
            foreach (string file in Directory.EnumerateFiles(pathFolder, "*.stp", SearchOption.AllDirectories))
            {
                try
                {
                    System.IO.File.Delete(file);
                }
                catch (Exception e)
                {
                    Log.Warning($"File deletion failed with path {file}. Exeception - {e.ToString()}");
                }

            }

            //Save the product as STP       
            var outputFile = pathFolder + "\\" + prdDoc.Product.get_PartNumber() + ".stp";
            catiaInst.DisplayFileAlerts = false;
            prdDoc.ExportData(outputFile, "stp");
            catiaInst.DisplayFileAlerts = true;

            Log.Information($"StressDataPreparation: Stress Product saved to {outputFile})");
            return rootPath;
        }

        public static void StressDataCleanUp(Product productToClean)
        {
            ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();

            Selection selection = rootDoc.Selection;

            try
            {
                PartDocument partDoc = null;
                CatiaCommonUtils.GetPartDocumentFromProduct(productToClean, ref partDoc);

                selection.Clear();
                selection.Add(productToClean);
                selection.Search("Name=*EDGE*FILLET*,all");

                if (selection.Count > 0)
                {
                    Log.Information($"StressDataPreparation: Stress - Clean Up --> Total number of egde fillets found: { selection.Count})");
                    
                    if (partDoc != null)
                    {
                        for(int i=1; i<selection.Count; i++)
                        {
                            partDoc.Part.Inactivate((AnyObject)selection.Item2(i).Value);
                        }
                    }
                    //selection.Delete();
                    Log.Information($"StressDataPreparation: Stress - Clean Up --> Clean up process completed successfully: { selection.get_Name()})");
                }
                else
                {
                    Log.Information($"StressDataPreparation: Stress - Clean Up --> No edge fillets found to clean up.");
                }

                productToClean.Update();
            }
            catch (Exception)
            {
                Log.Information($"StressDataPreparation: Stress - Clean Up --> Clean up process failed...!");
            }
        }
    }
}
