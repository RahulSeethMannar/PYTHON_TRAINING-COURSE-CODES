﻿using A350F_CommonLibs.Configurator.Constants;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace A350F_CommonLibs.Configurator
{
    public class UI_Inputs
    {
        public const string Title = "2D Configurator";
        public const string JsonFileVersion = "v3.1.1.1";

        public const double FontSize = 16;
        public const double FontSizeButton = 20;

        public const string DefaultScale_FrontView = "1:3.5";
        public const string DefaultScale_IsoView = "1:12";
        public const string DefaultScale_Sheet = "1:2";
        public const string DefaultScaleSheet_1to1 = "1:1";
        public const string DefaultScaleSheet_1to2 = "1:2";
        public const string DefaultSheetSize = "1.5A0";

        public const double TitleblockWidth = 210;
        public const double TitleblockHeight = 142.75;


        public const string CatiaApiErrorMessage = "CATIA API error.\n\n" +
                                             "Please do the following steps and check.\n" +
                                             "\t 1. Clear %TEMP%\n" +
                                             "\t 2. Clear Catia Cache\n" +
                                             "\t 3. Restart, CATIA and recheck\n" +
                                             "\t 4. System and recheck.";

        #region Sections
        public static ObservableCollection<string> Sections = new ObservableCollection<string>()
        {
            "XWB-S1112",
            "XWB-S1314",
            "XWB-S15",
            "XWB-S151",
            "XWB-S1519",
            "XWB-S1617",
            "XWB-S1618",
            "XWB-S19",
            "XWB-S191",
            "XWB-S19191",
            "XWB-S1617",
            "XWB-S18",
            "XWB-S1819",
            "XWB-S19-1",
            "SA-S1114",
            "SA-S1314",
            "SA-S14A",
            "SA-15",
            "SA-1519",
            "SA-1617",
            "SA-16A",
            "SA-17",
            "SA-18",
            "SA-1819",
            "SA-19"
        };
        #endregion

        #region DRWTypes
        public static List<string> DRWTypes = new List<string>()
        {
            DrawingTypes.SinglePart,
            DrawingTypes.Assembly,
            DrawingTypes.DesignSolution,
            DrawingTypes.Installation,
            DrawingTypes.UnIdentified
        };
        #endregion

        #region DRWTypeAbbr
        public static Dictionary<string, string> DRWTypeAbbr = new Dictionary<string, string>()
        {
            { DrawingTypes.SinglePart, DrawingTypesAbbreviation.SinglePart},
            { DrawingTypes.Assembly, DrawingTypesAbbreviation.Assembly},
            { DrawingTypes.DesignSolution, DrawingTypesAbbreviation.DesignSolution},
            { DrawingTypes.Installation, DrawingTypesAbbreviation.Installation}
        };
        #endregion

        #region PartFamilies
        public static ObservableCollection<string> PartFamilies = new ObservableCollection<string>()
        {
            PartFamilyNames.Crossbeam,
            PartFamilyNames.SingleCargoRail,
            PartFamilyNames.DoubleCargoRail,

            PartFamilyNames.RollerTracks,

            PartFamilyNames.InnerShearPlate,
            PartFamilyNames.OuterShearPlate,

            PartFamilyNames.PduAssembly,

            PartFamilyNames.Seatrail,

            //PartFamilyNames.ShearWeb,
            //PartFamilyNames.X_Paddles,
            //PartFamilyNames.X_Frame,

            PartFamilyNames.Z_Struts,

            //PartFamilyNames.UnIdentified,
        };
        #endregion

        #region PrimaryViews
        public static ObservableCollection<string> PrimaryViews = new ObservableCollection<string>()
        {
            DrawingViewNames.BackgroundView,
            DrawingViewNames.IsometricView,
            DrawingViewNames.FrontView,
            DrawingViewNames.RearView,
            DrawingViewNames.TopView,
            DrawingViewNames.BottomView,
            DrawingViewNames.RightView,
            DrawingViewNames.LeftView
        };
        #endregion

        #region SecondaryViews
        public static ObservableCollection<string> SecondaryViews = new ObservableCollection<string>()
        {
            DrawingViewNames.DetailView,
            DrawingViewNames.DetailViewCircular,
            DrawingViewNames.SectionView,
            DrawingViewNames.SectionCut,
            DrawingViewNames.AuxiliaryView
        };
        #endregion

        #region Features
        public static ObservableCollection<string> Features = new ObservableCollection<string>()
        {
            FeaturesNames.BOM,
            FeaturesNames.BondingSymbol,
            FeaturesNames.BondingDetail,
            FeaturesNames.BondingTable,
            FeaturesNames.Components2D,
            //FeaturesNames.Callouts,
            FeaturesNames.PartNumberCallout,
            //FeaturesNames.ItemNumberCallout,
            //FeaturesNames.StructureReferenceCallout,
            FeaturesNames.FastenerSymbols,
            FeaturesNames.HoleGrouping,
            FeaturesNames.HoleSymbols,
            FeaturesNames.IPPoints,
            FeaturesNames.LightningHolesDatum,
            FeaturesNames.Notes,
            FeaturesNames.StampSymbols,
            FeaturesNames.StructureReference,
            FeaturesNames.Tables,
            FeaturesNames.Texts,
            FeaturesNames.ToolingHoles,
        };
        #endregion
    }
}
