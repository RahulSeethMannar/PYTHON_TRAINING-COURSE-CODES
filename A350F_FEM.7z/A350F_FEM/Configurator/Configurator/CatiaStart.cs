﻿using INFITF;
using MECMOD;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Application = INFITF.Application;

namespace Configurator.Views
{
    public class CatiaStart

    {

        // Define global variables

        internal static Application CATIA = null;

        public static ProductDocument activeProdDoc = null;

        public static PartDocument activePartDoc = null;

        public static Workbench activeWorkbench = null;

        public static String activeWorkbenchName = null;

        internal static String ObjectTreeString;

        //Object constructor

        public CatiaStart(bool verb = false)

        {

            if (SetCatia())

            {

                if (SetActiveDoc())

                {

                    if (SetWorkbench())

                    {

                        //if (SetTreeObjects())

                        //{

                        //    Console.WriteLine("Catia successfully started.");

                        //}

                        //else if (verb)

                        //{

                        //    Console.WriteLine("EXC: Tree objects could not be detected.");

                        //}

                    }

                    else if (verb)

                    {

                        Console.WriteLine("EXC: No usable workbench present.");

                    }

                }

                else if (verb)

                {

                    Console.WriteLine("EXC: No usable active document type present.");

                }

            }

            else if (verb)

            {

                Console.WriteLine("EXC: No CATIA session is open.");

            }

        }
        bool SetCatia()

        {

            try

            {

                CATIA = (Application)Marshal.GetActiveObject("CATIA.Application");

                return true;

            }

            catch

            {

                return false;

            }

        }
        public bool SetActiveDoc()

        {

            try

            {

                activePartDoc = CATIA.ActiveDocument is PartDocument ? (PartDocument)CATIA.ActiveDocument : null;

                activeProdDoc = CATIA.ActiveDocument is ProductDocument ? (ProductDocument)CATIA.ActiveDocument : null;

                return true;

            }

            catch

            {

                return false;

            }

        }
        bool SetWorkbench()

        {

            //try

            //{

            //activeWorkbench = CATIA.ActiveDocument.GetWorkbench(activeWorkbenchName);

            //spaWorkbench = activeWorkbench is SPAWorkbench ? (SPAWorkbench)activeWorkbench : null;

            //spaWorkbench = CATIA.ActiveDocument.GetWorkbench("SPAWorkbench") as SPAWorkbench;



            return true;

            //}

            //catch

            //{

            //    return false;

            //}

        }
        bool SetTreeObjects()

        {

            try

            {

                ObjectTreeString = " , ";

                for (int i = 1; i <= activePartDoc.Part.Bodies.Count; i++)

                {

                    ObjectTreeString += " , " + activePartDoc.Part.Bodies.Item(i).get_Name();

                    try

                    {

                        for (int j = 1; j <= activePartDoc.Part.Bodies.Item(i).HybridBodies.Count; j++)

                        {

                            ObjectTreeString += " , " + activePartDoc.Part.Bodies.Item(i).HybridBodies.Item(j).get_Name();



                            try

                            {

                                for (int k = 1; k <= activePartDoc.Part.Bodies.Item(i).HybridBodies.Item(j).HybridShapes.Count; k++)

                                {

                                    ObjectTreeString += " , " + activePartDoc.Part.Bodies.Item(i).HybridBodies.Item(j).HybridShapes.Item(k).get_Name();

                                }

                            }

                            catch

                            {

                            }

                        }

                    }

                    catch

                    { }

                    try

                    {

                        for (int j = 1; j <= activePartDoc.Part.Bodies.Item(i).HybridShapes.Count; j++)

                        {

                            ObjectTreeString += " , " + activePartDoc.Part.Bodies.Item(i).HybridShapes.Item(j).get_Name();

                        }

                    }

                    catch

                    {

                    }

                }

                for (int i = 1; i <= activePartDoc.Part.HybridBodies.Count; i++)

                {

                    ObjectTreeString += " , " + activePartDoc.Part.HybridBodies.Item(i).get_Name();

                    try

                    {

                        for (int j = 1; j <= activePartDoc.Part.HybridBodies.Item(i).HybridShapes.Count; j++)

                        {

                            ObjectTreeString += " , " + activePartDoc.Part.HybridBodies.Item(i).HybridShapes.Item(j).get_Name();

                        }

                    }

                    catch

                    { }

                    try

                    {

                        for (int j = 1; j <= activePartDoc.Part.HybridBodies.Item(i).HybridBodies.Count; j++)

                        {

                            ObjectTreeString += " , " + activePartDoc.Part.HybridBodies.Item(i).HybridBodies.Item(j).get_Name();

                            try

                            {

                                for (int k = 1; k <= activePartDoc.Part.HybridBodies.Item(i).HybridBodies.Item(j).HybridShapes.Count; k++)

                                {

                                    ObjectTreeString += " , " + activePartDoc.Part.HybridBodies.Item(i).HybridBodies.Item(j).HybridShapes.Item(k).get_Name();

                                }

                            }

                            catch

                            { }

                        }

                    }

                    catch

                    { }

                }

                return true;

            }

            catch

            {

                return false;

            }

        }

        public PartDocument OpenPartDoc(string filepath = null)

        // Opens a part document.

        // If no file path is given, opens new part document.

        // TODO: SHOULD CHECK IF FILE ENDS WITH .CATPART.

        {

            if (filepath == null)

            {

                CATIA.Documents.Add("Part");

            }

            else

            {

                // opens catpart document           

                CATIA.Documents.Open(filepath);

            }



            // Get Active Part Doc and update local var

            SetActiveDoc();

            SetWorkbench();



            return activePartDoc;

        }

        public ProductDocument OpenProductDoc(string filepath = null)

        // Opens a Product document.

        // If no file path is given, opens new Product document.

        // TODO: SHOULD CHECK IF FILE ENDS WITH .CATProd.

        {

            if (filepath == null)

            {

                CATIA.Documents.Add("Product");

            }

            else

            {

                // opens catpart document           

                CATIA.Documents.Open(filepath);

            }



            // Get Active Product Doc and update local var

            SetActiveDoc();

            SetWorkbench();



            return activeProdDoc;

        }

    }
}
