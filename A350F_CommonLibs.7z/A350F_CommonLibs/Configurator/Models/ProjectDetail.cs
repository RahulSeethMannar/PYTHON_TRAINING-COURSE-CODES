﻿namespace A350F_CommonLibs.Configurator.Models
{
    public class ProjectDetail
    {
        public string Program { get; set; }
        public string Section { get; set; }
        public string ATAChapter { get; set; }
        public string DRWType { get; set; }
        public string PartFamily { get; set; }
        public string SheetNumber { get; set; }
        public string SheetSize { get; set; }
        public string SheetCount { get; set; }
        public bool IsOppoPartSelected { get; set; }

        public ProjectDetail Clone()
        {
            ProjectDetail projectDetail = new ProjectDetail();
            projectDetail.Program = this.Program;
            projectDetail.Section = this.Section;
            projectDetail.ATAChapter = this.ATAChapter;
            projectDetail.DRWType = this.DRWType;
            projectDetail.PartFamily = this.PartFamily;
            projectDetail.SheetNumber = this.SheetNumber;
            projectDetail.SheetSize = this.SheetSize;
            projectDetail.SheetCount = this.SheetCount;
            projectDetail.IsOppoPartSelected = this.IsOppoPartSelected;
            return projectDetail;
        }
    }
}
