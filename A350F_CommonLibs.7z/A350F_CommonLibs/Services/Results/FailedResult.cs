﻿using System.Collections.Generic;

namespace A350F_CommonLibs.Services.Results
{
    public class FailedResult<T> : ResultBase<T>
    {
        private readonly T _data;

        private List<string> _errors;

        public FailedResult(T data)
        {
            _internalErrorId = 0;
            _data = data;
            _errors = new List<string> { "Process get failed result" };
        }

        public override ResultType ResultType => ResultType.Failed;

        public override List<string> Errors
        {
            get
            {
                return _errors;
            }
            set
            {
                _errors = value;
            }
        }

        public override T Data => _data;
    }
}
