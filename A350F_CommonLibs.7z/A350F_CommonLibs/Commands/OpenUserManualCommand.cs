﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using Microsoft.SqlServer.Server;

namespace A350F_CommonLibs.Commands
{
    public class OpenUserManualCommand : CommandBase
    {
        public OpenUserManualCommand() { }

        public override void Execute(object parameter)
        {
            try
            {
                Dictionary<string, string> urlDict = new Dictionary<string, string>();

                var serverName = System.Environment.MachineName;
                String resultName = System.Net.Dns.GetHostEntry(serverName).HostName;

                resultName = resultName.ToLower();
                string resourceFile = "Resources/usermanualurl_local.txt";
                if (resultName.Contains("accenture"))
                {
                    resourceFile = "Resources/usermanualurl_2.txt";
                }

                Uri resourceUrl = new Uri($"pack://application:,,,/{Assembly.GetAssembly(this.GetType()).GetName().Name};component/{resourceFile}");
                using (Stream stream = Application.GetResourceStream(resourceUrl).Stream)
                //    string urlFile = "A350F_CommonLibs.Resources.usermanualurl.txt";
                //using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(urlFile))
                {
                    using (var reader = new StreamReader(stream))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            if (line.Trim().StartsWith("#"))
                            {
                                continue;
                            }
                            urlDict.Add(line.Split('=')[0], string.Join("=", line.Split('=').Skip(1).ToArray()));
                        }
                    }
                }

                if (parameter is string && (parameter as string).Length > 0) 
                {
                    string url = urlDict[parameter as string];
                    if (String.IsNullOrWhiteSpace(url) ||
                        !(url.ToLower().StartsWith("http") || url.ToLower().StartsWith("resources\\"))) 
                    { 
                        return;
                    }

                    if (url.ToLower().StartsWith("resources\\"))
                    {
                        string strExeFilePath = Assembly.GetExecutingAssembly().Location;
                        string strWorkPath = Path.GetDirectoryName(strExeFilePath);
                        url = Path.Combine(strWorkPath, url);
                    }

                    Process.Start(url);
                }
            }
            catch 
            {
 
            }
        }
        public override bool CanExecute(object parameter)
        {
            return base.CanExecute(parameter);
        }
    }
}
