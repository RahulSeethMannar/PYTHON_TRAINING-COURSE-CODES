﻿using System;

namespace A350F_CommonLibs.Configurator.Models
{
    public class NoteComponent : IEquatable<NoteComponent>
    {
        public string Name { get; set; }
        public double ScaleRatio { get; set; }
        public string Scale  { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public bool Visible { get; set; }
        public bool AddedAsNew { get; set; } = false;

        #region Constructor

        public NoteComponent()
        {
        }
        public NoteComponent(string name, double scale)
        {
            Initialize(name, scale, 0, 0);
        }
        public NoteComponent(string name, double scale, double x, double y, bool visible = true)
        {
            Initialize(name, scale, x, y, visible);
        }

        #endregion

        #region Initialize
        private void Initialize(string name, double scale, double x, double y, bool visible = true)
        {
            this.Name = name;
            this.ScaleRatio = scale;
            this.X = x;
            this.Y = y;
            this.Visible = visible;
        }
        #endregion

        #region IsSameAs
        public bool IsSameAs(object obj)
        {
            try
            {
                if (obj is NoteComponent)
                {
                    NoteComponent noteComponent = obj as NoteComponent;
                    return noteComponent.GetHashCode() == this.GetHashCode();
                }
                else return false;
            }
            catch (Exception ex)
            {

                return false;
            }
        }
        #endregion

        #region Equals
        public bool Equals(NoteComponent other)
        {
            return this.IsSameAs(other);
        }
        #endregion

        #region override Equal && operators

        #region Equals
        public override bool Equals(object other)
        {
            return this.IsSameAs(other);
        }
        #endregion

        #region ==
        /// <summary>
        /// Compare two instances of this class for inequality.
        /// </summary>
        public static bool operator ==(NoteComponent a, NoteComponent b)
        {
            return a.Equals(b);
        }
        #endregion

        #region !=
        /// <summary>
        /// Compare two instances of this class for inequality.
        /// </summary>
        public static bool operator != (NoteComponent a, NoteComponent b)
        {
            return !(a == b);
        }
        #endregion

        #region GetHashCode
        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Scale, ScaleRatio, X, Y, Visible);
        }
        #endregion

        #region ToString
        // override object.Equals
        public override string ToString()
        {
            return Name;
        }
        #endregion

        #endregion

    }

}
