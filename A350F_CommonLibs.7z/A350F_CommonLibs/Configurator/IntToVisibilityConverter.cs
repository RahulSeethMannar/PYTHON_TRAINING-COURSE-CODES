﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace A350F_CommonLibs.Configurator
{
    public class IntToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return (value is int integer && integer == 1) ? Visibility.Hidden : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
}
