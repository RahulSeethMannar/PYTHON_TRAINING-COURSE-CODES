﻿
using System.Windows;

namespace A350F_CommonLibs.Dialogs
{
    public interface IDialog
    {
        MessageBoxResult ShowInfoMessageBox(string message);
        MessageBoxResult ShowInfoMessageBoxYesNo(string message);
        MessageBoxResult ShowErrorMessageBox(string message);
    }
}
