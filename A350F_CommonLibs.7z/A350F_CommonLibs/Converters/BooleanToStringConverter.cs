﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace A350F_CommonLibs.Converters
{ 
    public class BooleanToStringConverter : BooleanToValueConverter<string> { }

}
