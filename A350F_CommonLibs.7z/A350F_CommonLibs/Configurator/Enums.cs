﻿
namespace A350F_CommonLibs.Configurator
{
    public enum eDrawingTypes
    {
        UnIdentified = 0,
        NotDefined = 0,
        SinglePart = 1,
        Assembly = 2,
        DesignSolution = 3,
        Installation = 4
    }

    public enum eViewDirection
    {
        NA = -1,
        Clockwise = 0,
        AntiClockwise = 1
    }
    public enum eAngleOfProjection
    {
        None = -1,
        First = 0,
        Third = 1
    }
    public enum eIdentificationMarkingPrefLocation
    {
        Empty,
        Top,
        Bottom,
        Left,
        Right
    }

    public enum eGenWireFrameMod
    {
        Default = 1,
        Hidden = 1,
        Visible = 2
    }

    public enum eGenApplyUncut_3DSpec
    {
        Default = 1,
        Shown,
        Hidden
    }
    public enum eDrwGenerationModeVal
    {
        Exact = 0, // View is generated from topological data 
        CGR = 1,
        Raster = 2,
        Approximate =3
    }
}
