﻿
namespace A350F_CommonLibs.Configurator.Models
{
    public class FeaturesToCreate
    {
        public bool CreateBOM { get; set; }
        public bool Create2DComponents { get; set; }
        public bool CreateBondingSymbol { get; set; }
        public bool CreateBondingDetail { get; set; }
        public bool CreateBondingTable { get; set; }
        public bool CreateCallOuts { get; set; }
        public bool CreateFastenerSymbols { get; set; }
        public bool CreateHNFHoles { get; set; }
        public bool CreateHoleGrouping { get; set; }
        public bool CreateHoleSymbols { get; set; }
        public bool CreateIPPoints { get; set; }
        public bool CreateLightningHolesDatum { get; set; }
        public bool CreateNotes { get; set; }
        public bool CreateStampSymbols { get; set; }
        public bool CreateStructureReferences { get; set; }
        public bool CreateToolingHoles { get; set; }
        public bool CreateTables { get; set; }
        public bool CreateTexts { get; set; }
        public bool CreateProfiles { get; set; }
        public bool CreatePartNumberCallout { get; set; }
    }
}
