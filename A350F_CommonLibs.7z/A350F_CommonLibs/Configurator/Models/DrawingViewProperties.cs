﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Configurator.Models
{
    public class DrawingViewProperties
    {
        public bool ShowHiddenLines { get; set; } = false;
        public bool ShowCenterLines { get; set; } = false;
        public bool Show3DSpec { get; set; } = false;
        public bool Show3DColors { get; set; } = false;
        public bool ShowAxisLines { get; set; } = false;
        public bool ShowThread { get; set; } = false;
        public bool ShowFillets { get; set; } = false;
        public bool Show3DPoints { get; set; } = false;
        public bool Show3DWireframe { get; set; } = false;
    }
}
