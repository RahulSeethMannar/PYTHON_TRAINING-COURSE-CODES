﻿using System.Collections.Generic;

namespace A350F_CommonLibs.Configurator.Models
{
    public class TreeviewDetail
    {
        public string Name { get; set; }
        public List<ViewItem> Views { get; set; }

        public TreeviewDetail()
        { }

        public TreeviewDetail(ViewItem viewItem)
        {
            this.Name = viewItem.ItemName;
            this.Views = new List<ViewItem>();
            foreach (ViewItem vi in viewItem.ViewItems)
            {
                this.Views.Add(vi);
            }
        }
    }
}
