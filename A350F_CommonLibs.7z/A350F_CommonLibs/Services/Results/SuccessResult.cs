﻿using System.Collections.Generic;

namespace A350F_CommonLibs.Services.Results
{
    public class SuccessResult<T> : ResultBase<T>
    {
        private readonly T _data;

        public SuccessResult(T data)
        {
            _data = data;
        }
        public override ResultType ResultType => ResultType.Ok;

        public override List<string> Errors { get => new List<string>(); set => _ = value; }

        public override T Data => _data;
    }
}
