﻿using System.Collections.Generic;

namespace A350F_CommonLibs.Services.Results
{
    public class UnauthorizedResult<T> : ResultBase<T>
    {
        private List<string> _errors;
        private readonly string _userName = default;

        public UnauthorizedResult(string userName)
        {
            _userName = userName;
            _errors = new List<string> { $"User {_userName} is not authorized." };
        }

        public override ResultType ResultType => ResultType.Unauthorized;

        public override List<string> Errors
        {
            get
            {
                return _errors;
            }
            set
            {
                _errors = value;
            }
        }

        public string UserName => _userName;

        public override T Data => default;
    }
}
