﻿using DRAFTINGITF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Configurator.Models
{
    public class Text
    {
        public string Name { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public string Content { get; set; }
        public CatTextAnchorPosition AnchorPosition { get; set; }
        public CatTextFrameType FrameType { get; set; }
        public double FontSize { get; set; }
        public string FontName { get; set; }
        public bool Visible { get; set; }

        public Text(DrawingText dwgText)
        {
            if (dwgText is null) return;
            Name = dwgText.get_Name();
            X = dwgText.x;
            Y = dwgText.y;
            Content = dwgText.get_Text();
            AnchorPosition = dwgText.AnchorPosition;
            FrameType = dwgText.FrameType;
            GetFontDetails(dwgText);
        }

        private void GetFontDetails(DrawingText dwgText)
        {
            try
            {
                FontSize = dwgText.GetFontSize(1, Content.Length);
                FontName = dwgText.GetFontName(1, Content.Length);
            }
            catch (Exception ex) { }
            FontName = FontName is null ? "" : FontName;
        }


    }
}
