﻿using A350F_CommonLibs.Configurator.Constants;
using DRAFTINGITF;
using MECMOD;
using Newtonsoft.Json;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace A350F_CommonLibs.Configurator.Models
{
    public class ViewItem
    {
        public string ItemName { get; set; }
        public string ItemNameLine2 { get; set; }
        public string ItemType { get; set; }
        public int IsVisible { get; set; }
        public int IsDeleteButtonVisible { get; set; }
        public int IsSheetSizeControlVisible => CanSheetSizeControlVisible();
        public string SheetSize { get; set; }
        public bool SheetSizeChangedByUser { get; set; } = false;
        public string SheetScale { get; set; }
        public bool SheetScaleChangedByUser { get; set; } = false;

        public int ProjectionMethod { get; set; }
        public int PaperSize { get; set; }
        public int Orientation { get; set; }
        public double Angle { get; set; } = 0;
        public double Scale { get; set; } = 1;

        public double X { get; set; } = 0;
        public double Y { get; set; } = 0;
        public double XAxisData { get; set; } = 0;
        public double YAxisData { get; set; } = 0;
        public double[] Position => GetPositionAsArray();
        public double[] PositionAxisData => GetPositionAsArray(getAxisData: true);
        public int ViewType { get; set; } = 0;
        public string ViewShape { get; set; } = IDs.NA;
        public string ViewScale { get; set; } = String.Empty;
        public bool ViewScaleChangedByUser { get; set; } = false;
        public eViewDirection ViewDirection { get; set; } = eViewDirection.Clockwise;
        public bool ViewIsVisible { get; set; } = true;
        public bool ViewPlaceInOccupiedSpace { get; set; } = false;
        public bool IsAlignedWithReferenceView { get; set; } = false;

        public bool AddHtzText { get; set; } = false;

        public DrawingViewProperties ViewProperties => GetViewProperties();
        public bool ShowHiddenLines { get; set; } = false;
        public bool ShowCenterLines { get; set; } = false;
        public bool Show3DSpec { get; set; } = false;
        public bool Show3DColors { get; set; } = false;
        public bool Show3DPoints { get; set; } = false;
        public bool Show3DWireframe { get; set; } = false;
        public bool ShowFillets { get; set; } = false;
        public bool ShowAxis { get; set; } = false;
        public bool ShowThread { get; set; } = false;

        public bool LockStatus { get; set; } = false;
        public bool FrameVisualization { get; set; } = false;
        public bool ClipAsPerParentView { get; set; } = false;
        public bool ClipView { get; set; } = false;
        public bool CreateBackgroundComponents { get; set; } = false;
        public bool CreateLegends { get; set; } = false;

        public Vector3D FirstVector { get; set; }
        public Vector3D SecondVector { get; set; }
        public Vector3D NormalVector { get; set; }

        public List<double> ClippingArr { get; set; } = new List<double>();
        public List<double> ViewClippingArr { get; set; } = new List<double>();
        public List<List<double>> BreakOutViewClippingArr { get; set; } = new List<List<double>>();

        public INFITF.Document DocumentToLink { get; set; } = null;
        public string DocumentToLinkPartNumber => GetDocumentToLinkPartNumber();

        public bool ViewIsAddedNew { get; set; } = false;
        public bool ViewIsCreated => Convert.ToBoolean(DrawingViewCreated != null);
        public DrawingView DrawingViewCreated { get; set; } = null;

        public List<NoteComponent> Components { get; set; } = null;
        public List<Table> Tables { get; set; } = null;
        public List<Text> Texts { get; set; } = null;
        public ObservableCollection<ViewItem> ViewItems { get; set; } = null;


        #region Constructor

        public ViewItem()
        {
            Initialize("", "", "");
        }

        public ViewItem(string name, int IsVisible = 0)
        {
            Initialize(name, "", "", IsDeleteButtonVisible);
        }

        public ViewItem(string name, string itemType)
        {
            Initialize(name, "", itemType, IsDeleteButtonVisible);
        }

        public ViewItem(string name, string sheetSize, int IsVisible)
        {
            Initialize(name, sheetSize, "", IsDeleteButtonVisible);
        }

        public ViewItem(string name, string sheetSize, string itemType, int DeleteButtonIsVisible = 0)
        {
            Initialize(name, sheetSize, itemType, DeleteButtonIsVisible);
        }

        #endregion

        #region Initialize
        private void Initialize(string name, string sheetSize, string itemType, int isDeleteButtonVisible = 0)
        {
            this.ItemName = name;
            this.ItemNameLine2 = "";
            this.SheetSize = sheetSize;
            this.ItemType = itemType;
            this.IsVisible = this.IsDeleteButtonVisible = isDeleteButtonVisible;
            this.ViewShape = "";

            this.ClippingArr = new List<double>();
            this.ViewClippingArr = new List<double>();
            this.DocumentToLink = null;
            this.DrawingViewCreated = null;

            this.ViewDirection = eViewDirection.Clockwise;
            this.ViewIsVisible = true;
            this.ClipAsPerParentView = this.ClipView = false;

            this.Tables = new List<Table>();
            this.Texts = new List<Text>();
            this.Components = new List<NoteComponent>();
            this.ViewItems = new ObservableCollection<ViewItem>();

            if (this.IsSheetSizeControlVisible != 0) this.SheetSize = IDs.NA;

            this.FirstVector = new Vector3D(0, 0, 0);
            this.SecondVector = new Vector3D(0, 0, 0);
            this.NormalVector = new Vector3D(0, 0, 0);

            this.SheetScale = (this.ItemType == IDs.Sheet) ? IDs.NotToScale : "";
            this.X = this.Y = 0;
            this.Scale = 1;

        }
        #endregion

        #region CanSheetSizeControlVisible
        private int CanSheetSizeControlVisible()
        {
            return (this.ItemType == IDs.Sheet || this.ItemType == IDs.SummarySheet) ? 0 : 1;
        }
        #endregion

        #region GetPositionAsArray
        private double[] GetPositionAsArray(bool getAxisData = false)
        {
            if (ItemType == IDs.Sheet || ItemType == DrawingViewNames.BackgroundView ||
                ItemType == TreeIDs.TreeViewRootElementType ||
                IsAFeature())
                return null;
            if (getAxisData)
                return new double[] { XAxisData, YAxisData };
            else
                return new double[] { X, Y };
        }
        #endregion

        #region GetClippingArray
        private double[] GetClippingArray()
        {
            if (ItemType == IDs.Sheet || UI_Inputs.PrimaryViews.Contains(ItemType) || ItemType == DrawingViewNames.BackgroundView)
                return null;
            return new double[] { X, Y };
        }
        #endregion

        #region GetCombinedName
        public string GetCombinedName()
        {
            string viewName = "";
            try
            {
                viewName = this.ItemName + ((this.ItemNameLine2 != null && this.ItemNameLine2.Trim().Length != 0) ? "\n" + this.ItemNameLine2 : "");
            }
            catch (Exception) { viewName = ""; }
            return viewName;
        }
        #endregion

        #region GetDocumentToLinkPartNumber
        public string GetDocumentToLinkPartNumber()
        {
            string partNumber = "";

            if (DocumentToLink != null)
            {
                try
                {
                    partNumber = (DocumentToLink as PartDocument)?.Product?.get_PartNumber();
                }
                catch (Exception) { partNumber = ""; }

                try
                {
                    if (String.IsNullOrEmpty(partNumber))
                        partNumber = (DocumentToLink as ProductDocument)?.Product?.get_PartNumber();
                }
                catch (Exception) { partNumber = ""; }
            }

            return String.IsNullOrEmpty(partNumber) ? IDs.Empty : partNumber;
        }
        #endregion

        #region GetClone
        public ViewItem GetClone()
        {
            ViewItem clone = new ViewItem();

            INFITF.Document documentToLink = this.DocumentToLink;
            DrawingView drawingViewCreated = this.DrawingViewCreated;

            try
            {
                this.DocumentToLink = null; this.DrawingViewCreated = null;
                string allLines = JsonConvert.SerializeObject(this, Formatting.Indented);
                clone = JsonConvert.DeserializeObject<ViewItem>(allLines);
            }
            catch (Exception ex) { }

            if (clone != null)
            {
                clone.DocumentToLink = documentToLink;
                clone.DrawingViewCreated = drawingViewCreated;
            }

            return clone;
        }
        #endregion

        #region GetViewProperties
        private DrawingViewProperties GetViewProperties()
        {
            if ((UI_Inputs.PrimaryViews.Contains(this.ItemType) && ItemType != DrawingViewNames.BackgroundView) ||
                UI_Inputs.SecondaryViews.Contains(this.ItemType))
                return new DrawingViewProperties()
                {
                    ShowHiddenLines = this.ShowHiddenLines,
                    ShowCenterLines = this.ShowCenterLines,
                    Show3DPoints = this.Show3DPoints,
                    Show3DWireframe = this.Show3DWireframe,
                    ShowFillets = this.ShowFillets,
                    ShowAxisLines = this.ShowAxis,
                    ShowThread = this.ShowThread
                };
            else
                return null;
        }
        #endregion

        #region IsAFeature
        public bool IsAFeature()
        {
            return UI_Inputs.Features.Contains(this.ItemType) ||
                    this.ItemType == FeaturesNames.Notes ||
                    this.ItemType == FeaturesNames.Texts ||
                    this.ItemType == FeaturesNames.Tables ||
                    this.ItemType == FeaturesNames.Components2D;
        }
        #endregion

        #region IsSheet
        public bool IsSheet()
        {
            return this.ItemType == IDs.Sheet || this.IsSummarySheet();
        }
        #endregion

        #region IsSummarySheet
        public bool IsSummarySheet()
        {
            return  this.ItemType == IDs.SummarySheet;
        }
        #endregion

        #region IsView
        public bool IsView()
        {
            return this.IsPrimaryView() || this.IsSecondaryView();
        }
        #endregion

        #region IsPrimaryView
        public bool IsPrimaryView()
        {
            return UI_Inputs.PrimaryViews.Contains(this.ItemType);
        }
        #endregion

        #region IsSecondaryView
        public bool IsSecondaryView()
        {
            return UI_Inputs.SecondaryViews.Contains(this.ItemType);
        }
        #endregion

        #region IsTreeViewRootElement
        public bool IsTreeViewRootElement()
        {
            return this.ItemType == TreeIDs.TreeViewRootElementType;
        }
        #endregion

        #region IsBackgroundView
        public bool IsBackgroundView()
        {
            return this.ItemType == DrawingViewNames.BackgroundView;
        }
        #endregion

        #region IsFrontView
        public bool IsFrontView()
        {
            return this.ItemType == DrawingViewNames.FrontView;
        }
        #endregion

        #region IsRearView
        public bool IsRearView()
        {
            return this.ItemType == DrawingViewNames.RearView;
        }
        #endregion

        #region IsLeftView
        public bool IsLeftView()
        {
            return this.ItemType == DrawingViewNames.LeftView;
        }
        #endregion

        #region IsRightView
        public bool IsRightView()
        {
            return this.ItemType == DrawingViewNames.RightView;
        }
        #endregion

        #region IsTopView
        public bool IsTopView()
        {
            return this.ItemType == DrawingViewNames.TopView;
        }
        #endregion

        #region IsBottomView
        public bool IsBottomView()
        {
            return this.ItemType == DrawingViewNames.BottomView;
        }
        #endregion

        #region IsAuxiliaryView
        public bool IsAuxiliaryView()
        {
            return this.ItemType == DrawingViewNames.AuxiliaryView;
        }
        #endregion

        #region IsSectionView
        public bool IsSectionView()
        {
            return this.ItemType == DrawingViewNames.SectionCut || this.ItemType == DrawingViewNames.SectionView;
        }
        #endregion

        #region IsIsometricView
        public bool IsIsometricView()
        {
            return this.ItemType == DrawingViewNames.IsometricView;
        }
        #endregion

    }
}
