﻿
using Serilog;

namespace A350F_CommonLibs.CatiaUtils
{
    class CatiaMathUtils
    {
        /// <summary>
        /// Calculate the absolute matrix
        /// </summary>
        /// <param name="parentTrafo">Input: left transformation matrix in the production</param>
        /// <param name="localTrafo">Input: second transformation matrix in the production</param>
        /// <param name="absoluteTrafo">Output: result transformation matrix</param>
        public static void TrafoMatrixProduct(double[] parentTrafo, double[] localTrafo, ref double[] absoluteTrafo)
        {
            // l: left matrix, r: right matrix
            // | l0, l3, l6, l9  |     | r0, r3, r6, r9  |
            // | l1, l4, l7, l10 |  .  | r1, r4, r7, r10 |
            // | l2, l5, l8, l11 |     | r2, r5, r8, r11 |
            // |  0,  0,  0,   1 |     |  0,  0,  0,   1 |
            // result matrix has the same sequence

            double[] l = new double[12];
            double[] r = new double[12];

            // Matrix product (Left).(Right)
            for (int i = 0; i < 12; i++)
            {
                l[i] = parentTrafo[i];
                r[i] = localTrafo[i];
            }

            // Rotation
            absoluteTrafo[0] = l[0] * r[0] + l[3] * r[1] + l[6] * r[2];
            absoluteTrafo[3] = l[0] * r[3] + l[3] * r[4] + l[6] * r[5];
            absoluteTrafo[6] = l[0] * r[6] + l[3] * r[7] + l[6] * r[8];
            absoluteTrafo[1] = l[1] * r[0] + l[4] * r[1] + l[7] * r[2];
            absoluteTrafo[4] = l[1] * r[3] + l[4] * r[4] + l[7] * r[5];
            absoluteTrafo[7] = l[1] * r[6] + l[4] * r[7] + l[7] * r[8];
            absoluteTrafo[2] = l[2] * r[0] + l[5] * r[1] + l[8] * r[2];
            absoluteTrafo[5] = l[2] * r[3] + l[5] * r[4] + l[8] * r[5];
            absoluteTrafo[8] = l[2] * r[6] + l[5] * r[7] + l[8] * r[8];
            // Translation - extra plus
            absoluteTrafo[9] = l[0] * r[9] + l[3] * r[10] + l[6] * r[11] + l[9];
            absoluteTrafo[10] = l[1] * r[9] + l[4] * r[10] + l[7] * r[11] + l[10];
            absoluteTrafo[11] = l[2] * r[9] + l[5] * r[10] + l[8] * r[11] + l[11];
        }


        public static void PointTraslate(double[] trafo, double[] oldPos, ref double[] newPos)
        {
            // l: left matrix, oldPos: 
            // | l0, l3, l6, l9  |     | oldPos0 |
            // | l1, l4, l7, l10 |  .  | oldPos1 |
            // | l2, l5, l8, l11 |     | oldPos2 |
            // |  0,  0,  0,   1 |     |       1 |
            // result matrix has the same sequence
            double[] l = new double[12];
            for (int i = 0; i < 12; i++)
            {
                l[i] = trafo[i];
            }

            newPos[0] = l[0] * oldPos[0] + l[3] * oldPos[1] + l[6] * oldPos[2] + l[9];
            newPos[1] = l[1] * oldPos[0] + l[4] * oldPos[1] + l[7] * oldPos[2] + l[10];
            newPos[2] = l[2] * oldPos[0] + l[5] * oldPos[1] + l[8] * oldPos[2] + l[11];
        }

        /// <summary>
        /// Check whether the given point is on the line defined by the second and third point
        /// </summary>
        /// <param name="point">The point to check</param>
        /// <param name="lineP0">first point defines the line</param>
        /// <param name="lineP1">second point defines the line</param>
        /// <returns></returns>
        public static bool IsPointOnLine(double[] point, double[] lineP0, double[] lineP1)
        {

            double dx = lineP1[0] - lineP0[0];
            double dy = lineP1[1] - lineP0[1];
            double dz = lineP1[2] - lineP0[2];

            double ex = point[0] - lineP0[0];
            double ey = point[1] - lineP0[1];
            double ez = point[2] - lineP0[2];

            double q = dx * ex;
            q += dy * ey;
            q += dz * ez;
            q *= q;
            q /= (dx * dx + dy * dy + dz * dz);
            q /= (ex * ex + ey * ey + ez * ez);

            if (q >= 1.0 - 1e-6)
            {
                return true;
            }

            Log.Information($"Point on line check: LineP0-{lineP0[0]},{lineP0[1]},{lineP0[2]} " +
                $"LineP1-{lineP1[0]},{lineP1[1]},{lineP1[2]} Point-{point[0]},{point[1]},{point[2]}");
            return false;
        }

    }


}
