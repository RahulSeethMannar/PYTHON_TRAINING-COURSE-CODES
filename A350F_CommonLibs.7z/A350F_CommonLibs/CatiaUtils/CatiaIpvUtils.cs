﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows;

using A350F_CommonLibs.Stores;

using HybridShapeTypeLib;

using INFITF;

using KnowledgewareTypeLib;

using MECMOD;

using NavigatorTypeLib;

using PARTITF;

using ProductStructureTypeLib;

using Serilog;

using SPATypeLib;

using Application = INFITF.Application;
using Point = HybridShapeTypeLib.Point;

namespace A350F_CommonLibs.CatiaUtils
{
    public class CatiaIpvUtils
    {

        private static string publishName = "IpCheckBodyPub";
        private static string AdfPart = "adf-part";
        private static string Std = "std";
        private static string Bracket = "bracket";
        private static string Standard = "STANDARD";

        const double EPSILON = 0.001;
        const double MULTIPEP = 1.001;
        const double SCALING_FACTOR_MULTIPLIER_FOR_BOUNDING_BOX_CONSTRUCTION = 2.1;

        public class IpvClashResult
        {
            public bool isContactWithPrimaryStruct { get; set; } = false;
            public bool isWithinClearanceToPrimaryStruct { get; set; } = false;
            public bool isClashWithPrimaryStruct { get; set; } = false;
            public bool isClashWithCube { get; set; } = false;
            public bool isClashOnlyWithCubePrimaryStruct { get; set; } = false;
            public bool? isCubeClashWithSomething { get; set; } = null;
            public bool isClashWithOthers { get; set; } = false;
            public bool isClashWithStayOutZone { get; set; } = false;
            public bool isMultiPrimaryStructFound { get; set; } = false;
            public bool isClashWithSecondaryProposal { get; set; } = false;
            public bool isCylindricalHole { get; set; } = false;
            public double? diameter { get; set; }
            public object axisLine { get; set; }
        }

        public class IpvCheckProperty
        {
            public string IpPartNumber { get; set; }
            public List<string> PrimStructList { get; set; }
            public NotificationStoreBase NotifStore { get; set; }
            public bool IsTrend { get; set; } = false;
            public bool IsStandard { get; set; }
            public bool Is3cCheck { get; set; } = false;
            public bool IsEdgeDistCheck { get; set; } = false;
            public bool IsFilletDistCheck { get; set; } = false;
            public bool Is2Dot5mmCheck { get; set; } = false;
            public bool Is25Dot4mmCheck { get; set; } = false;
            public bool IsPitchDistCheck { get; set; } = false;
            public bool IsBboxCheck { get; set; } = false;
            public bool IsHoleCheck { get; set; } = false;
            public bool IsBracketCheck { get; set; } = false;
            public bool IsFeedThroughCheck { get; set; } = false;
            public List<(double, double, double)> IpCoordList { get; set; } = null;
            public IDictionary<string, string> SecondaryNameList { get; set; } = null;
            public double Tolerance { get; set; }
            public double ClearanceTolerance { get; set; } = 0.0;
            public double MultiFac { get; set; } = 1.0;
            public double PlusFac { get; set; } = 0.0;
            public double Diameter { get; set; } = 0.0;
            public string PrimStructPartNumber { get; set; } = "";
            public string ProposalPartNumber { get; set; } = "";
            public string PrimStructPath { get; set; } = "";
            public string PitchDistanceType { get; set; } = "";
            public List<string> ErrorImageLocalPath { get; set; } = null;
            public List<string> ResultInfoList { get; set; } = null;
            public Product TempDatumProduct = null;
            /// <summary>
            /// This list is used to store detected origin found proposal product
            /// The global propsal list could be replaced by disassembled faces from the original proposal
            /// That list will be used for calculation, but still some operation should be executed on 
            /// the original products (like hide/show, etc.)
            /// </summary>
            public ICollection<Product> OriginProposalList = new List<Product>();
        }

        #region main entrance function for different checks
        /**
         * ***********************************************************************************************
         * Start of main checks
         * ***********************************************************************************************
         */

        public static int SelectAndReframeOnFirstValidIp(string partNumber)
        {
            List<Product> validIpList;
            int result = GetValidIpList(null, partNumber, out validIpList, false, true, true);

            if (result > 0 || validIpList is null || validIpList.Count < 1)
            {
                int ipCount = validIpList is null ? 0 : validIpList.Count;
                Log.Error($"Reframe On: Not exact one ip is found. Found {ipCount} ip(s)");
                return 1;
            }

            Product foundProd = validIpList[0];
            List<Product> cubeCheckList = GetCubesFromIp(foundProd);

            if (cubeCheckList.Count < 1)
            {
                Log.Error($"Reframe On: No cube found.");
                return 2;
            }

            Selection selection = CatiaCommonUtils.GetSelection();
            selection.Add(cubeCheckList[0]);

            Application catiaInst = CatiaCommonUtils.GetCatia();
            catiaInst.StartCommand("Reframe On");
            catiaInst.StartCommand("Center graph");

            return 0;
        }

        public static int NotInAirCheck(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList;
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            string ipNumberForTrend = (property.IsTrend) ? property.IpPartNumber : null;

            List<int> resultList = new List<int>();

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, property.IsStandard ? Std : AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);

                if (cubeCheckList is null || cubeCheckList.Count == 0)
                {
                    Log.Error($"No cube instane found");
                    property.ResultInfoList = new List<string>() { ipProduct.get_Name() };
                    CleanDatumRootProduct(property);
                    return 1004;
                }

                // 2. loop all cubes, could have more than one in an IP
                HashSet<Product> clashedCubes = new HashSet<Product>();
                foreach (Product cube in cubeCheckList)
                {
                    Log.Information($"NotInAirCheck: start check for instance ({cube.get_Name()})");

                    Product cubeProd = cube;
                    Product primStructProd = null;
                    IpvClashResult clashResult = ComputeClash(property, null, ref cubeProd, ref primStructProd, ipNumberForTrend);

                    // 3. Compute cube clash with something
                    if (null != clashResult.isCubeClashWithSomething && true == clashResult.isCubeClashWithSomething)
                    {
                        clashedCubes.Add(cubeProd);
                        result = 0;
                        Log.Information($"NotInAirCheck: Found clashed cube - {cubeProd.get_Name()}");
                    }
                    else
                    {
                        result = 1;
                        string errorMsg = $"A Cube is not clashing with anything";
                        Body cubeBody = GetPart(cubeProd).MainBody;
                        Reference cubeRef = GetPart(cubeProd).CreateReferenceFromObject(cubeBody);
                        string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(null, null, cubeBody, cube,
                            cube, property.IpPartNumber, "CBNotInAir", errorMsg, property);
                        Log.Information($"NotInAirCheck: One cube is not clashing with anything - {cubeProd.get_Name()}");
                        //break;
                    }

                    resultList.Add(result);
                }
            }

            CleanDatumRootProduct(property);
            return resultList.Max();
        }

        public static int HoleClashWithCubeAndPrimStruct(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList = new List<Product>();
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                result = PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                result = CheckSecondaryAndCubeCount(adfPartCheckList, cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                // 2. loop all cylinders, could have more than one in an IP
                HashSet<Product> clashedCubes = new HashSet<Product>();
                foreach (Product adfPartProd in adfPartCheckList)
                {
                    result = CheckSingleCylinderCrash(property, property.NotifStore, property.IpPartNumber, clashedCubes, adfPartProd, property.IsTrend);
                    if (result > 0)
                    {
                        CleanDatumRootProduct(property);
                        return result;
                    }
                }

                // 3. make sure cylinder clashes with different cubes
                if (clashedCubes.Count != adfPartCheckList.Count && result == 0)
                {
                    result = 2;
                    Log.Error($"HoleClashCheck: Clashed cube count {clashedCubes.Count} is not matching cylinder count {adfPartCheckList.Count}");
                }

                CleanDatumRootProduct(property);
            }

            return result;
        }

        public static int Hole2Dot5MmCheck(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList = new List<Product>();
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                result = PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                result = CheckSecondaryAndCubeCount(adfPartCheckList, cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
                if (rootDoc is null)
                {
                    Log.Error($"Hole 2.5mm check: root document not found");
                    CleanDatumRootProduct(property);
                    return 1005;
                }

                List<int> resultList = new List<int>();

                // 2. loop all cylinders, could have more than one in an IP
                HashSet<Product> clashedCubes = new HashSet<Product>();
                foreach (Product cylinderProd in adfPartCheckList)
                {
                    result = Hole2dot5mmSingleCheck(property, property.NotifStore, property.IpPartNumber,
                        property.Tolerance, rootDoc, clashedCubes, cylinderProd, property.IsTrend);

                    resultList.Add(result);

                    //if (result > 0)
                    //{
                    //    return result;
                    //}
                }

                if (resultList.Max() > 0)
                {
                    CleanDatumRootProduct(property);
                    return resultList.Max();
                }

                // 3. make sure cylinder clashes with different cubes
                if (clashedCubes.Count != adfPartCheckList.Count)
                {
                    result = 2;
                    Log.Error($"Hole 2.5mm check: Clashed cube count {clashedCubes.Count} is not matching cylinder count {adfPartCheckList.Count}");
                }

                CleanDatumRootProduct(property);

            }

            return result;
        }

        public static int FeedThroughContactWithPrimStruct(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList;
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);

                if (adfPartCheckList is null || adfPartCheckList.Count == 0)
                {
                    Log.Error($"No valid Feed Through instane found");
                    CleanDatumRootProduct(property);
                    return 1006;
                }

                string ipNumberForTrend = (property.IsTrend) ? property.IpPartNumber : null;

                // 2. loop all feed through drum. Normally should only has one.
                HashSet<Product> clashedCubes = new HashSet<Product>();
                List<int> resultList = new List<int>();
                foreach (Product feedThroughProd in adfPartCheckList)
                {
                    Log.Information($"Feedthrough contact prim struct check: start check for instance ({feedThroughProd.get_Name()})");

                    Product cubeProd = null;
                    Product primStructProd = null;
                    IpvClashResult clashResult = ComputeClash(property, feedThroughProd, ref cubeProd, ref primStructProd, ipNumberForTrend, property.Tolerance);

                    // Evaluate clash result
                    CheckSingleFeedThroughContactClashResult(property, ipNumberForTrend, resultList, feedThroughProd,
                        ref cubeProd, ref primStructProd, ref clashResult);
                }

                result = Math.Max(resultList.Max(), result);
            }

            if (result > 0)
            {
                Log.Error($"Feedthrough contact prim struct check failed by at least one proposal with highst internal error value {result}");
            }

            CleanDatumRootProduct(property);
            return result;
        }

        public static int FeedThrough2Dot5MmCheck(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList = new List<Product>();
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                CleanDatumRootProduct(property);
                return result;
            }
            result = -1;

            property.NotifStore.ProgressValue += 10;
            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);

                result = FeedThroughSingleIp2dot5mmCheck(property, (List<Product>)adfPartCheckList, (List<Product>)cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }
            }

            CleanDatumRootProduct(property);
            return result;
        }

        public static int BracketNotCrashWithPrimStruct(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList;
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> bracketList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, property.IsStandard ? Std : AdfPart,
                    ref bracketList, ref cubeCheckList);

                if (bracketList is null || bracketList.Count == 0)
                {
                    Log.Error($"No valid Standard/Non-Standard Part instane found");
                    CleanDatumRootProduct(property);
                    return 1006;
                }

                string ipNumberForTrend = (property.IsTrend) ? property.IpPartNumber : null;

                // 2. loop all standard part, could have more than one in an IP
                HashSet<Product> clashedCubes = new HashSet<Product>();
                foreach (Product bracket in bracketList)
                {
                    Log.Information($"Standard/Non-Standard part not crash prim struct check: start check for instance ({bracket.get_Name()})");

                    Product cubeProd = null;
                    Product primStructProd = null;
                    IpvClashResult clashResult = ComputeClash(property, bracket, ref cubeProd, ref primStructProd, ipNumberForTrend);

                    // Check clash result
                    BracketClashSingleResultCheck(property, ref result, ipNumberForTrend, bracket, ref cubeProd, ref primStructProd, ref clashResult);
                    if (result > 0)
                    {
                        CleanDatumRootProduct(property);
                        return result;
                    }
                }

                result = 0;
                Log.Information($"Standard/Non-Standard part not crash prim struct check: successful - clashes found but not clash with prim struct");
            }

            CleanDatumRootProduct(property);
            return result;
        }

        public static int BracketContactWithPrimStruct(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList;
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> proposalBracketList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, property.IsStandard ? Std : AdfPart,
                    ref proposalBracketList, ref cubeCheckList);

                if (proposalBracketList is null || proposalBracketList.Count == 0)
                {
                    Log.Error($"No valid proposal bracket instane found");
                    CleanDatumRootProduct(property);
                    return 1006;
                }

                string ipNumberForTrend = (property.IsTrend) ? property.IpPartNumber : null;

                // 2. loop all proposal bracket, could have more than one in an IP
                HashSet<Product> clashedCubes = new HashSet<Product>();
                foreach (Product bracket in proposalBracketList)
                {
                    Log.Information($"Proposal bracket contact prim struct check: start check for instance ({bracket.get_Name()})");

                    Product cubeProd = null;
                    Product primStructProd = null;
                    IpvClashResult clashResult = ComputeClash(property, bracket, ref cubeProd, ref primStructProd, ipNumberForTrend, property.Tolerance);

                    BracketContactSingleClashResultCheck(property, ref result, ipNumberForTrend, bracket, ref cubeProd, ref primStructProd, ref clashResult);
                    if (result >= 0)
                    {
                        CleanDatumRootProduct(property);
                        return result;
                    }
                }

                result = 2;
                Log.Error($"Standard part contact prim struct check: failed no contact/clearance with prim struct result found");
            }

            CleanDatumRootProduct(property);
            return result;
        }

        public static int BracketEdgeWebDistance2Dot5mmCheck(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList = new List<Product>();
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            // cube count and bracket count doesn't need to be equal
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> bracketList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct,
                    property.IsStandard ? Std : AdfPart, ref bracketList, ref cubeCheckList);

                if (bracketList is null || bracketList.Count == 0)
                {
                    Log.Error($"Bracket Edge/Distance to Fillet Check: No valid bracket instane found");
                    CleanDatumRootProduct(property);
                    return 1006;
                }
                else if (bracketList.Count > 1)
                {
                    Log.Error($"More than one bracket part or assembly found under BFH node ");
                    CleanDatumRootProduct(property);
                    return 4104;
                }

                Selection selection = CatiaCommonUtils.GetSelection();
                ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
                if (rootDoc is null)
                {
                    Log.Error($"Bracket Edge/Distance to Fillet Check: root document not found");
                    CleanDatumRootProduct(property);
                    return 1005;
                }

                // 2. loop all brackets if more than one exists
                foreach (Product bracketProd in bracketList)
                {

                    result = BracketSingleCheck(property, selection, rootDoc, bracketProd, ipProduct, cubeCheckList);
                    if (result > 0)
                    {
                        CleanDatumRootProduct(property);
                        return result;
                    }
                }

            }

            CleanDatumRootProduct(property);
            return result;
        }

        public static int HoleEdgeWebDistanceCheck(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList;
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            if (property.Diameter <= 0)
            {
                result = 2002;
                Log.Error($"Hole Edge/Distance to Fillet Check: Input diameter {property.Diameter} is not valid");
                property.ResultInfoList = new List<string>() { property.Diameter.ToString() };
                return result;
            }

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                result = PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                result = CheckSecondaryAndCubeCount(adfPartCheckList, cubeCheckList);
                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
                if (rootDoc is null)
                {
                    Log.Error($"Hole Edge/Distance to Fillet Check: root document not found");
                    CleanDatumRootProduct(property);
                    return 1005;
                }

                SPAWorkbench spaWorkBench = (SPAWorkbench)rootDoc.GetWorkbench("SPAWorkbench");
                Selection selection = rootDoc.Selection;

                // 2. loop all cylinders, could have more than one in an IP
                HashSet<Product> clashedCubes = new HashSet<Product>();
                foreach (Product cylinderProd in adfPartCheckList)
                {
                    int tmpResult = HoleSingleEdgeWebDistCheck(property, rootDoc, selection,
                        cylinderProd, ipProduct, cubeCheckList);
                    result = Math.Max(result, tmpResult);
                }

                CleanDatumRootProduct(property);
            }

            return result;
        }

        public static string GetVpmPrimaryStructRelatedInfo(IpvCheckProperty property)
        {
            string primDefinition = "";
            List<Product> validIpList;
            int result = GetValidIpList(property, property.IpPartNumber, out validIpList, false);
            if (result > 0)
            {
                return primDefinition;
            }

            // 1. loop all valid IP product, normally should only have one instance
            // cube count and bracket count doesn't need to be equal
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> secondaryList = new List<Product>();
                string proposalPartNumber = "";
                if (!CanGetSecondaryList(ref proposalPartNumber, ipProduct, ref secondaryList, property))
                {
                    property.ProposalPartNumber = proposalPartNumber;
                    continue;
                }
                property.ProposalPartNumber = proposalPartNumber;

                Product cubeProd = null;
                Product primStructProd = null;
                IpvClashResult clashResult = ComputeClash(property, secondaryList.First(), ref cubeProd, ref primStructProd);
                if (primStructProd is null)
                {
                    return primDefinition;
                }

                if (clashResult.isMultiPrimaryStructFound)
                {
                    string status = SelectInteractiveProductOrFromPs(ref primStructProd, property);
                    if (status == "Cancel" || primStructProd is null)
                    {
                        return primDefinition;
                    }

                    try
                    {
                        property.PrimStructPartNumber = primStructProd.get_PartNumber();
                        primDefinition = primStructProd.get_Definition();
                    }
                    catch
                    {
                        return primDefinition;
                    }
                }

                primDefinition = primStructProd.get_Definition();

                double[] absTrafo = new double[12];
                string path = "";
                CatiaProdUtils.GetAbsTrafo(primStructProd, CatiaCommonUtils.GetActiveRootProd(), ref absTrafo, ref path, true);
                property.PrimStructPath = path;
            }

            return primDefinition;
        }

        public static string GetTrendPrimaryStructDefinition(IpvCheckProperty property)
        {
            string definition = "";
            ICollection<Product> cubeCheckList = new List<Product>();
            ICollection<Product> adfPartCheckList = new List<Product>();
            PartDocument tempPartDoc = null;

            // Collect all adf part and standard part as secondary to detect later for prim structure
            //List<string> proposalPartListFromDB = GetProposalPartNumTrend(instNameSecondaryList, AdfPart);
            //List<string> proposalStdFromDB = GetProposalPartNumTrend(instNameSecondaryList, Standard);
            //proposalPartListFromDB.AddRange(proposalStdFromDB);
            List<string> proposalPartListFromDB;
            if (property.IsStandard)
            {
                proposalPartListFromDB = GetProposalPartNumTrend(property.SecondaryNameList, Standard);
            }
            else
            {
                proposalPartListFromDB = GetProposalPartNumTrend(property.SecondaryNameList, AdfPart);
            }

            // gets the IP cube list based on the ip coordinates data from DB
            GetCubeSecondaryListTrend(property, property.IpCoordList, ref tempPartDoc,
                ref cubeCheckList, ref adfPartCheckList, proposalPartListFromDB);

            string foundPrimStructPn = "";
            Product foundPrimStruct = null;
            foreach (Product secondProd in adfPartCheckList)
            {
                Product cubeProd = null;
                Product primStructProd = null;
                IpvClashResult clashResult = ComputeClash(property, secondProd, ref cubeProd, ref primStructProd);
                if (foundPrimStruct is null && primStructProd != null && !clashResult.isMultiPrimaryStructFound)
                {
                    foundPrimStructPn = primStructProd.get_PartNumber();
                    foundPrimStruct = primStructProd;
                    break;
                }
                else
                {
                    string status = SelectInteractiveProductOrFromPs(ref foundPrimStruct, property);
                    if (status == "Cancel" || foundPrimStruct is null)
                    {
                        return definition;
                    }

                    try
                    {
                        property.PrimStructPartNumber = foundPrimStruct.get_PartNumber();
                        foundPrimStructPn = foundPrimStruct.get_PartNumber();
                    }
                    catch
                    {
                        return definition;
                    }

                    break;
                }

            }

            if (foundPrimStruct != null)
            {
                definition = foundPrimStruct.get_Definition();
                property.PrimStructPartNumber = foundPrimStructPn;
            }

            return definition;
        }

        public static int BoundingBoxParameters(IpvCheckProperty property)
        {
            int result = -1;
            List<Product> validIpList = new List<Product>();
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> nonStdBracketList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref nonStdBracketList, ref cubeCheckList);

                if (nonStdBracketList is null || nonStdBracketList.Count == 0)
                {
                    Log.Error($"No valid Standard/Non-Standard Part instane found");
                    CleanDatumRootProduct(property);
                    return 1006;
                }

                ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
                if (rootDoc is null)
                {
                    Log.Error($"Non Std Bracket Bounding Box Parameter Check: root document not found");
                    CleanDatumRootProduct(property);
                    return 1005;
                }

                SPAWorkbench spaWorkBench = (SPAWorkbench)rootDoc.GetWorkbench("SPAWorkbench");
                Selection selection = rootDoc.Selection;

                // 2. loop all non standard part, could have more than one in an IP
                foreach (Product nonStdBracket in nonStdBracketList)
                {

                    result = NonStdBracketSingleCheck(property.NotifStore, property.IpPartNumber, selection, rootDoc, nonStdBracket, ipProduct);
                    if (result > 0)
                    {
                        CleanDatumRootProduct(property);
                        return result;
                    }

                }

            }

            CleanDatumRootProduct(property);
            return result;
        }

        public static int CLS25Dot4MmCheck(IpvCheckProperty property)
        {
            int result = -1;

            List<Product> validIpList = new List<Product>();
            result = GetValidIpList(property, property.IpPartNumber, out validIpList, property.IsTrend);
            if (result > 0)
            {
                return result;
            }
            result = -1;

            property.NotifStore.ProgressValue += 10;

            // 1. loop all valid IP product, normally should only have one instance
            foreach (Product ipProduct in validIpList)
            {
                ICollection<Product> adfPartCheckList = new List<Product>();
                ICollection<Product> cubeCheckList = new List<Product>();
                PrepareInputCubeSecondary(property, property.IsTrend, property.IpCoordList, property.SecondaryNameList, ipProduct, AdfPart,
                    ref adfPartCheckList, ref cubeCheckList);

                if (cubeCheckList is null || cubeCheckList.Count == 0)
                {
                    Log.Error($"CLS IP 25.4mm Distance Check: No IP Cube instane found");
                    CleanDatumRootProduct(property);
                    return 1004;
                }

                Selection selection = CatiaCommonUtils.GetSelection();
                ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
                if (rootDoc is null)
                {
                    Log.Error($"CLS IP 25.4mm Distance Check: root document not found");
                    CleanDatumRootProduct(property);
                    return 1005;
                }

                // Create a List of tuples to store the points with x, y, and z coordinates
                List<(double X, double Y, double Z)> pointsList = new List<(double, double, double)>();
                //HybridShapeFactory hybridShapeFactory = null;               
                SPAWorkbench spaWorkBench = (SPAWorkbench)rootDoc.GetWorkbench("SPAWorkbench");

                // create cog points of all cubes for calculation
                result = CreateClsIpCubeCogPoint(property, property.IpPartNumber, cubeCheckList, rootDoc, pointsList, property.IsTrend,
                    out HybridShapeFactory hybridShapeFactory, out HybridBody dummyGeometricalSet, out PartDocument tempPartDoc);

                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }

                // Sort the List by X coordinate in ascending order
                List<(double X, double Y, double Z)> sortedList = pointsList.OrderBy(p => p.X).ToList();

                // performs 25.4mm check between IP cubes
                result = PerformClsIp25Dot4MmCheck(rootDoc, property.IpPartNumber, property.Tolerance, spaWorkBench, hybridShapeFactory, dummyGeometricalSet,
                                    tempPartDoc, sortedList);

                if (result > 0)
                {
                    CleanDatumRootProduct(property);
                    return result;
                }
            }

            CleanDatumRootProduct(property);
            return result;
        }

        /**
        * ***********************************************************************************************
        * End of main checks
        * ***********************************************************************************************
        */
        #endregion

        #region internal functions

        private static int GetValidIpList(IpvCheckProperty property, string ipPartNumber, out List<Product> validIpList,
            bool isTrend, bool changeMode = true, bool preCheck = false)
        {
            List<Product> ipList = new List<Product>();
            List<string> ipPathList = new List<string>();

            CatiaProdUtils.FindAllInstances(ipPartNumber, null, "", ref ipList, ref ipPathList, changeMode, preCheck);

            if (ipList.Count == 0 && !isTrend)
            {
                validIpList = new List<Product>();
                Log.Error("No IP found in the active product");
                return 1001;
            }
            else if (ipList.Count == 0 && isTrend)
            {
                if (property is null || property.IpCoordList is null || property.IpCoordList.Count == 0 )
                {
                    validIpList = new List<Product>();
                    Log.Error("Incorrect or incomplete IP coordinates in CoreAll");
                    return 1012;
                }

                validIpList = new List<Product>();
                validIpList.Add(CatiaCommonUtils.GetActiveRootProd());
                Log.Information("Add root product as valid IP to meet internal requirement for Trend case.");
                return 0;
            }

            // We need to check the part numbers of the IP and its parent in case of VPM
            // E.g. V92D parent combination
            validIpList = FilterValideIps(ipList, ipPathList, isTrend);

            if (validIpList.Count == 0)
            {
                Log.Error("No valid IP found");
                return 1002;
            }
            if (validIpList.Count > 1)
            {
                Log.Error("More than one valid IP found");
                return 1003;
            }

            return 0;
        }

        private static int PrepareInputCubeSecondary(IpvCheckProperty property, bool isTrend, List<(double, double, double)> ipCoordList,
            IDictionary<string, string> secondaryNameList, Product ipProduct, string secondaryType,
            ref ICollection<Product> adfPartCheckList, ref ICollection<Product> cubeCheckList)
        {
            int result = -1;

            // get ADF-Part list from Data base, later used to find actual proposal 
            string dbSecType = secondaryType == Std ? Standard : secondaryType;
            List<string> proposalPartListFromDB = GetProposalPartNumTrend(secondaryNameList, dbSecType);

            // For the case of VPM and Trend with BFH node replaced (we are able to find IP and proposal in CATIA)
            if (ipProduct != CatiaCommonUtils.GetActiveRootProd())
            {
                //adfPartCheckList = GetAdfPartFromIp(ipProduct);
                GetSecondaryFromIp(property, ipProduct, ref adfPartCheckList, secondaryType, proposalPartListFromDB);
                cubeCheckList = GetCubesFromIp(ipProduct);
            }
            else
            // For the case of Trend with flat product structure
            {
                PartDocument tempPartDoc = null;

                // gets the IP cube and Cylinder list based on the ip coordinates data from DB
                result = GetCubeSecondaryListTrend(property, ipCoordList, ref tempPartDoc,
                    ref cubeCheckList, ref adfPartCheckList, proposalPartListFromDB);
            }

            // For the case that the secondary are in the same part, we need to disassembly the secondary
            if (result <= 0 && adfPartCheckList.Count > 0 
                && adfPartCheckList.Count != cubeCheckList.Count && !property.Is25Dot4mmCheck)
            {
                result = GetDisassembledSecondaryIfAny(property, adfPartCheckList, cubeCheckList);
            }

            return result;
        }

        /// <summary>
        /// In case for hole check that one part body contains multiple cylinder proposals, we will extract the faces
        /// of the part body and disassembly them into multiple single cylinder and close the surface to get multiple solid 
        /// cylinder part body. They will be used to compute the result to the corresponding IP cube.
        /// </summary>
        /// <param name="property"></param>
        /// <param name="adfPartCheckList"></param>
        /// <param name="cubeCheckList"></param>
        /// <returns></returns>
        private static int GetDisassembledSecondaryIfAny(IpvCheckProperty property, ICollection<Product> adfPartCheckList, 
            ICollection<Product> cubeCheckList)
        {
            int result = 0;

            // Add temp product under root product for calculation and copy cube and crossbean into it
            Product tempProduct = CatiaCommonUtils.GetActiveRootProd().Products.AddNewComponent("Product", "");

            // The temp product will be marked in property class and will be cleaned when check is done
            property.TempDatumProduct = tempProduct;
            Selection selection = CatiaCommonUtils.GetSelection();
            selection.Clear();

            Product tempPartProd = tempProduct.Products.AddNewComponent("Part", "");
            PartDocument tempPartDoc = (PartDocument)tempPartProd.ReferenceProduct.Parent;
            Part tempPart = tempPartDoc.Part;
            HybridBodies hybridBodies = tempPart.HybridBodies;

            // Copy all found secondary parts to temp part
            // We will have several part bodies in the temp part
            foreach (Product adfPart in adfPartCheckList)
            {
                CopyProductPartBreakLinkToTempSameAbsPos(selection, tempPartDoc, adfPart);
            }
            tempPartProd.Update();

            // This list will be refilled with closed surface solids (disassemblied cylinders)
            adfPartCheckList.Clear();

            HybridBody dummyDisassemblySet = hybridBodies.Add();
            dummyDisassemblySet.set_Name("DUMMY DISASSEMBLY ELEMENTS");

            Bodies partBodies = tempPartDoc.Part.Bodies;
            for (int i=1, partIndex = 1; i<=partBodies.Count; i++)
            {
                Body body = partBodies.Item(i);
                try
                {
                    Array datums = BuildDatumsFromBody(tempPart, body, dummyDisassemblySet, tempPartProd);
                    if (datums != null && datums.Length>0)
                    {
                        foreach(HybridShape datum in datums)
                        {
                            // Add the datum to the extracting parent set
                            dummyDisassemblySet.AppendHybridShape(datum);
                            tempPartProd.Update();

                            CloseSurfaceAndSolidToList(adfPartCheckList, tempProduct, selection, partIndex, datum);
                            partIndex++;
                        }
                        tempProduct.Update();
                    }
                }
                catch (Exception e)
                {
                    result = 2007;
                    Log.Error($"Hole Check: Failed while disassembly cylinders from one part {e.ToString()}");
                }
            }

            selection.Clear();
            selection.Add(tempPartProd);
            selection.Delete();
            selection.Clear();
            tempProduct.Update();

            return result;
        }

        /// <summary>
        /// Close surface of single hybridshape and add it to the check list
        /// </summary>
        /// <param name="adfPartCheckList"></param>
        /// <param name="tempProduct"></param>
        /// <param name="selection"></param>
        /// <param name="partIndex"></param>
        /// <param name="datum"></param>
        private static void CloseSurfaceAndSolidToList(ICollection<Product> adfPartCheckList, Product tempProduct, 
            Selection selection, int partIndex, HybridShape datum)
        {
            // Create new part to paste single datum, each part contains one cylinder proposal
            Product tempPartProdDatum = tempProduct.Products.AddNewComponent("Part", "Datum" + partIndex + tempProduct.get_PartNumber());
            PartDocument tempPartDocDatum = (PartDocument)tempPartProdDatum.ReferenceProduct.Parent;
            Part tempPartDatum = tempPartDocDatum.Part;
            HybridBodies hybridBodiesDatum = tempPartDatum.HybridBodies;
            HybridBody disassemblyFaces = hybridBodiesDatum.Add();
            disassemblyFaces.set_Name("DISASSEMBLY SURFACE");
            tempPartProdDatum.Update();

            selection.Clear();
            selection.Add(datum);
            selection.Copy();
            selection.Clear();
            selection.Add(disassemblyFaces);
            selection.PasteSpecial("CATPrtResultWithOutLink");
            selection.Clear();
            tempPartDatum.Update();

            // Closing cylinder surfaces to generate solid cylinder part
            HybridShape surface = disassemblyFaces.HybridShapes.Item(1);
            tempPartDatum.UpdateObject(surface);
            Reference cylinderSurfaceRef = tempPartDatum.CreateReferenceFromObject(surface);
            ShapeFactory shapeFactory = (ShapeFactory)tempPartDatum.ShapeFactory;
            // Add the new solid to main part body
            tempPartDatum.InWorkObject = tempPartDatum.MainBody;
            var closeSurface = shapeFactory.AddNewCloseSurface(cylinderSurfaceRef);
            tempPartDatum.Update();

            // Hide the extraced surfaces
            adfPartCheckList.Add(tempPartProdDatum);
            selection.Clear();
            selection.Add(disassemblyFaces);
            selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            selection.Clear();
        }

        private static void CopyProductPartBreakLinkToTempSameAbsPos(Selection selection, 
            PartDocument tempPartDoc, Product adfPart)
        {
            Part objPart = ((PartDocument)adfPart.ReferenceProduct.Parent).Part;
            double[] absTrafoCube = new double[12];
            string pathOfPart = "";
            CatiaProdUtils.GetAbsTrafo(adfPart, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoCube, ref pathOfPart);
            //PublishFirstBody(prdCub, cubePart, pathCube);
            selection.Clear();
            //selection.Add((AnyObject)prdCub.Publications.Item(publishName).Valuation);
            selection.Add(GetReferenceToRootFirstBody(objPart, pathOfPart));
            selection.Copy();
            selection.Clear();
            selection.Add(tempPartDoc.Part);
            selection.PasteSpecial("CATPrtResultWithOutLink");
            //publishedTmpCubeBodies.Add((Body)selection.Item(1).Value);
            selection.Clear();
            selection.Add(adfPart);
            selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            selection.Clear();
        }

        private static bool CanGetSecondaryList(ref string proposalPartNumber,
            Product ipProduct, ref ICollection<Product> secondaryList, IpvCheckProperty property)
        {
            bool canGetSecondaryList = true;

            List<string> adfPartNamList = GetProposalPartNumTrend(property.SecondaryNameList, AdfPart);
            GetSecondaryFromIp(property, ipProduct, ref secondaryList, AdfPart, adfPartNamList);

            if (secondaryList is null || secondaryList.Count == 0)
            {
                //secondaryList = GetBracketFromIp(ipProduct, true);
                List<string> stdNamList = GetProposalPartNumTrend(property.SecondaryNameList, Standard);
                GetSecondaryFromIp(property, ipProduct, ref secondaryList, Std, stdNamList);

                if (secondaryList is null || secondaryList.Count == 0)
                {
                    //secondaryList = GetBracketFromIp(ipProduct, false);
                    List<string> bracketNamList = GetProposalPartNumTrend(property.SecondaryNameList, Bracket);
                    GetSecondaryFromIp(property, ipProduct, ref secondaryList, Bracket, bracketNamList);

                    proposalPartNumber = secondaryList.First().get_PartNumber();
                    if (secondaryList is null || secondaryList.Count == 0)
                    {
                        canGetSecondaryList = false;
                    }
                    else
                    {
                        proposalPartNumber = secondaryList.First().get_PartNumber();
                    }
                }
                else
                {
                    proposalPartNumber = secondaryList.First().get_PartNumber();
                }
            }
            else
            {
                proposalPartNumber = secondaryList.First().get_PartNumber();
            }

            return canGetSecondaryList;
        }

        private static PartDocument FindAdfAdapPartDocFromAssembly(Product bracket)
        {
            if (bracket is null)
            {
                return null;
            }

            ProductDocument bracketDoc = bracket.ReferenceProduct.Parent as ProductDocument;

            if (bracketDoc is null)
            {
                PartDocument bracketPartDoc = bracket.ReferenceProduct.Parent as PartDocument;
                return bracketPartDoc;
            }

            foreach (Product child in bracket.Products)
            {
                child.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                string toFind = "ADF-PART/ADAP-PART";
                string nomenclature = child.get_Nomenclature();
                if (toFind.ToLower().Contains(nomenclature.ToLower()))
                {
                    return child.ReferenceProduct.Parent as PartDocument;
                }
            }
            return null;
        }

        private static int CheckPrimStruct(IpvCheckProperty property, NotificationStoreBase notifStore, Product secondaryProd,
            ref Product primStructProd, IpvClashResult clashResult, string type)
        {
            // check secondary clearnce, contact or clash with prime structure
            if (!clashResult.isContactWithPrimaryStruct && !clashResult.isClashWithPrimaryStruct && !clashResult.isWithinClearanceToPrimaryStruct
                || primStructProd is null || clashResult.isMultiPrimaryStructFound)
            {
                string status = SelectInteractiveProductOrFromPs(ref primStructProd, property);
                if (status == "Cancel" || primStructProd is null)
                {
                    notifStore.ProgressValue += 100;
                    Log.Error($"{type}: manual check required - secondary part({secondaryProd.get_Name()}) not contacting, " +
                        $"clearanced or clashing with prim structure, or multi prim struct found");
                    return 1008;
                }

                //List<Product> productsToExport = new List<Product>();
                //for (int i = 1; i <= selection.Count2; i++)
                //{
                //    primStructProd = (Product)selection.Item(i).Value;
                //}

                primStructProd.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                property.PrimStructPartNumber = primStructProd.get_PartNumber();
                return 0;
            }
            else
            {
                primStructProd.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                Log.Information($"Primary Strucutre validated with part number {primStructProd.get_PartNumber()}");
                notifStore.ProgressValue += 5;
                return 0;
            }
        }

        private static string SelectInteractiveProductOrFromPs(ref Product primStruct, IpvCheckProperty property)
        {
            // Try to find prim struct using part number in the product structure
            string primStructPn = property.PrimStructPartNumber;
            if (!String.IsNullOrWhiteSpace(primStructPn) && primStructPn.Length > 0)
            {
                primStruct = CatiaProdUtils.FindFirstInActiveDocumentWithPartNumber(primStructPn);
                if (null != primStruct)
                {
                    return "Ok";
                }
            }

            MessageBox.Show($"Unable to detect primary structure automatically. ​" + Environment.NewLine +
                $"Please click on OK and then manually select a primary structure using Tools Palette.", 
                "Select Primary Structure", MessageBoxButton.OK, MessageBoxImage.None,
                MessageBoxResult.OK, MessageBoxOptions.DefaultDesktopOnly);
            Document activeDocument = CatiaCommonUtils.GetActiveDoc();
            Selection selection = activeDocument.Selection;
            selection.Clear();

            // Ask user to select the product to convert to stp file format
            object[] filters = new object[1] { "Product" };

            string status = selection.SelectElement3(filters,
                "Could you please select the primary structure? ", true,
                CATMultiSelectionMode.CATMultiSelTriggWhenUserValidatesSelection, true);

            if (status == "Cancel" || selection.Count2 == 0)
            {
                status = "Cancel";
            }
            else
            {
                primStruct = selection.Item2(1).Value as Product;
                primStruct.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                property.PrimStructPartNumber = primStruct.get_PartNumber();
            }

            return status;
        }

        private static void BracketContactSingleClashResultCheck(IpvCheckProperty property, ref int result, 
            string ipNumberForTrend, Product bracket, ref Product cubeProd, ref Product primStructProd, 
            ref IpvClashResult clashResult)
        {
            if (primStructProd == null || clashResult.isMultiPrimaryStructFound)
            {
                // We can't find prim structure, let the user to select one
                // check bracket contact, clearance or clashes with prim structure
                result = CheckPrimStruct(property, property.NotifStore, bracket, ref primStructProd, clashResult, "Standard part contact prim struct Check");
                if (result > 0)
                {
                    return;
                }

                // recalculate clash
                cubeProd = null;
                clashResult = ComputeClash(property, bracket, ref cubeProd, ref primStructProd, ipNumberForTrend, property.Tolerance);
            }


            if (clashResult is null)
            {
                result = 1007;
                Log.Error($"Standard part contact prim struct check: clash result is null, internal error");
                return;
            }

            if (clashResult.isContactWithPrimaryStruct || clashResult.isWithinClearanceToPrimaryStruct)
            {
                result = 0;
                Log.Information($"Standard part contact prim struct check: OK Contact/Clearance result found.");
                return;
            }
            else
            {
                PartDocument bracketDoc = bracket.ReferenceProduct.Parent as PartDocument;
                if (bracketDoc is null)
                {
                    bracketDoc = FindAdfAdapPartDocFromAssembly(bracket);
                }
                PartDocument primDoc = bracketDoc;
                CatiaCommonUtils.GetPartDocumentFromProduct(primStructProd, ref primDoc);

                result = 1;
                string errorMsg = $"Bracket contact/clearance check failed - No contact/clearance with the structure";
                Log.Information(errorMsg);

                string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(primDoc?.Part?.MainBody, bracketDoc?.Part?.MainBody, null, bracket,
                    bracket, property.IpPartNumber, "StdContact", errorMsg, property);
            }
        }

        private static HybridShapePointCoord CreateCogFromBody(Part tempPart, HybridShapeFactory hbFactory, SPAWorkbench partSpaWorkBench, Body partBody)
        {
            //CREATE A POINT AT COG OF BRACKET BODY
            Reference bodyRef = tempPart.CreateReferenceFromObject(partBody);
            Measurable bodyMeasurable = partSpaWorkBench.GetMeasurable(bodyRef);
            object[] bodyCog = new object[3];
            bodyMeasurable.GetCOG(bodyCog);
            double xCogBracket = (double)bodyCog[0];
            double yCogBracket = (double)bodyCog[1];
            double zCogBracket = (double)bodyCog[2];
            HybridShapePointCoord bodyCogPoint = hbFactory.AddNewPointCoord(xCogBracket, yCogBracket, zCogBracket);
            bodyCogPoint.set_Name("POINT ON BODY COG");
            tempPart.UpdateObject(bodyCogPoint);
            return bodyCogPoint;
        }

        private static int CheckSecondaryAndCubeCount(ICollection<Product> secondaryPartCheckList, ICollection<Product> cubeCheckList)
        {
            if (secondaryPartCheckList is null || secondaryPartCheckList.Count == 0 ||
                cubeCheckList is null || cubeCheckList.Count == 0 ||
                secondaryPartCheckList.Count != cubeCheckList.Count)
            {
                if (secondaryPartCheckList is null || cubeCheckList is null)
                {
                    Log.Error($"No valid Secondary (ADF-Part, ADF-ASSY, ADAP-Part, ADAP-ASSY, cylinder, drum) Part/Cube instane found");
                }
                else if (secondaryPartCheckList != null && cubeCheckList != null)
                {
                    Log.Error($"Secondary (ADF-Part, ADF-ASSY, ADAP-Part, ADAP-ASSY, cylinder, drum) count {secondaryPartCheckList.Count} " +
                        $"not matching cube count {cubeCheckList.Count}");
                    return 1010;
                }
                else
                {
                    Log.Error($"Zero instance of Secondary (ADF-Part, ADF-ASSY, ADAP-Part, ADAP-ASSY, cylinder, drum)/Cube found");
                }
                return 1009;
            }

            return 0;
        }

        /// <summary>
        /// Ip is valid if the first 3 chars are equal the first chars from its parent node
        /// We will use path list to identify the validation
        /// </summary>
        /// <param name="ipList">The input ip list</param>
        /// <param name="ipPathList">The input path list</param>
        /// <returns></returns>
        private static List<Product> FilterValideIps(List<Product> ipList, List<string> ipPathList, bool isTrend = false)
        {
            List<Product> result = new List<Product>();
            if (ipList is null || ipPathList is null || ipList.Count == 0 || ipPathList.Count == 0)
            {
                return result;
            }

            for (int i = 0; i < ipList.Count; i++)
            {
                Product ip = ipList[i];
                string ipPath = ipPathList[i];
                ipPath = ipPath.Trim('/');
                string[] ipPathToken = ipPath.Split('/');
                if (ipPathToken is null || ipPathToken.Length < 2)
                {
                    continue;
                }

                // Get parent part number if not trend
                string ipParent = ipPathToken[ipPathToken.Length - 2];
                if (isTrend)
                {
                    try
                    {
                        Product parentProd = (Product)ip.Parent;
                        ipParent = parentProd.get_PartNumber();
                    }
                    catch
                    {

                    }
                }

                string ipParentTypeCode = ipParent.Substring(0, 4);
                string ipSection = ipPathToken[ipPathToken.Length - 1].Substring(0, 3);

                // First 3 chars from parent node should match that of child node. Fourth char must be a "d".
                if (ipParent.ToLower().StartsWith(ipSection.ToLower()) && ipParentTypeCode.ToLower().EndsWith("d"))
                {
                    result.Add(ip);
                    ip.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                    Log.Information($"Found valid IP for check with path {ipPath}");
                }
                else
                {
                    //result.Add(ip);
                    Log.Warning($"FilterValideIps: Found invalid IP path: {ipPath}");
                }
            }

            return result;
        }
        private static void CleanupProdStruct(Selection selection, ProductDocument rootDoc,
            Product secondaryProd, Product cubeProd, Product primStructProd, Product tempProduct, 
            ICollection<Product> cubeCheckList = null)
        {
            if (tempProduct != null)
            {
                try
                {
                    selection.Clear();
                    selection.Add(tempProduct);
                    selection.Delete();
                }
                catch
                {
                    Log.Debug($"Error happend during cleaning up structure. continue...");
                }

            }

            try
            {
                selection.Clear();
                if (primStructProd != null)
                {
                    selection.Add(primStructProd);
                }
                if (secondaryProd != null)
                {
                    selection.Add(secondaryProd);
                }
                if (cubeCheckList != null)
                {
                    foreach (var cube in cubeCheckList)
                    {
                        selection.Add(cube);
                    }
                } else if (cubeProd != null)
                {
                    selection.Add(cubeProd);
                }
                selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyShowAttr);
                selection.Clear();
                rootDoc.Product.Update();
            }
            catch
            {
                Log.Debug($"Error happend during re-show hidden parts. check continue...");
            }

        }

        private static void CleanDatumRootProduct(IpvCheckProperty property)
        {
            Selection selection = CatiaCommonUtils.GetSelection();
            selection.Clear();
            // Show the proposal product and clean the origin list no matter how. We are using the same property file for all checks
            foreach (Product prod in property.OriginProposalList)
            {
                selection.Add(prod);
            }
            selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyShowAttr);
            property.OriginProposalList.Clear();

            if (property.TempDatumProduct is null)
            {
                return;
            }

            selection.Clear();
            selection.Add(property.TempDatumProduct);
            selection.Delete();

            property.TempDatumProduct = null;
            CatiaCommonUtils.GetActiveRootProd().Update();
        }

        private static List<double[]> GetCylinderCenters(ProductDocument rootDoc, SPAWorkbench spaWorkBench, Selection selection, Product cylinderProd)
        {
            List<double[]> centerList = new List<double[]>();

            // Select all edges in the cylinder part
            PartDocument cylinderPartDoc = (PartDocument)cylinderProd.ReferenceProduct.Parent;
            selection.Add(cylinderPartDoc.Part.MainBody);
            selection.Search("Topology.Edge,sel");

            // Calculate trafo for cylinder
            double[] absTrafo = new double[12];
            string path = "";
            CatiaProdUtils.GetAbsTrafo(cylinderProd, rootDoc.Product, ref absTrafo, ref path);

            // From cylinder we should find two edges (top and bottom boundaries) with type TriDimFeatEdge
            // Then we will get the center point from these two edges
            // Using the center points, we have the center line of the cylinder
            // Then we can check whether the cog point of cube lies on the line or not.
            List<SelectedElement> returnList = new List<SelectedElement>();
            for (int i = 1; i <= selection.Count; i++)
            {
                returnList.Add(selection.Selection.Item(i));
            }
            foreach (SelectedElement edge in returnList)
            {
                string type = edge.Type;
                if (!type.Contains("TriDimFeatEdge"))
                {
                    continue;
                }

                Measurable measure = spaWorkBench.GetMeasurable(edge.Reference);
                object[] center = new object[3];

                // The measured center point is using local trafo. We need to calculate absolute position.
                measure.GetCenter(center);

                double[] oldPos = new double[3];
                double[] newPos = new double[3];
                oldPos[0] = (double)center[0];
                oldPos[1] = (double)center[1];
                oldPos[2] = (double)center[2];

                // Calculate absolution position for the center point of the top and botton edges
                CatiaMathUtils.PointTraslate(absTrafo, oldPos, ref newPos);
                centerList.Add(newPos);
            }
            return centerList;
        }

        private static void CheckSingleFeedThroughContactClashResult(IpvCheckProperty property, string ipNumberForTrend, List<int> resultList,
            Product feedThroughProd, ref Product cubeProd, ref Product primStructProd, ref IpvClashResult clashResult)
        {
            int singleResult = -1;
            if (primStructProd == null || clashResult.isMultiPrimaryStructFound)
            {
                // We can't find prim structure, let the user to select one
                // check bracket contact, clearance or clashes with prim structure
                singleResult = CheckPrimStruct(property, property.NotifStore, feedThroughProd, ref primStructProd, clashResult, "Feedthrough contact prim struct Check");
                if (singleResult > 0)
                {
                    resultList.Add(singleResult);
                    return;
                }

                // recalculate clash
                cubeProd = null;
                clashResult = ComputeClash(property, feedThroughProd, ref cubeProd, ref primStructProd, ipNumberForTrend, property.Tolerance);
            }

            if (clashResult is null)
            {
                singleResult = 1007;
                Log.Error($"Feedthrough contact prim struct check: clash result is null, internal error");
                resultList.Add(singleResult);
                return;
            }

            if (clashResult.isContactWithPrimaryStruct)
            {
                singleResult = 0;
                Log.Information($"Feedthrough contact prim struct check: OK Contact/Clearance result found.");
                resultList.Add(singleResult);
                return;
            }
            else
            {
                PartDocument feedThroughDoc = (PartDocument)feedThroughProd.ReferenceProduct.Parent;
                PartDocument primDoc = feedThroughDoc;
                CatiaCommonUtils.GetPartDocumentFromProduct(primStructProd, ref primDoc);

                string errorMsg = $"Proposal contact check failed - No contact with the structure";
                Log.Information(errorMsg);
                string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(primDoc.Part.MainBody, feedThroughDoc.Part.MainBody, null, feedThroughProd,
                    feedThroughProd, property.IpPartNumber, "FeedThroughContact", errorMsg, property);

                singleResult = 1;
                resultList.Add(singleResult);
            }
        }

        private static int FeedThroughSingleIp2dot5mmCheck(IpvCheckProperty property, List<Product> adfPartCheckList, List<Product> cubeCheckList)
        {
            int result = 0;
            HashSet<Product> clashedCubes = new HashSet<Product>(); ;

            result = CheckSecondaryAndCubeCount(adfPartCheckList, cubeCheckList);
            if (result > 0)
            {
                return result;
            }

            Selection selection = CatiaCommonUtils.GetSelection();
            ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            if (rootDoc is null)
            {
                Log.Error($"Feedthrough 2.5mm check: root document not found");
                return 1005;
            }
            property.NotifStore.ProgressValue += 10;

            // 2. loop all drums, could have more than one in an IP
            foreach (Product drumProd in adfPartCheckList)
            {
                Log.Information($"Feedthrough 2.5mm check: start check for instance ({drumProd.get_Name()})");

                // 2.1. check whether drum clashes with cube
                Product cubeProd = null;
                Product primStructProd = null;
                IpvClashResult clashResult = ComputeClash(property, drumProd, ref cubeProd, ref primStructProd, property.IpPartNumber);
                if (cubeProd is null || !clashResult.isClashWithCube)
                {
                    Log.Information($"Feedthrough 2.5mm check: check failed - no clashed cube found");
                    property.ResultInfoList = new List<string>() { drumProd.get_Name() };
                    return 3001;
                }
                property.NotifStore.ProgressValue += 10;

                clashedCubes.Add(cubeProd);

                result = CheckPrimStruct(property, property.NotifStore, drumProd, ref primStructProd, clashResult, "Feedthrough 2.5mm check");
                if (result > 0)
                {
                    return result;
                }

                // 2.3. cube 2.5mm check (check whether cube cog distance to axis of the feedthrough hole is smaller than tolerance)
                Product tempProduct = null;

                try
                {
                    tempProduct = FeedThroughSingleSecondaryDistCheck(property, property.IpPartNumber, property.NotifStore, selection,
                                        rootDoc, drumProd, cubeProd, primStructProd, property.Tolerance, ref result);
                    property.NotifStore.ProgressValue += 10;
                }
                catch (Exception e)
                {
                    result = 1000;
                    Log.Warning($"Internal execption during FeedThroughSingleIp2dot5mmCheck. {e.ToString()}");
                }

                // clean up the product structure
                CleanupProdStruct(selection, rootDoc, drumProd, cubeProd, primStructProd, tempProduct);

                if (result > 0)
                {
                    return result;
                }
            }

            // 3. make sure cylinder clashes with different cubes
            if (clashedCubes.Count != adfPartCheckList.Count)
            {
                result = 2;
                Log.Error($"Feedthrough 2.5mm check: Clashed cube count {clashedCubes.Count} is not matching drum count {adfPartCheckList.Count}");
            }

            return result;
        }

        private static void BracketClashSingleResultCheck(IpvCheckProperty property, ref int result, string ipNumberForTrend,
            Product bracket, ref Product cubeProd, ref Product primStructProd, ref IpvClashResult clashResult)
        {
            if (clashResult is null)
            {
                Log.Information($"Standard/Non-Standard part not crash prim struct check: clash result is null, no result found");
            }
            else if (primStructProd == null || clashResult.isMultiPrimaryStructFound)
            {
                // We can't find prim structure, let the user to select one
                // check bracket contact, clearance or clashes with prim structure
                result = CheckPrimStruct(property, property.NotifStore, bracket, ref primStructProd, clashResult, "Standard/Non-Standard part not crash prim struct check");
                if (result > 0)
                {
                    return;
                }

                // recalculate clash
                cubeProd = null;
                clashResult = ComputeClash(property, bracket, ref cubeProd, ref primStructProd, ipNumberForTrend);
            }

            if (clashResult is null)
            {
                Log.Information($"Standard/Non-Standard part not crash prim struct check: clash result is null, no result found");
            }
            else if (clashResult.isClashWithPrimaryStruct || clashResult.isClashWithOthers)
            {
                result = 1;
                PartDocument bracketDoc = bracket.ReferenceProduct.Parent as PartDocument;
                if (bracketDoc is null)
                {
                    bracketDoc = FindAdfAdapPartDocFromAssembly(bracket);
                }
                PartDocument primDoc = bracketDoc;
                CatiaCommonUtils.GetPartDocumentFromProduct(primStructProd, ref primDoc);

                string errorMsg = $"Bracket clash check: failed - clash with primary structure {primStructProd.get_PartNumber()} or other parts (not cube)";
                Log.Information(errorMsg);
                string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(primDoc?.Part?.MainBody, bracketDoc?.Part?.MainBody, null, bracket,
                    bracket, property.IpPartNumber, "NonStdCrash", errorMsg, property);
                return;
            }
        }

        private static int BracketSingleCheck(IpvCheckProperty property, Selection selection,
            ProductDocument rootDoc, Product bracketProd, Product ipProduct, ICollection<Product> cubeCheckList)
        {
            int result = 0;
            Log.Information($"Bracket Edge/Distance to Fillet Check: start check for instance ({bracketProd.get_Name()})");

            string ipNumberForTrend = (property.IsTrend) ? property.IpPartNumber : null;

            // 2.1. check whether bracket clashes with cube
            Product cubeProd = null;
            Product primStructProd = null;
            IpvClashResult clashResult = ComputeClash(property, bracketProd, ref cubeProd, ref primStructProd, ipNumberForTrend, property.ClearanceTolerance);
            if (cubeProd is null)
            {
                if (cubeCheckList.Any())
                {
                    cubeProd = cubeCheckList.First();
                }
                else if (property.Is2Dot5mmCheck)
                {
                    Log.Error($"Bracket 2.5mm Check: Error - no cube is found for bracket({bracketProd.get_Name()})");
                    property.ResultInfoList = new List<string>() { bracketProd.get_Name() };
                    return 4001;
                }
                else
                {
                    Log.Information($"Bracket Edge/Distance to Fillet Check: Info - no cube is found for bracket({bracketProd.get_Name()})");
                }
            }

            Product tempProduct = null;
            try
            {
                // Web or Edge distance check
                if (!property.Is2Dot5mmCheck)
                {
                    // 2.2. check bracket contact, clearance or clashes with prim structure
                    result = CheckPrimStruct(property, property.NotifStore, bracketProd, ref primStructProd, clashResult, "Bracket Edge/Fillet Distance Check");
                    if (result > 0)
                    {
                        return result;
                    }

                    // 2.3. Edge or Distance to Fillet Check for the given bracket, cube and prim structure
                    tempProduct = ValidateEdgeWebPitchDist(property, property.IpPartNumber, selection, rootDoc, bracketProd, cubeProd, primStructProd, ipProduct,
                        property.MultiFac, property.Tolerance, property.ClearanceTolerance, 0.0, cubeCheckList, property.IsStandard,
                        ref result, property.PitchDistanceType, property.IsEdgeDistCheck, property.IsPitchDistCheck);
                }
                else
                // 2.5mm check
                {
                    result = CheckPrimStruct(property, property.NotifStore, bracketProd, ref primStructProd, clashResult, "Bracket 2.5mm check");
                    if (result > 0)
                    {
                        return result;
                    }

                    result = BracketSingle2dot5mmCheck(property, property.IpPartNumber, property.Tolerance, property.ClearanceTolerance, selection, rootDoc,
                        bracketProd, cubeProd, primStructProd, ipProduct, cubeCheckList, property.IsStandard, out tempProduct);
                }
            }
            catch (Exception e)
            {
                result = 1000;
                Log.Warning($"Internal execption happens during BracketSingleCheck. {e.ToString()}");
            }

            // clean up the product structure
            CleanupProdStruct(selection, rootDoc, bracketProd, cubeProd, primStructProd, tempProduct);

            return result;
        }

        private static int BracketSingle2dot5mmCheck(IpvCheckProperty property, string ipPartNumber, double tolerance, double clearanceTolerance, Selection selection,
            ProductDocument rootDoc, Product bracketProd, Product cubeProd, Product primStructProd, Product ipProduct,
            ICollection<Product> cubeCheckList, bool isStandard, out Product tempProduct)
        {
            int result = 0;

            if (!CheckParentBfhNode(ipProduct) && !isStandard)
            {
                Log.Warning($"No BFH node found for Trend Bracket 2.5mm check, manual check required");
                tempProduct = null;
                return 4101;
            }

            // Publish all needed part bodies and copy them to temp part for later use
            PartDocument tempPartDoc = null;
            HybridBodies tempGeoSet = null;

            tempProduct = null;
            result = TryCreateTempProduct(property, selection, rootDoc, bracketProd, cubeProd, 
                primStructProd, ref tempProduct, ref tempPartDoc, ref tempGeoSet, isStandard);

            if (result > 0)
            {
                return result;
            }

            Bodies tempPartBodies = tempPartDoc.Part.Bodies;
            Body bodySecondary = tempPartBodies.Item(2);
            Body bodyPrim = tempPartBodies.Item(3);
            Body bodyIpCube = tempPartBodies.Item(4);
            Part tempPart = tempPartDoc.Part;
            SPAWorkbench partSpaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");


            List<Body> publishedTmpCubeBodies = new List<Body>();
            PublishAndCopyTempAllCubes(selection, rootDoc, ipProduct, tempPartDoc, publishedTmpCubeBodies, cubeCheckList);

            HybridBody geoSetMountHoleAxis = tempGeoSet.Add();
            geoSetMountHoleAxis.set_Name("MOUNTING HOLES AXIS LINES");
            HybridBody geoSetInterfaceHoleAxis = tempGeoSet.Add();
            geoSetInterfaceHoleAxis.set_Name("INTERFACE HOLES AXIS LINES");

            List<double> listMountingHoleDiameters = new List<double>();
            result = DetectMountingAndInterfaceAxisLines(tempPartDoc, selection, tempGeoSet, geoSetMountHoleAxis,
                geoSetInterfaceHoleAxis, listMountingHoleDiameters, clearanceTolerance, publishedTmpCubeBodies, isStandard);

            // We got interface axes lines
            if (geoSetInterfaceHoleAxis.HybridShapes.Count > 1)
            {
                Log.Warning($"Bracket 2.5mm check: More than one interface hole/axis line " +
                    $"({geoSetInterfaceHoleAxis.HybridShapes.Count}) found on proposal.");

                // There are cases with multiple interface holes on one bracket and we are expecting more than one
                // interface axes lines to be detected. To solve the problem of clips on the bracket, we are not
                // using the combined body to find the axis line, we will only use bracket for none standard case 
                // to detect the axis line.
                //result = 18;
                //return result;
            }

            if (geoSetInterfaceHoleAxis.HybridShapes.Count < 1)
            {
                Log.Error($"Bracket 2.5mm check: No interface hole found on bracket");

                result = 4002;
                return result;
            }

            List<int> resultList = new List<int>();
            foreach (AnyObject axisShape in geoSetInterfaceHoleAxis.HybridShapes)
            {
                // 1. check the 4 side faces of the cube
                bodyIpCube = IdentifyCubeFromList(bodyIpCube, tempPart, partSpaWorkBench, publishedTmpCubeBodies, axisShape);
                result = CheckMinDistCubeCogAxisLine(property, tempPartDoc, tolerance, axisShape,
                    bodyIpCube, bodyPrim, bodySecondary, ipPartNumber);
                resultList.Add(result);

                // 2. check the cube cog against bracket surface
                result = ValidateMinDistIpCubeAndBracketFace(property, tempPartDoc, axisShape,
                    tempGeoSet, tolerance, ipPartNumber, primStructProd, bodyIpCube, isStandard);
                resultList.Add(result);
            }

            return resultList.Max();
        }

        private static int TryCreateTempProduct(IpvCheckProperty property, Selection selection, ProductDocument rootDoc, 
            Product proposalProd, Product cubeProd, Product primStructProd,  
            ref Product tempProduct, ref PartDocument tempPartDoc, ref HybridBodies tempGeoSet, 
            bool isStandard = true, bool isPitchDistCheck = false, string pitchDistanceType = null)
        {
            int retValue = 0;
            try
            {
                retValue = PrepareTempPartsForCalculation(property, selection, rootDoc, proposalProd, cubeProd, primStructProd, out tempProduct,
                                out tempPartDoc, out tempGeoSet, isStandard, isPitchDistCheck, pitchDistanceType);
            }
            catch (Exception e)
            {
                Log.Warning($"Error happend during temp product preparation, retry {e.ToString()}");
                if (tempProduct != null)
                {
                    // clean up the product structure
                    CleanupProdStruct(selection, rootDoc, proposalProd, cubeProd, primStructProd, tempProduct);
                    tempProduct = null;
                }
            }

            if (tempProduct is null)
            {
                try
                {
                    retValue = PrepareTempPartsForCalculation(property, selection, rootDoc, proposalProd, cubeProd, primStructProd, out tempProduct,
                                    out tempPartDoc, out tempGeoSet, isStandard, isPitchDistCheck, pitchDistanceType);
                }
                catch (Exception e)
                {
                    CleanupProdStruct(selection, rootDoc, proposalProd, cubeProd, primStructProd, tempProduct);
                    tempProduct = null;
                    return 1000;
                }
            }

            return retValue;
        }

        private static bool CheckParentBfhNode(Product ipProduct)
        {
            if (ipProduct == null || ipProduct.Parent == null || ipProduct.Parent == CatiaCommonUtils.GetActiveRootProd())
            {
                return false;
            }

            try
            {
                Product parentProd = null;
                if (ipProduct.Parent is Products)
                {
                    parentProd = (Product)((Products)ipProduct.Parent).Parent;
                }
                else if (ipProduct.Parent is Product)
                {
                    parentProd = (Product)ipProduct.Parent;
                }

                if (parentProd != null && parentProd.get_PartNumber().ToLower().Contains("bfh"))
                {
                    return true;
                }
            }
            catch (Exception e)
            {
                Log.Warning($"Error happens by get bfh parent node, no matter we will return false and continue. {e.ToString()}");

            }

            return false;
        }

        private static Body IdentifyCubeFromList(Body bodyIpCube, Part tempPart, SPAWorkbench partSpaWorkBench,
            List<Body> publishedTmpCubeBodies, AnyObject axisShape)
        {
            Reference axisRef = tempPart.CreateReferenceFromObject(axisShape);
            Measurable axisMeasure = partSpaWorkBench.GetMeasurable(axisRef);

            int count = 0;
            double lastMinDist = 0;
            foreach (Body cube in publishedTmpCubeBodies)
            {
                Reference cubeRef = tempPart.CreateReferenceFromObject(cube);
                double minDist = axisMeasure.GetMinimumDistance(cubeRef);

                if (count == 0 || minDist < lastMinDist)
                {
                    bodyIpCube = cube;
                    lastMinDist = minDist;
                }

                count++;
                //if (minDist < EPSILON)
                //{
                //    bodyIpCube = cube;
                //    break;
                //}
            }

            return bodyIpCube;
        }

        private static void PublishAndCopyTempAllCubes(Selection selection, ProductDocument rootDoc,
            Product ipProduct, PartDocument tempPartDoc, List<Body> publishedTmpCubeBodies, ICollection<Product> cubeCheckList)
        {
            try
            {
                foreach (Product prdCub in cubeCheckList)
                {
                    CopyProductPartBreakLinkToTempSameAbsPos(selection, tempPartDoc, prdCub);
                }
                tempPartDoc.Product.Update();

                for (int i = 5; i <= tempPartDoc.Part.Bodies.Count; i++)
                {
                    publishedTmpCubeBodies.Add(tempPartDoc.Part.Bodies.Item(i));
                }
            }
            catch
            {
                Log.Error($"Error happens by publishing all extra cubes.");
            }
        }

        private static int ValidateMinDistIpCubeAndBracketFace(IpvCheckProperty property, PartDocument tempPartDoc, object axesLineInterface,
            HybridBodies tempGeoSet, double tolerance, string ipPartNumber, Product primStructProd, Body bodyIpCube, bool isStandard)
        {
            int result = -1;
            Part tempPart = tempPartDoc.Part;
            HybridShapeFactory hbFactory = (HybridShapeFactory)tempPart.HybridShapeFactory;
            SPAWorkbench partSpaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
            Bodies tempPartBodies = tempPart.Bodies;
            Body bodyBracket = tempPartBodies.Item(2);
            Body bodyPrim = tempPartBodies.Item(3);

            if (bodyIpCube is null)
            {
                result = 4003;
                Log.Error($"Bracket 2.5mm check: No IP cube Body is found in the temp part");
                return result;
            }

            HybridShapePointCoord bracketCogPoint = CreateCogFromBody(tempPart, hbFactory, partSpaWorkBench, bodyBracket);

            HybridBody element2Dot5mmCheckGeoSet = tempGeoSet.Add();
            element2Dot5mmCheckGeoSet.set_Name("ELEMENTS FOR 2.5 MM CHECK");
            element2Dot5mmCheckGeoSet.AppendHybridShape(bracketCogPoint);

            // FOR EACH BRACKET FACE
            // MEASURE MINIMUM ANGLE BETWEEN BRACKET FACE AND AXIS LINE
            // IF MINIMUM ANGLE IS 90 DEGREE
            // CREATE A 0mm OFFSET PLANES FROM BRACKET FACES
            // APPEND PLANES TO A LIST
            Reference axesLineRef = tempPart.CreateReferenceFromObject((AnyObject)axesLineInterface);
            // This measurable is used to calculate the angle between the axes line and bracket faces
            Measurable axesLineMeasurable = partSpaWorkBench.GetMeasurable(axesLineRef);

            // Looping bracket faces to find the perpendicular faces to the axes line
            List<Face> listSelectedFaces = new List<Face>();
            List<string> listSelectedTypes = new List<string>();
            //if (isStandard)
            //{
            // No difference for std and none std cases
            HybridBody hybridShapesBracketFacesGeometricalSet = (HybridBody)tempGeoSet.GetItem("BRACKET FACES");
            GetAllFacesOfBody(tempPartDoc, hybridShapesBracketFacesGeometricalSet, out listSelectedFaces, out listSelectedTypes);
            //}
            //else
            //{
            //    GetAllFacesOfBody(tempPartDoc, bodyBracket, out listSelectedFaces, out listSelectedTypes);
            //}


            List<HybridShapePlaneOffset> bracketPlanList = new List<HybridShapePlaneOffset>();
            foreach (var bracketFace in listSelectedFaces)
            {
                try
                {
                    double angle = axesLineMeasurable.GetAngleBetween(bracketFace);
                    Log.Debug($"Bracket 2.5mm check: Found angle ({angle}) between one bracket face and interface axes");
                    double delta = Math.Abs(90.0 - angle);
                    if (delta < EPSILON)
                    {
                        HybridShapeExtract bracketFaceExtract = hbFactory.AddNewExtract(bracketFace);
                        bracketFaceExtract.Compute();
                        HybridShapePlaneOffset bracketFacePlane = hbFactory.AddNewPlaneOffset(bracketFace, 0.0, true);
                        bracketFacePlane.Compute();
                        bracketPlanList.Add(bracketFacePlane);
                        element2Dot5mmCheckGeoSet.AppendHybridShape(bracketFacePlane);
                    }
                }
                catch (Exception)
                {
                    Log.Debug($"Bracket 2.5mm check: Can not calculate angle between one bracket face and interface axes");
                }
            }

            // FOR EACH PERPENDICULAR PLANE IN LIST
            // MEASURE DISTANCE TO COG OF BODY BRACKET
            // MEASURE DISTANCE TO BODY IP CUBE
            // MEASURE DISTANCE TO INTERFACE HOLE FACE
            // IF MINIMUM DISTANCE TO BODY IP CUBE IS NOT EQUAL TO 0
            // CONTINUE TO LOOPING
            // ELSE CREATE A DICT
            Reference bracketCogPointRef = tempPart.CreateReferenceFromObject(bracketCogPoint);
            // This measurable is used to calculate the min distance of the point to the bracket faces
            Measurable bracketCogPointMeasurable = partSpaWorkBench.GetMeasurable(bracketCogPointRef);
            Reference cubeRef = tempPart.CreateReferenceFromObject(bodyIpCube);
            // This measurable is used to calculate the min distance of the ip cube to the bracket faces
            Measurable cubeMeasurable = partSpaWorkBench.GetMeasurable(cubeRef);
            var distPlanDict = new Dictionary<HybridShapePlaneOffset, double>();
            foreach (HybridShapePlaneOffset plane in bracketPlanList)
            {
                double cubePlanDist = cubeMeasurable.GetMinimumDistance((Reference)plane);
                if (Math.Abs(cubePlanDist) >= EPSILON)
                {
                    continue;
                }
                double bracketCogPlanDist = bracketCogPointMeasurable.GetMinimumDistance((Reference)plane);
                distPlanDict[plane] = bracketCogPlanDist;
            }

            // Sort the distance of the plan to the bracket cog 
            var sortedDistPlanePairs = distPlanDict.OrderByDescending(x => x.Value).ToList();
            HybridShapePlaneOffset farestPlane = sortedDistPlanePairs[0].Key;

            HybridShapePointCoord cubeCogPoint = CreateCogFromBody(tempPart, hbFactory, partSpaWorkBench, bodyIpCube);
            Reference cubeCogPointRef = tempPart.CreateReferenceFromObject(cubeCogPoint);
            // This measurable is used to calculate the min distance of the ip cube cog to the found face, should have 0 value
            Measurable cubeCogMeasurable = partSpaWorkBench.GetMeasurable(cubeCogPointRef);
            double cubeCogPlaneDist = cubeCogMeasurable.GetMinimumDistance((Reference)farestPlane);
            double tartgetDist = tolerance + EPSILON;

            result = IpCubeBracketResultCalculation(property, ipPartNumber, bodyIpCube, bodyBracket, bodyPrim, sortedDistPlanePairs,
                cubeCogPointRef, cubeCogMeasurable, cubeCogPlaneDist, tartgetDist);

            return result;
        }

        private static int IpCubeBracketResultCalculation(IpvCheckProperty property, string ipPartNumber,
            Body bodyIpCube, Body bodyBracket, Body bodyPrim, List<KeyValuePair<HybridShapePlaneOffset, double>> sortedDistPlanePairs,
            Reference cubeCogPointRef, Measurable cubeCogMeasurable, double cubeCogPlaneDist, double tartgetDist)
        {
            int result = 1;

            if (Math.Abs(cubeCogPlaneDist) < tartgetDist)
            {
                result = 0;
                Log.Information($"Bracket 2.5mm check: Successful. IP cube cog minimum distance to the " +
                    $"found bracket plane is {Math.Round(cubeCogPlaneDist, 4)}. Within tolerance {Math.Round(tartgetDist, 4)}");
            }
            // for none standard case, we need to calculate the distance of other planes to the cube cog
            else if (!property.IsStandard)
            {
                // we need to take case of the case of real failed and manual check required.
                for (int i = 1; i < sortedDistPlanePairs.Count; i++)
                {
                    HybridShapePlaneOffset plane = sortedDistPlanePairs[i].Key;
                    double cubePlaneDist = cubeCogMeasurable.GetMinimumDistance((Reference)plane);

                    // if we found the cube is in tolerance range of undesired plan, its a manual check required.
                    if (cubePlaneDist < tartgetDist)
                    {
                        result = 4102;
                        Log.Warning($"Bracket 2.5mm check: Not farest plane is near cube cog with distance {cubePlaneDist} " +
                            $"which is within tolerance {Math.Round(tartgetDist, 4)}, manual check required");
                        break;
                    }
                }
            }

            // Real failed case, take failed image
            if (result > 0 && result < 10)
            {
                string errorMsg = $"Bracket 2.5mm check failed, min distance is {Math.Round(cubeCogPlaneDist, 4)}mm " +
                    $"between bracket outer face and cube COG. Tolerance {Math.Round(tartgetDist, 4)}mm violation";
                string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrim, bodyBracket, bodyIpCube, bodyIpCube,
                    cubeCogPointRef, ipPartNumber, "bracket2_5mm", errorMsg, property);

                Log.Warning($"Bracket 2.5mm check: Failed. IP cube cog minimum distance to the " +
                    $"found bracket plane is {Math.Round(cubeCogPlaneDist, 4)}. Greater than tolerance {Math.Round(tartgetDist, 4)}");
            }

            return result;
        }

        private static int CheckSingleCylinderCrash(IpvCheckProperty property, NotificationStoreBase notifStore, string ipPartNumber,
                        HashSet<Product> clashedCubes, Product adfPartProd, bool isTrend)
        {
            int result = -1;
            Log.Information($"Hole cylinder crash cube/prim struct check: start check for instance ({adfPartProd.get_Name()})");

            string ipNumberForTrend = (isTrend) ? ipPartNumber : null;

            Product cubeProd = null;
            Product primStructProd = null;
            IpvClashResult clashResult = ComputeClash(property, adfPartProd, ref cubeProd, ref primStructProd, ipNumberForTrend);

            if (primStructProd == null)
            {
                // We can't find prim structure, let the user to select one
                // check bracket contact, clearance or clashes with prim structure
                result = CheckPrimStruct(property, notifStore, adfPartProd, ref primStructProd, clashResult, "Standard part contact prim struct Check");
                if (result > 0)
                {
                    return result;
                }

                // recalculate clash
                cubeProd = null;
                clashResult = ComputeClash(property, adfPartProd, ref cubeProd, ref primStructProd, ipNumberForTrend);
            }

            if (clashResult is null)
            {
                Log.Error($"Crash only cube/prim struct check: clash result is null");
                result = 1007;
            }
            else if (clashResult.isClashWithCube && clashResult.isClashWithPrimaryStruct)
            {
                result = 0;
                clashedCubes.Add(cubeProd);
                Log.Information($"Clash with cube and primary structure");
            }
            else
            // Check failed, make screenshot for it
            {
                string errorMsg = $"A cylinder/proposal is not clashing with cube and primary structure";
                string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(null, null, null, adfPartProd,
                    adfPartProd, ipPartNumber, "cylindercrash", errorMsg, property);
                Log.Information($"Crash cube/prim struct check: check failed - {errorMsg}");
                result = 1;
            }
            return result;
        }

        private static int HoleSingleEdgeWebDistCheck(IpvCheckProperty property, ProductDocument rootDoc, Selection selection,
            Product cylinderProd, Product ipProduct, ICollection<Product> cubeCheckList)
        {
            int result = -1;
            Log.Information($"Hole Edge/Distance to Fillet Check: start check for instance ({cylinderProd.get_Name()})");

            string ipNumberForTrend = (property.IsTrend) ? property.IpPartNumber : null;

            // 2.1. check whether seconadary part clashes with cube
            Product cubeProd = null;
            Product primStructProd = null;
            IpvClashResult clashResult = ComputeClash(property, cylinderProd, ref cubeProd, ref primStructProd, ipNumberForTrend);
            if (cubeProd is null)
            {
                if (cubeCheckList.Any())
                {
                    cubeProd = cubeCheckList.First();
                }
                else
                {
                    Log.Error($"Hole Edge/Distance to Fillet Check: Info - no cube is found for cylider({cylinderProd.get_Name()})");
                    property.ResultInfoList = new List<string>() { cylinderProd.get_Name() };
                    result = 2001;
                }
            }

            if (result > 0)
            {
                return result;
            }

            // 2.2. check bracket contact or clashes with prim structure
            result = CheckPrimStruct(property, property.NotifStore, cylinderProd, ref primStructProd, clashResult, "Hole Edge/Fillet Distance Check");
            if (result > 0)
            {
                return result;
            }

            // 2.3. Edge or Fillet Distance check for the given secondary part, cube and prim structure
            Product tempProduct = null;

            try
            {
                tempProduct = ValidateEdgeWebPitchDist(property, property.IpPartNumber, selection, rootDoc, cylinderProd, cubeProd, primStructProd,
                    ipProduct, property.MultiFac, property.Tolerance, property.ClearanceTolerance, property.Diameter,
                    cubeCheckList, false, ref result, property.PitchDistanceType, property.IsEdgeDistCheck, property.IsPitchDistCheck);
            }
            catch (Exception e)
            {
                result = 1000;
                Log.Warning($"Internal execption during HoleSingleEdgeWebDistCheck, check will continue. {e.ToString()}");
            }

            // clean up the product structure
            CleanupProdStruct(selection, rootDoc, cylinderProd, cubeProd, primStructProd, tempProduct, cubeCheckList);

            return result;
        }

        private static double CalculateCubePrimStructDistance(Selection selection, Product tempProduct, Product cubeProd,
            Product primStructProd, double[] absTrafoCube, string pathCube, string pathPrimStruct)
        {
            //CopyCubeCrossBeanToTemp(cubeProd, crossBeamProd, selection, tempProduct);

            Product tempPart = tempProduct.Products.AddNewComponent("Part", "");
            PartDocument tmpPartDoc = (PartDocument)tempPart.ReferenceProduct.Parent;
            HybridBodies hybridBodies = tmpPartDoc.Part.HybridBodies;
            HybridShapeFactory hbFactory = (HybridShapeFactory)tmpPartDoc.Part.HybridShapeFactory;
            ShapeFactory shapeFactory = (ShapeFactory)tmpPartDoc.Part.ShapeFactory;
            SPAWorkbench partSpaWorkBench = (SPAWorkbench)tmpPartDoc.GetWorkbench("SPAWorkbench");
            HybridBody checkHbBody = hybridBodies.Add();
            checkHbBody.set_Name("Dummy_Elements_For_Check");

            // Copy cube and crossbeam with absolute position (By publication) to tmp prod
            Reference refCog = CopyCubePrimStructToTmpPart(selection, cubeProd, primStructProd,
                pathCube, pathPrimStruct, tmpPartDoc, hbFactory, checkHbBody);

            // Calculate the intersection boundary of the cube and crossbeam
            Reference intersectRef = CalculateIntersectionFromCubePrimStruct(tmpPartDoc, hbFactory);

            if (intersectRef is null)
            {
                Log.Error($"Cube PrimStruct Dist: cube({cubeProd.get_Name()}) is not intesecting prim structure({primStructProd.get_Name()})");
                return 2003;
            }

            // Create intersection boundary and calculate distance from cube cog to the boundary
            try
            {
                tmpPartDoc.Part.InWorkObject = checkHbBody;
                HybridShapeFill intersectBoundary = hbFactory.AddNewFill();
                intersectBoundary.AddBound(intersectRef);
                intersectBoundary.Continuity = 1;
                intersectBoundary.Detection = 2;
                intersectBoundary.AdvancedTolerantMode = 2;
                intersectBoundary.Compute();
                intersectBoundary.set_Name("Fill.INTERSECTION SURFACE OF IP CUBE AND CROSS BEAM");
                checkHbBody.AppendHybridShape(intersectBoundary);
                Reference intersectFaceRef = tmpPartDoc.Part.CreateReferenceFromObject(intersectBoundary);

                Measurable measure = partSpaWorkBench.GetMeasurable(intersectFaceRef);
                double minDist = measure.GetMinimumDistance(refCog);
                return minDist;
            }
            catch
            {
                Log.Error($"Cube PrimStruct Dist: Internal error by creating intersect boundary and dist calculation cube cog to intesection surface)");
                return 2004;
            }
        }

        private static Reference CalculateIntersectionFromCubePrimStruct(PartDocument tmpPartDoc, HybridShapeFactory hbFactory)
        {
            Body firstBodyForIntersection = null;
            Body secondBodyForIntersection = null;
            foreach (Body body in tmpPartDoc.Part.Bodies)
            {
                if (body.Shapes.Count == 1)
                {
                    Shape shape = body.Shapes.Item(1);
                    if (shape.get_Name().StartsWith("Solid"))
                    {
                        if (firstBodyForIntersection is null)
                        {
                            firstBodyForIntersection = body;
                            continue;
                        }
                        else if (secondBodyForIntersection is null)
                        {
                            secondBodyForIntersection = body;
                            break;
                        }
                    }
                }
            }

            Reference cubeRef = tmpPartDoc.Part.CreateReferenceFromObject(firstBodyForIntersection);
            Reference crossBeamRef = tmpPartDoc.Part.CreateReferenceFromObject(secondBodyForIntersection);

            //Reference crossBeamRef = partDoc.Part.CreateReferenceFromObject(partDoc.Part.Bodies.Item(3));
            //Reference cubeRef = partDoc.Part.CreateReferenceFromObject(partDoc.Part.Bodies.Item(4));

            Reference intersectRef = null;
            try
            {
                //HybridShapeIntersection intersectBody = hbFactory.AddNewIntersection(refSphere, crossBeamRef);
                HybridShapeIntersection intersectBody = hbFactory.AddNewIntersection(cubeRef, crossBeamRef);
                tmpPartDoc.Part.Update();
                intersectRef = tmpPartDoc.Part.CreateReferenceFromObject(intersectBody);
            }
            catch
            {

            }

            return intersectRef;
        }

        private static Reference CopyCubePrimStructToTmpPart(Selection selection, Product cubeProd, Product crossBeamProd,
            string pathCube, string pathCrossbeam, PartDocument tmpPartDoc, HybridShapeFactory hbFactory, HybridBody checkHbBody)
        {
            //tmpPartDoc.Part.InWorkObject = tmpPartDoc.Part.MainBody;
            Part crossBeamPart = ((PartDocument)crossBeamProd.ReferenceProduct.Parent).Part;
            Part cubePart = ((PartDocument)cubeProd.ReferenceProduct.Parent).Part;

            // Publish cube and crossbeam main body
            //PublishFirstBody(cubeProd, cubePart, pathCube);
            //PublishFirstBody(crossBeamProd, crossBeamPart, pathCrossbeam);

            HybridShapePointCoord pointOfCog = CreatePartCogPoint(cubeProd, tmpPartDoc, hbFactory, checkHbBody);

            Reference refCog = tmpPartDoc.Part.CreateReferenceFromObject(pointOfCog);
            HybridShapeSphere cogSphere = hbFactory.AddNewSphere(refCog, null, 2.5, -90, 90, 0, 360);
            // value 1 for whole sphere
            cogSphere.Limitation = 1;
            checkHbBody.AppendHybridShape(cogSphere);
            tmpPartDoc.Part.UpdateObject(cogSphere);
            Reference refSphere = tmpPartDoc.Part.CreateReferenceFromObject(cogSphere);

            selection.Clear();
            //selection.Add((AnyObject)cubeProd.Publications.Item(publishName).Valuation);
            //selection.Add((AnyObject)crossBeamProd.Publications.Item(publishName).Valuation);
            selection.Add(GetReferenceToRootFirstBody(cubePart, pathCube));
            selection.Add(GetReferenceToRootFirstBody(crossBeamPart, pathCrossbeam));
            // DO NOT use part reference as source, if multiple instance exists in product, random 
            // instance will be used as source (Different absolute position). No predictable results.
            //selection.Add((Body)crossBeamPart.MainBody);
            //selection.Add((Body)cubePart.MainBody);
            selection.Copy();
            selection.Clear();
            selection.Add(tmpPartDoc.Part);
            //selection.PasteSpecial("CATPrtResult");//CATPrtResultWithOutLink
            selection.PasteSpecial("CATPrtResultWithOutLink");
            selection.Clear();
            tmpPartDoc.Part.Update();
            //tmpPartDoc.Part.InWorkObject = tmpPartDoc.Part.MainBody;
            return refCog;
        }

        /// <summary>
        /// Publish the first Body in the product against root Product
        /// Absolute position will be applied on the published Body
        /// </summary>
        /// <param name="prod">The product of the part</param>
        /// <param name="part">The reference part</param>
        /// <param name="pathProduct">The path from root to the product</param>
        private static void PublishFirstBody(Product prod, Part part, string pathProduct, string objectType = null)
        {
            // Publish the part body
            Publication bodyPub = null;
            try
            {
                bodyPub = prod.Publications.Item(publishName);

                // We must unpublish the existing one before we can publish a new instance
                // Otherwise we will use the old published part which will lead to error
                if (null != bodyPub)
                {
                    prod.Publications.Remove(publishName);
                    bodyPub = null;
                }
                bodyPub = prod.Publications.Item(publishName);
            }
            catch
            {
                if (bodyPub is null)
                {
                    Reference refBody = GetReferenceToRootFirstBody(part, pathProduct, objectType);
                    if (refBody is null)
                    {
                        return;
                    }
                    bodyPub = prod.Publications.Add(publishName);
                    prod.Publications.SetDirect(publishName, refBody);
                }
            }
        }

        private static Reference GetReferenceToRootFirstBody(AnyObject obj, string pathProduct, string objectType = null)
        {
            // Most important: the reference path need to meet the reference created in the next step
            // If we have reference name: root001/prod002/!partbody001, then we need to created 
            // reference from the root product.
            // If we use prod002/!partbody001 and create reference from prod002.CreateReferenceFromName
            // We will have the body created at zero axis and not the absolute position.
            // If we use prod002/!parbody001 and create reference from root001, then no real publication 
            // will be created.
            //string refName = pathProduct + "!" + part.Bodies.Item(1).get_Name();
            string refName = "";

            if (objectType == "AnyObject")
            {
                refName = pathProduct;
            }
            else
            {
                if (obj is Part)
                {
                    refName = pathProduct + "!" + ((Part)obj).MainBody.get_Name();
                }
                else
                {
                    refName = pathProduct + "!" + obj.get_Name();
                }
            }

            if (refName.Length > 0)
            {
                Reference refBody = CatiaCommonUtils.GetActiveRootProd().CreateReferenceFromName(refName);
                return refBody;
            }
            return null;
        }

        private static Product FeedThroughSingleSecondaryDistCheck(IpvCheckProperty property, String ipPartnumber, NotificationStoreBase notifStore, Selection selection,
            ProductDocument rootDoc, Product drumProd,
            Product cubeProd, Product primStructProd, double tolerance, ref int result)
        {
            // Add temp product under root product for calculation, publish all needed part bodies and copy them to temp part for later use
            PartDocument tempPartDoc = null;
            HybridBodies tempGeoSet = null;

            Product tempProduct = null;
            result = TryCreateTempProduct(property, selection, rootDoc, drumProd, cubeProd,
                primStructProd, ref tempProduct, ref tempPartDoc, ref tempGeoSet);

            if (result > 0)
            {
                return tempProduct;
            }

            Bodies tempPartBodies = tempPartDoc.Part.Bodies;
            Body bodySecondary = tempPartBodies.Item(2);
            Body bodyPrim = tempPartBodies.Item(3);
            Body bodyIpCube = tempPartBodies.Item(4);
            HybridShapeFactory hbFactory = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;
            ShapeFactory shapeFactory = (ShapeFactory)tempPartDoc.Part.ShapeFactory;
            SPAWorkbench spaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");

            // CREATE THE NECESSARY GEOMETRICAL SETS
            HybridBody checkHbBody = tempGeoSet.Add();
            checkHbBody.set_Name("Dummy_Elements_For_Check");
            HybridBody axisHbBody = tempGeoSet.Add();
            axisHbBody.set_Name("Dummy_Axis_Lines_Generated_For_Check");
            HybridShapePointCoord pointOfCog;
            HybridBody nonPfHbBody = tempGeoSet.Add();
            nonPfHbBody.set_Name("Dummy_Extract_Of_Non_Planar_Drum_Face");
            HybridBody nonPfHbExtractBoundBody = tempGeoSet.Add();
            nonPfHbExtractBoundBody.set_Name("Dummy_Extract_Of_Drum_Boundary");
            HybridBody centerPtHbBody = tempGeoSet.Add();
            centerPtHbBody.set_Name("Dummy_Center_Points_Drum_Edges");
            HybridBody intSolidFacesHbBody = tempGeoSet.Add();
            intSolidFacesHbBody.set_Name("Dummy_Extracts_Of_Intersected_Solid_Faces");
            HybridBody edgOfFtHoleHbBody = tempGeoSet.Add();
            edgOfFtHoleHbBody.set_Name("Dummy_Edges_Of_FeedThrough_Hole_Face");
            tempPartDoc.Part.Update();

            // CREATE AN AXIS LINE FROM NON PLANAR SURFACE TO GET THE RADIUS
            string partnumber = "";
            HybridShapeLinePtPt axisLineOfDrum;
            CreateAxisLineForNonPlanarSurfaceOfDrum(selection, drumProd, bodySecondary, hbFactory, nonPfHbBody,
                centerPtHbBody, checkHbBody, nonPfHbExtractBoundBody, tempPartDoc, partnumber, out axisLineOfDrum);

            // 3.2 Calculate drum radius, we will double it as the radium for sphere in later process
            double drumRadius;
            notifStore.ProgressValue += 10;
            int retValue = CalulateDrumRadiusMajorAxis(bodySecondary, selection, spaWorkBench, tempPartDoc,
                axisLineOfDrum, hbFactory, nonPfHbBody, nonPfHbExtractBoundBody, out drumRadius);
            if (retValue > 0)
            {
                Log.Error($"Feedthrough 2.5mm check: Drum radius({drumRadius}) is too small.");
                result = 3002;
            }
            else
            {
                Log.Information($"Feedthrough 2.5mm check: Original drum radius({drumRadius}) for bounding cube (2xradius)");
                // 3.3 Create Bounding Box using cog of cube with 2xradius and calculate the intersection with cross
                Body bodyBoundingBox;
                retValue = CreateBoundingBoxAndIntersectWithCrossbeam(cubeProd, tempPartDoc, hbFactory, shapeFactory, drumRadius,
                                checkHbBody, out pointOfCog, out partnumber, out bodyBoundingBox);
                if (retValue > 0)
                {
                    result = retValue;
                    return tempProduct;
                }
                notifStore.ProgressValue += 10;

                //CreateSphereAndIntersectWithCrossbeam(cubeProd, primStructProd, selection, partDoc,
                //    hbFactory, shapeFactory, drumRadius, checkHbBody, out pointOfCog, out partnumber);

                // 3.4 Compute cylinderic/elliptic surface of the intersected part and we should get only one axis
                // which is the axis of the feedthrough hole. The axis will be added to axisHbBody.
                //edited to create axis line 1st
                ComputeAxisOfFeedthroughHole(selection, bodyBoundingBox, hbFactory, intSolidFacesHbBody, edgOfFtHoleHbBody, axisHbBody, spaWorkBench, tempPartDoc);
                notifStore.ProgressValue += 10;

                if (axisHbBody.HybridShapes.Count > 1)
                {
                    Log.Error($"Feedthrough 2.5mm check: More than one cylinderic/elliptic surface is found after bounding box intersecting prim struct");
                    result = 3003;
                }
                else
                {
                    // 3.5 Last step. Compute the distance of the cube cog to the axis, should be smaller than tolerance
                    foreach (var axisShape in axisHbBody.HybridShapes)
                    {
                        result = Math.Max(result, CheckMinDistCubeCogAxisLine(property, tempPartDoc, tolerance, axisShape,
                            bodyIpCube, bodyPrim, bodySecondary, ipPartnumber));
                    }
                }
            }

            return tempProduct;
        }

        private static int CheckMinDistCubeCogAxisLine(IpvCheckProperty property, PartDocument tempPartDoc,
            double tolerance, object axisShape, Body bodyIpCube, Body bodyPrim, Body bodySecondary, string ipPartnumber)
        {
            int result = 1;
            SPAWorkbench spaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
            Reference lineRef = tempPartDoc.Part.CreateReferenceFromObject((AnyObject)axisShape);
            Measurable measureLineRef = spaWorkBench.GetMeasurable(lineRef);
            HybridShapeFactory hbFactory = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;

            HybridBodies hybridBodies = tempPartDoc.Part.HybridBodies;
            HybridBody checkHbBody = hybridBodies.Add();
            checkHbBody.set_Name("Dummy_Elements_For_Check");
            //HybridShapePointCoord pointOfCog = CreatePartCogPoint(bodyIpCube, tempPartDoc, hbFactory, checkHbBody);
            HybridShapePointCoord pointOfCog = CreateCogFromBody(tempPartDoc.Part, hbFactory, spaWorkBench, bodyIpCube);
            checkHbBody.AppendHybridShape(pointOfCog);
            tempPartDoc.Part.Update();

            Reference refCog = tempPartDoc.Part.CreateReferenceFromObject(pointOfCog);

            double minDist = measureLineRef.GetMinimumDistance(refCog);
            double minDistRound = Math.Round(minDist, 3);
            if (minDistRound <= tolerance + EPSILON)
            {
                result = 0;
                Log.Information($"2.5mm check: Min Distance from one cube cog to the axes line is {minDist}, within tolerance {Math.Round(tolerance + EPSILON, 3)}");
            }
            else
            {
                string errorMsg = $"The minimum distance between a cube COG and the axis is {minDistRound}mm, " +
                    $"violation of tolerance value {Math.Round(tolerance + EPSILON, 3)}mm";
                Log.Error(errorMsg);
                Reference cubeRef = tempPartDoc.Part.CreateReferenceFromObject(bodyIpCube);
                CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrim, bodySecondary, bodyIpCube, bodySecondary,
                    cubeRef, ipPartnumber, "2Dot5mm", errorMsg, property);
            }

            return result;
        }

        private static int CheckMinDistCubeFacesAxisLine(IpvCheckProperty property, PartDocument tempPartDoc,
            double tolerance, object axisShape, Body bodyIpCube, Body bodyPrim, Body bodySecondary, string ipPartnumber)
        {
            int result = 1;
            SPAWorkbench spaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
            Reference lineRef = tempPartDoc.Part.CreateReferenceFromObject((AnyObject)axisShape);
            Measurable measureLineRef = spaWorkBench.GetMeasurable(lineRef);

            List<Face> listSelectedFaces;
            List<string> listSelectedTypes;
            GetAllFacesOfBody(tempPartDoc, bodyIpCube, out listSelectedFaces, out listSelectedTypes);

            int okResultFaceCount = 0;
            int faceCount = listSelectedFaces.Count;
            foreach (Face face in listSelectedFaces)
            {
                double minDist = measureLineRef.GetMinimumDistance(face);
                double minDistRound = Math.Round(minDist, 3);
                if (minDistRound == 0.0)
                {
                    continue;
                }

                double angle = measureLineRef.GetAngleBetween(face);
                double angleRound = Math.Abs(Math.Round(angle, 3) % 90.0);
                double angleDist = 0.0;
                if (faceCount == 6)
                {
                    angle = 0.0;
                    angleRound = 0.0;
                }
                if (faceCount == 14)
                {
                    angleDist = 5.0;
                }

                if (Math.Abs(minDistRound - 2.5) <= tolerance + EPSILON && angleRound < angleDist + EPSILON)
                {
                    okResultFaceCount++;
                    Log.Information($"2.5mm check: Min Distance from one cube face " +
                        $"to the axes line is {minDist}");
                }
                else if (Math.Abs(minDistRound) > EPSILON && angleRound < angleDist + EPSILON)
                {
                    string errorMsg = $"The minimum distance between a cube face and the axis is {minDistRound}mm, " +
                        $"violation of tolerance range 2.5+-{tolerance + EPSILON}mm";
                    Log.Error(errorMsg);
                    Reference cubeRef = tempPartDoc.Part.CreateReferenceFromObject(bodyIpCube);
                    CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrim, bodySecondary, bodyIpCube, bodySecondary,
                        cubeRef, ipPartnumber, "2Dot5mm", errorMsg, property);
                }
                else
                {
                    string errorMsg = $"The minimum distance is {minDistRound}mm, target " +
                        $"tolerance range 2.5+-{tolerance + EPSILON}mm. Angle between axis line and face is {angleRound}°";
                    Log.Debug(errorMsg);
                }
            }

            // All four side faces should have correct distance to the axes line, for cube with 14 faces, we check 12
            if (okResultFaceCount == 4)
            {
                result = 0;
            }

            return result;
        }

        private static int Hole2dot5mmSingleCheck(IpvCheckProperty property, NotificationStoreBase notifStore, string ipPartnumber, double tolerance
            , ProductDocument rootDoc, HashSet<Product> clashedCubes, Product cylinderProd, bool isTrend)
        {
            int result = 0;
            Log.Information($"Hole 2.5mm check: start check for instance ({cylinderProd.get_Name()})");

            Selection selection = rootDoc.Selection;

            string ipNumberForTrend = (isTrend) ? ipPartnumber : null;

            // Calculate the cube and the crossbeam that we need to check
            Product cubeProd = null;
            Product primStructProd = null;
            IpvClashResult clashResult = ComputeClash(property, cylinderProd, ref cubeProd, ref primStructProd, ipNumberForTrend);

            result = CheckPrimStruct(property, notifStore, cylinderProd, ref primStructProd, clashResult, "Hole 2.5mm check");
            if (result > 0)
            {
                return result;
            }

            if (cubeProd is null || primStructProd is null)
            {
                Log.Information($"Hole 2.5mm check: check failed - no clashed cube or prim struct found");
                return 2005;
            }

            clashedCubes.Add(cubeProd);

            PartDocument tempPartDoc = null;
            HybridBodies tempGeoSet = null;
            Product tempProduct = null;

            result = TryCreateTempProduct(property, selection, rootDoc, cylinderProd, cubeProd,
                primStructProd, ref tempProduct, ref tempPartDoc, ref tempGeoSet);

            if (result > 0)
            {
                return result;
            }

            try
            {
                Bodies tempPartBodies = tempPartDoc.Part.Bodies;
                Body bodySecondary = (Body)tempPartBodies.GetItem("SECONDARY");
                Body bodyPrim = (Body)tempPartBodies.GetItem("STRUCTURE");
                Body bodyIpCube = (Body)tempPartBodies.GetItem("IP_CUBE");
                HybridShapeFactory hbFactory = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;
                ShapeFactory shapeFactory = (ShapeFactory)tempPartDoc.Part.ShapeFactory;
                SPAWorkbench spaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");

                // 2.1 Calculate center points on top and bottom surface of the cylinder, should have 2 results
                List<double[]> centerList = GetCylinderCenters(rootDoc, spaWorkBench, selection, cylinderProd);
                if (centerList.Count == 2)
                {
                    // 2.2 Cylinder center line (axis) and cube cog should be on the same line
                    // After this step, we checked 4 faces of the cube, the remaining 2 faces will be checked next
                    //result = HoleSecondaryDistCheck(centerList, cubeProd, tolerance, ref errorMsg);

                    // Create the axis line from two center point from the cylinder
                    Point center1CylinderFace = hbFactory.AddNewPointCoord(centerList[0][0], centerList[0][1], centerList[0][2]);
                    Point center2CylinderFace = hbFactory.AddNewPointCoord(centerList[1][0], centerList[1][1], centerList[1][2]);
                    HybridShapeLinePtPt axisLineOfCylinder = hbFactory.AddNewLinePtPt(center1CylinderFace as Reference, center2CylinderFace as Reference);
                    axisLineOfCylinder.Compute();

                    result = CheckMinDistCubeCogAxisLine(property, tempPartDoc, tolerance, axisLineOfCylinder,
                        bodyIpCube, bodyPrim, bodySecondary, ipPartnumber);
                }
                else
                {
                    Log.Error($"Hole 2.5mm check: Not exact 2 center points are found on cylinder. " +
                        $"PartNum:{cylinderProd.get_PartNumber()} Count: {centerList.Count}");
                    result = 2006;
                }

                if (result == 0)
                {
                    // 2.3 Check the remaining 2 faces of the cube
                    // check the axis against crossbeam surface
                    // Calculate path string for cube againt root, trafo is not used here
                    double[] absTrafoCube = new double[12];
                    string pathCube = "";
                    CatiaProdUtils.GetAbsTrafo(cubeProd, rootDoc.Product, ref absTrafoCube, ref pathCube);

                    // Calculate path string for crossbeam againt root, trafo is not used here
                    double[] absTrafoPrimStruct = new double[12];
                    string pathPrimStruct = "";
                    CatiaProdUtils.GetAbsTrafo(primStructProd, rootDoc.Product, ref absTrafoPrimStruct, ref pathPrimStruct);

                    if (cubeProd != null && primStructProd != null)
                    {
                        // Main step, calculate cube distance against prime structure surface
                        double minDist = CalculateCubePrimStructDistance(selection, tempProduct, cubeProd,
                            primStructProd, absTrafoCube, pathCube, pathPrimStruct);
                        double targetDist = tolerance + EPSILON;

                        if (Math.Abs(minDist) > targetDist)
                        {
                            Log.Error($"Hole 2.5mm check: check failed (surface dict) - min Dist({minDist}) is greater than tolerance {targetDist}");

                            Body cylinderBody = GetPart(cylinderProd).MainBody;
                            Body primBody = GetPart(primStructProd).MainBody;
                            Body cubeBody = GetPart(cubeProd).MainBody;

                            Reference cubeRef = tempPartDoc.Part.CreateReferenceFromObject(bodyIpCube);

                            string error = $"Hole 2.5mm check failed, min distance between prim struct and cube cog is {Math.Round(minDist, 4)}mm greater than tolerant {targetDist}mm";
                            string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(primBody, cylinderBody, cubeBody, null,
                                cubeRef, ipPartnumber, "hole2_5mm", error, property);
                            result = 3;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                result = 1000;
                Log.Warning($"Internal execption during Hole2dot5mmSingleCheck, check will continue. {e.ToString()}");
            }

            // clean up the product structure
            CleanupProdStruct(selection, rootDoc, cylinderProd, cubeProd, primStructProd, tempProduct);

            return result;
        }

        private static int PrepareTempPartsForCalculation(IpvCheckProperty property, Selection selection, ProductDocument rootDoc, Product secondaryProd,
            Product cubeProd, Product primStructProd, out Product tempProduct, out PartDocument tempPartDoc, out HybridBodies tempGeoSet,
            bool isStandard = true, bool isPitchDistCheck = false, string pitchDistanceType = null)
        {
            int retValue = 0;

            // Add temp product under root product for calculation and copy cube and crossbean into it
            tempProduct = rootDoc.Product.Products.AddNewComponent("Product", "");
            Product tempPart = tempProduct.Products.AddNewComponent("Part", "");
            tempPartDoc = (PartDocument)tempPart.ReferenceProduct.Parent;
            HybridBodies hybridBodies = tempPartDoc.Part.HybridBodies;

            // Combine bodies for secondary only for standard bracket check
            List<AnyObject> newAddedBodyList = PrepareTempPartsCombineBodies(secondaryProd, property);

            // Publish ipCube body
            Part cubePart = ((PartDocument)cubeProd.ReferenceProduct.Parent).Part;
            double[] absTrafoCube = new double[12];
            string pathCube = "";
            CatiaProdUtils.GetAbsTrafo(cubeProd, rootDoc.Product, ref absTrafoCube, ref pathCube);
            //if (null != cubeProd)
            //{
            //    PublishFirstBody(cubeProd, cubePart, pathCube);
            //}

            // Publish primary structure body
            Part crossBeamPart = ((PartDocument)primStructProd.ReferenceProduct.Parent).Part;
            double[] absTrafoPrimaryProd = new double[12];
            string pathPrimaryProd = "";
            CatiaProdUtils.GetAbsTrafo(primStructProd, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoPrimaryProd, ref pathPrimaryProd);
            //PublishFirstBody(primStructProd, crossBeamPart, pathPrimaryProd);

            // Publish secondary (cylinder/Drum/Bracket/etc.) body
            Part secondaryPart = ((PartDocument)secondaryProd.ReferenceProduct.Parent).Part;
            double[] absTrafoSecondaryProd = new double[12];
            string pathSecondaryProd = "";
            CatiaProdUtils.GetAbsTrafo(secondaryProd, rootDoc.Product, ref absTrafoSecondaryProd, ref pathSecondaryProd);
            //PublishFirstBody(secondaryProd, secondaryPart, pathSecondaryProd);

            int partIndex = 1;
            //selection.Add((AnyObject)secondaryProd.Publications.Item(publishName).Valuation);
            //selection.Add((AnyObject)primStructProd.Publications.Item(publishName).Valuation);

            CopyPartAbsPosNewBody(selection, tempPartDoc, secondaryPart, pathSecondaryProd, ref partIndex, "SECONDARY");
            CopyPartAbsPosNewBody(selection, tempPartDoc, crossBeamPart, pathPrimaryProd, ref partIndex, "STRUCTURE");
            if (null != cubeProd)
            {
                CopyPartAbsPosNewBody(selection, tempPartDoc, cubePart, pathCube, ref partIndex, "IP_CUBE");
            }

            selection.Clear();
            selection.Add(primStructProd);
            selection.Add(secondaryProd);
            if (null != cubeProd)
            {
                selection.Add(cubeProd);
            }
            selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            selection.Clear();
            tempPartDoc.Part.Update();

            // CREATE THE NECESSARY GEOMETRICAL SETS
            HybridBody dummyGeometricalSet = hybridBodies.Add();
            dummyGeometricalSet.set_Name("DUMMY WORKING ELEMENTS");
            tempGeoSet = dummyGeometricalSet.HybridBodies;
            HybridBody bracketFacesGeometricalSet = tempGeoSet.Add();
            bracketFacesGeometricalSet.set_Name("BRACKET FACES");

            if (isPitchDistCheck)
            {
                if (pitchDistanceType.ToLower().Contains("cutout"))
                {
                    // Search for Hnf Instances in Primary Structure and add EXTRACT GEOMETRY
                    retValue = PrepareNonStdPartWithHnfInstances(selection, tempPartDoc, primStructProd, hybridBodies, false);

                    if (retValue > 0)
                    {
                        return retValue;
                    }
                }
                else
                {
                    // Preparing for pitch distance check with STD parts
                    PrepareForPitchDistanceWithStdParts(rootDoc, secondaryProd, hybridBodies, false);
                }

            }

            // Search for Hnf Instances in non-std brackets and add EXTRACT GEOMETRY
            retValue = PrepareNonStdPartWithHnfInstances(selection, tempPartDoc, secondaryProd, hybridBodies, true);
            if (retValue > 0)
            {
                return retValue;
            }

            //extract face from main part body insted of copied bracket, we will always using this for both std and none std
            PrepareBracketWithMergedFace(selection, rootDoc, secondaryProd, bracketFacesGeometricalSet);
            // prepare extra faces of stds for none standard bracket 2.5mm check, we are sure we will have BFH node in PS
            if (property.IsBracketCheck && !isStandard && property.Is2Dot5mmCheck)
            {
                List<string> filter = new List<string>();
                // add all adf part number and string for cube into the exclude filter
                filter.AddRange(GetProposalPartNumTrend(property.SecondaryNameList, AdfPart));
                filter.Add("cub");

                Product parentProduct = CatiaProdUtils.GetParentProduct(secondaryProd);
                IList<Product> extraProdsUnderBfhNode = CatiaProdUtils.GetAllChildNodesExcludeFilters(parentProduct, filter);

                foreach (Product prod in extraProdsUnderBfhNode)
                {
                    PrepareBracketWithMergedFace(selection, rootDoc, prod, bracketFacesGeometricalSet);
                }
            }

            // remove added bodies from the main part body
            if (newAddedBodyList.Any())
            {
                foreach (var itemToDelete in newAddedBodyList)
                {
                    selection.Add(itemToDelete);
                }
                selection.Delete();
                selection.Clear();
            }

            tempPartDoc.Part.Update();
            return retValue;
        }

        /// <summary>
        /// copy part main body/other object type to new part with the same absolute position.
        /// </summary>
        /// <param name="selection"></param>
        /// <param name="targetPartDoc"></param>
        /// <param name="sourcePart">the source part which main body will be copied</param>
        /// <param name="partPath">The path to the root product</param>
        /// <param name="bodyIndex">index of the body location, need to be exact, will be increased by one</param>
        /// <param name="bodyName">Specifiy the name of the copied body</param>
        private static void CopyPartAbsPosNewBody(Selection selection, PartDocument targetPartDoc, 
            Part sourcePart, string partPath, ref int bodyIndex, string bodyName)
        {
            selection.Clear();
            selection.Add(GetReferenceToRootFirstBody(sourcePart, partPath));
            bodyIndex++;
            selection.Copy();
            selection.Clear();
            selection.Add(targetPartDoc.Part);
            selection.PasteSpecial("CATPrtResultWithOutLink");

            if (!string.IsNullOrWhiteSpace(bodyName))
            {
                Body newBody = targetPartDoc.Part.Bodies.Item(bodyIndex);
                newBody.set_Name(bodyName);
            }
        }

        private static List<AnyObject> PrepareTempPartsCombineBodies(Product secondaryProd, IpvCheckProperty property)
        {
            // ADD ALL BODIES INTO PART BODY IN SECONDARY (Bracket part may have several bodies) PART DOCUMENT
            PartDocument partDocumentSecondary = (PartDocument)secondaryProd.ReferenceProduct.Parent;
            Part partBracketPartDocument = partDocumentSecondary.Part;
            Bodies bodiesBracketPartDocument = partBracketPartDocument.Bodies;

            List<AnyObject> newAddedBodyList = new List<AnyObject>();
            if (bodiesBracketPartDocument.Count > 1 && property.IsBracketCheck && property.IsStandard)
            {
                ShapeFactory shapeFactoryBracketPartDocument = (ShapeFactory)partBracketPartDocument.ShapeFactory;
                Body mainBodyBracketPartDocument = partBracketPartDocument.MainBody;
                foreach (Body eachBodyInBracketPartDocument in bodiesBracketPartDocument)
                {
                    partBracketPartDocument.InWorkObject = mainBodyBracketPartDocument;
                    try
                    {
                        Add addEachBody = shapeFactoryBracketPartDocument.AddNewAdd(eachBodyInBracketPartDocument);
                        partBracketPartDocument.UpdateObject(mainBodyBracketPartDocument);
                        newAddedBodyList.Add(addEachBody);
                    }
                    catch (Exception)
                    {
                        Log.Information($"PrepareTempPartsForCalculation: exception happens by combining all bodies to main part");
                    }
                }
            }

            return newAddedBodyList;
        }

        private static void PrepareForPitchDistanceWithStdParts(ProductDocument rootDoc, Product secondaryProd,
            HybridBodies hybridBodies, bool isBracketType)
        {

            // ASK USER TO SELECT STD PRODUCTS
            string msgText = "Please select the STD01 & STD02 CAD NODES...";
            Selection selection = rootDoc.Selection;
            selection.Clear();

            object[] productFilter = new object[1] { "Product" };

            string status = rootDoc.Selection.SelectElement3(productFilter, msgText, false,
                            CATMultiSelectionMode.CATMultiSelTriggWhenUserValidatesSelection, true);

            if (status == "Cancel" || selection.Count2 == 0)
            {
                return;
            }

            List<Product> listStdCadNodeProducts = ValidationPitchDistSelection(ref msgText, selection);

            // LOOP THROUGH ALL STD CAD NODES IN LIST
            foreach (Product productStdCadNode in listStdCadNodeProducts)
            {
                //PartDocument documentStdCadNode = (PartDocument)productStdCadNode.ReferenceProduct.Parent;
                PartDocument documentStdCadNode;
                Part part;
                List<CatiaHnfUtils> listStdCadNodeHnfInstances = GetAllHnfInstancesFromPartDocument(selection, productStdCadNode, out documentStdCadNode, out part);

                // IF HNF FOUND IN STD CAD NODE PART
                if (listStdCadNodeHnfInstances.Count == 0)
                {
                    continue;
                }

                HybridBody hnfGeometryExtractionGeometricalSet = null;
                HybridBody hnfHoleSurfacesGeometricalSet = null;
                HybridBody hnfHoleSurfacesforPSGeometricalSet = null;

                // Build assembled_hnf_holes_surface in part document 
                var assembledHnfHolesSurface = BuildAssembledHnfHolesSurfaceInPartDocument(documentStdCadNode, hybridBodies,
                    listStdCadNodeHnfInstances, false, ref hnfHoleSurfacesGeometricalSet, ref hnfGeometryExtractionGeometricalSet,
                                    ref hnfHoleSurfacesforPSGeometricalSet);   //isBracketType

                // CREATE REFERENCE OF ASSEMBLED HOLE SURFACES WRT ROOT PRODUCT
                // Publish BRACKET/STRUCTURE HOLE SURFACE
                double[] absTrafoBracketHoleSurface = new double[12];
                string pathabsTrafoBracketHoleSurface = "";
                CatiaProdUtils.GetAbsTrafo(productStdCadNode, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoBracketHoleSurface, ref pathabsTrafoBracketHoleSurface);
                pathabsTrafoBracketHoleSurface = pathabsTrafoBracketHoleSurface + "!" + assembledHnfHolesSurface.get_Name();

                HybridBody hybridBodyForFace;

                if (isBracketType)
                {
                    hybridBodyForFace = hnfHoleSurfacesGeometricalSet;
                }
                else
                {
                    hybridBodyForFace = hnfHoleSurfacesforPSGeometricalSet;
                }

                // COPY REFERENCE AND PASTE INTO DUMMY PART
                selection.Clear();
                //selection.Add((AnyObject)bracketPartDocument.Product.Publications.Item(publishName).Valuation);
                selection.Add(GetReferenceToRootFirstBody(assembledHnfHolesSurface, pathabsTrafoBracketHoleSurface, "AnyObject"));
                selection.Copy();
                selection.Clear();
                selection.Add(hybridBodyForFace);
                selection.PasteSpecial("CATPrtResultWithOutLink");
                selection.Clear();

                // Delete GEOMETRICAL SET created in main part document.
                selection.Clear();
                selection.Add(hnfGeometryExtractionGeometricalSet);
                selection.Delete();
                selection.Clear();
            }
        }

        private static List<Product> ValidationPitchDistSelection(ref string msgText, Selection selection)
        {
            // LOOP THROUGH SELECTION AND APPEND STD PRODUCTS INTO A LIST IF NOMENCLATURE IS CADNODE
            List<Product> listStdCadNodeProducts = new List<Product>();
            for (int i = 1; i <= selection.Count2; i++)
            {
                Product selectedProduct = (Product)selection.Item2(i).Value;

                // PUT SELECTED STD CAD NODE PRODUCT IN DESIGN MODE IF NOT
                try
                {
                    string partNumber = selectedProduct.get_PartNumber();
                }
                catch (Exception)
                {
                    selectedProduct.ApplyWorkMode(CatWorkModeType.DESIGN_MODE);
                }

                // CHECK IF THE PRODUCT NOMENCLATURE IS CADNODE
                bool isNonValidElementsSelectedByUser = false;
                if (selectedProduct.get_Nomenclature().ToLower() == "cadnode")
                {
                    string docName = ((PartDocument)selectedProduct.ReferenceProduct.Parent).get_Name();
                    if (docName.IndexOf("CATProduct") == -1)
                    {
                        listStdCadNodeProducts.Add(selectedProduct);
                    }
                    else
                    {
                        isNonValidElementsSelectedByUser = true;
                    }
                }
                else
                {
                    isNonValidElementsSelectedByUser = true;
                }

                // validation to show warning message to end user
                if (isNonValidElementsSelectedByUser)
                {
                    msgText = "At least 1 of the element you selected is not valid STD01 or STD02 CADNODE.";
                    msgText += "\nFollowing products will be taken into account in pitch distance checks:";
                    foreach (Product productStdCadNode in listStdCadNodeProducts)
                    {
                        msgText += $"\n --- {productStdCadNode.get_Name() as string}";
                    }
                    MessageBox.Show(msgText, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }

            return listStdCadNodeProducts;
        }

        private static void PrepareBracketWithMergedFace(Selection selection, ProductDocument rootDoc, Product secondaryProd,
                    HybridBody bracketFacesGeometricalSet)
        {
            if (secondaryProd is null || secondaryProd.ReferenceProduct is null ||
                !(secondaryProd.ReferenceProduct.Parent is PartDocument))
            {
                return;
            }

            PartDocument partDocumentSecondary = (PartDocument)secondaryProd.ReferenceProduct.Parent;
            Part partBracketPartDocument = partDocumentSecondary.Part;
            Body mainBodyBracketPartDocument = partBracketPartDocument.MainBody;

            // CREATE A GEOMETRICAL SET IN BRACKET PART DOCUMENT TO STORE FACE EXTRACTS
            HybridBodies hybridBbodiesBracket = partBracketPartDocument.HybridBodies;
            HybridBody bracketMainBodyFaceExtractGeometricalSet = hybridBbodiesBracket.Add();
            bracketMainBodyFaceExtractGeometricalSet.set_Name("FACE EXTRACTS");

            // FIND ALL FACES OF BRACKET MAIN BODY
            // AND CREATE AN EXTRACT FOR EACH OF THEM
            HybridShapeFactory hsfBracket = (HybridShapeFactory)partBracketPartDocument.HybridShapeFactory;
            selection.Clear();
            selection.Add(mainBodyBracketPartDocument);
            selection.Search("Topology.Face,sel");
            List<Reference> listBracketMainBodyFaceReferences = new List<Reference>();

            for (int i = 1; i <= selection.Count2; i++)
            {
                Reference selectedFace = (Reference)selection.Item2(i).Value;
                HybridShapeExtract extractBracketMainBodyFace = hsfBracket.AddNewExtract(selectedFace);
                extractBracketMainBodyFace.PropagationType = 2;
                extractBracketMainBodyFace.Compute();
                bracketMainBodyFaceExtractGeometricalSet.AppendHybridShape(extractBracketMainBodyFace);

                SPAWorkbench spaWorkbench = (SPAWorkbench)rootDoc.GetWorkbench("SPAWorkbench");

                bool isCutout = CheckIfFaceIsCylindricalOrEllipticalCutOut(partBracketPartDocument, spaWorkbench, extractBracketMainBodyFace);
                if (!isCutout)
                {
                    extractBracketMainBodyFace.PropagationType = 3;
                    extractBracketMainBodyFace.Compute();
                }

                // CREATE REFERENCE of Bracket Main Body Face Extract
                Part bracketPart = ((PartDocument)secondaryProd.ReferenceProduct.Parent).Part;
                double[] absTrafoBracketProd = new double[12];
                string pathBracketProd = "";
                CatiaProdUtils.GetAbsTrafo(secondaryProd, rootDoc.Product, ref absTrafoBracketProd, ref pathBracketProd);
                pathBracketProd = pathBracketProd + "!" + extractBracketMainBodyFace.get_Name();


                Reference referenceBracketMainBodyFaceExtract = GetReferenceToRootFirstBody(selectedFace, pathBracketProd, "AnyObject");

                listBracketMainBodyFaceReferences.Add(referenceBracketMainBodyFaceExtract);
            }

            foreach (Reference referenceBracketFaceExtract in listBracketMainBodyFaceReferences)
            {
                selection.Clear();
                selection.Add(referenceBracketFaceExtract);
                selection.Copy();
                selection.Clear();
                selection.Add(bracketFacesGeometricalSet);
                selection.PasteSpecial("CATPrtResultWithOutLink");
            }

            // Delete GEOMETRICAL SET created in main part document.
            selection.Clear();
            selection.Add(bracketMainBodyFaceExtractGeometricalSet);
            selection.Delete();
            selection.Clear();
        }

        private static int PrepareNonStdPartWithHnfInstances(Selection selection, PartDocument tempPartDoc,
                            Product secondaryProd, HybridBodies tempHybridBodies, bool isBracketType)
        {
            // PUT secondaryProd PRODUCT IN DESIGN MODE IF NOT
            try
            {
                string _ = secondaryProd.get_PartNumber();
            }
            catch (Exception)
            {
                secondaryProd.ApplyWorkMode(CatWorkModeType.DESIGN_MODE);
            }

            // SEARCH HNF INSTANCES IN BRACKET DOCUMENT
            PartDocument bracketPartDocument;
            Part part;
            List<CatiaHnfUtils> listHnfInstances = GetAllHnfInstancesFromPartDocument(selection, secondaryProd, out bracketPartDocument, out part);

            // CREATE A NEW LIST TO STORE HNF FEATURES STORED IN MAIN BODY
            List<CatiaHnfUtils> listBracketHnfInstancesInMainBody = new List<CatiaHnfUtils>();
            foreach (CatiaHnfUtils bracketHnfInstance in listHnfInstances)
            {
                bool isHnfBelongsToMainBody = CheckIfHnfIsStoredInMainBody(bracketHnfInstance, bracketPartDocument);
                if (isHnfBelongsToMainBody == true)
                {
                    listBracketHnfInstancesInMainBody.Add(bracketHnfInstance);
                }
            }

            // IF HNF FOUND IN BRACKET PART
            if (listBracketHnfInstancesInMainBody.Count != 0)
            {
                HybridBody hnfGeometryExtractionGeometricalSet = null;
                HybridBody hnfHoleSurfacesGeometricalSet = null;
                HybridBody hnfHoleSurfacesforPSGeometricalSet = null;

                // Build assembled_hnf_holes_surface in part document
                HybridShapeAssemble assembledHnfHolesSurface = BuildAssembledHnfHolesSurfaceInPartDocument(bracketPartDocument, tempHybridBodies,
                                    listBracketHnfInstancesInMainBody, isBracketType, ref hnfHoleSurfacesGeometricalSet, ref hnfGeometryExtractionGeometricalSet,
                                    ref hnfHoleSurfacesforPSGeometricalSet);

                // Publish BRACKET/STRUCTURE HOLE SURFACE
                double[] absTrafoBracketHoleSurface = new double[12];
                string pathabsTrafoBracketHoleSurface = "";
                CatiaProdUtils.GetAbsTrafo(secondaryProd, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoBracketHoleSurface, ref pathabsTrafoBracketHoleSurface);
                pathabsTrafoBracketHoleSurface = pathabsTrafoBracketHoleSurface + "!" + assembledHnfHolesSurface.get_Name();
                //PublishFirstBody(bracketPartDocument.Product, part, pathabsTrafoBracketHoleSurface, "AnyObject");

                HybridBody hybridBodyForFace;

                if (isBracketType)
                {
                    hybridBodyForFace = hnfHoleSurfacesGeometricalSet;
                }
                else
                {
                    hybridBodyForFace = hnfHoleSurfacesforPSGeometricalSet;
                }

                selection.Clear();
                //selection.Add((AnyObject)bracketPartDocument.Product.Publications.Item(publishName).Valuation);
                selection.Add(GetReferenceToRootFirstBody(assembledHnfHolesSurface, pathabsTrafoBracketHoleSurface, "AnyObject"));
                selection.Copy();
                selection.Clear();
                selection.Add(hybridBodyForFace);
                selection.PasteSpecial("CATPrtResultWithOutLink");
                selection.Clear();

                // Delete GEOMETRICAL SET created in main part document.
                selection.Clear();
                selection.Add(hnfGeometryExtractionGeometricalSet);
                selection.Delete();
                selection.Clear();

                try
                {
                    // Split bracket body with assembled HNF hole surfaces
                    ShapeFactory sfDummyPart = (ShapeFactory)tempPartDoc.Part.ShapeFactory;
                    Body bodyBracket = tempPartDoc.Part.Bodies.Item(2);
                    tempPartDoc.Part.InWorkObject = bodyBracket;
                    HybridShapes hybridShapesHnfHoleSurfacesGeometricalSet = hybridBodyForFace.HybridShapes;
                    Reference referenceJoinAllHnfHolesInBracket = tempPartDoc.Part.CreateReferenceFromObject(hybridShapesHnfHoleSurfacesGeometricalSet.Item(1));
                    Split splitBracketWithHnf = sfDummyPart.AddNewSplit(referenceJoinAllHnfHolesInBracket,
                                                                             CatSplitSide.catPositiveSide);
                    tempPartDoc.Part.Update();
                }
                catch
                {
                    return 4103;
                }
            }

            return 0;
        }

        /// <summary>
        /// Main function for Edge and Distance to Fillet Check for Bracket and Hole IPs
        /// </summary>
        /// <param name="isEdgeDistCheck"></param>
        /// <param name="selection"></param>
        /// <param name="rootDoc"></param>
        /// <param name="secondarytProd"></param>
        /// <param name="cubeProd"></param>
        /// <param name="primStructProd"></param>
        /// <param name="multiFac">The multiple factor for the safezone diameter calculation</param>
        /// <param name="tolerance">The plus factor (Tolerance) for the safezone diameter calculation</param>
        /// <param name="diameter">For Bracket Ip, diameter is 0. For Hole Ip, diameter is coming from metadata.
        ///                         We will use this parameter to decide if it is a Brack IP or Hole IP</param>
        /// <param name="result">The internal return int value</param>
        /// <returns>The temp Product for calculation</returns>
        private static Product ValidateEdgeWebPitchDist(IpvCheckProperty property, string ipPartNumber, Selection selection,
            ProductDocument rootDoc, Product secondarytProd, Product cubeProd, Product primStructProd, Product ipProduct,
            double multiFac, double tolerance, double clearanceTolerance, double diameter, ICollection<Product> cubeCheckList,
            bool isStandard, ref int result, string pitchDistanceType, bool isEdgeDistCheck = false, bool isPitchDistCheck = false)
        {
            // Publish all needed part bodies and copy them to temp part for later use
            PartDocument tempPartDoc = null;
            HybridBodies tempGeoSet = null;
            Product tempProduct = null;

            result = TryCreateTempProduct(property, selection, rootDoc, secondarytProd, cubeProd,
                primStructProd, ref tempProduct, ref tempPartDoc, ref tempGeoSet, isStandard, isPitchDistCheck, pitchDistanceType);

            if (result > 0)
            {
                return tempProduct;
            }

            Log.Information("Temp Product and Part created for staring the calculation");
            List<Body> publishedTmpCubeBodies = new List<Body>();
            PublishAndCopyTempAllCubes(selection, rootDoc, ipProduct, tempPartDoc, publishedTmpCubeBodies, cubeCheckList);

            HybridBody mountingHolesAxisLinesGeometricalSet = tempGeoSet.Add();
            mountingHolesAxisLinesGeometricalSet.set_Name("MOUNTING HOLES AXIS LINES");

            HybridBody interfaceHolesAxisLinesGeometricalSet = tempGeoSet.Add();
            interfaceHolesAxisLinesGeometricalSet.set_Name("INTERFACE HOLES AXIS LINES");

            List<double> listMountingHoleDiameters = new List<double>();
            // For Bracker IP
            if (diameter <= 0)
            {
                result = DetectMountingAndInterfaceAxisLines(tempPartDoc, selection, tempGeoSet, mountingHolesAxisLinesGeometricalSet,
                    interfaceHolesAxisLinesGeometricalSet, listMountingHoleDiameters, clearanceTolerance, publishedTmpCubeBodies, isStandard);
            }
            else
            // For hole IP
            {
                result = CalculateCylinderAxisLine(tempPartDoc, selection, tempGeoSet, mountingHolesAxisLinesGeometricalSet, secondarytProd);
                listMountingHoleDiameters.Add(diameter);
            }

            // Check failed or internal error happens, return result
            if (result > 0)
            {
                return tempProduct;
            }

            double safeZoneDiameter = 0.0;
            // Validate mounting hole diameter count and add formular to it
            if (listMountingHoleDiameters.Count != 1)
            {
                result = 4004;
                Log.Error($"Bracket Edge dist check: More than one mounting hole diameter is found. " +
                    $"All mounting hole diameters needs to be equal!!! Please perform this check manually...");
                return tempProduct;
            }
            else
            {
                safeZoneDiameter = listMountingHoleDiameters[0] * multiFac + tolerance;
                Log.Information($"Safe Zone Diameter: {safeZoneDiameter}mm");
            }

            // FOR EACH MOUNTING HOLE AXIS LINE IN MOUNTING HOLES
            // PERFORM EDGE OR Distance to Fillet CheckS
            double mountingHoleRadius = listMountingHoleDiameters[0] / 2.0;
            result = CalculateAllEdgeWebPitchDist(property, isEdgeDistCheck, ipPartNumber, primStructProd, selection, tempPartDoc, tempGeoSet,
                mountingHolesAxisLinesGeometricalSet, safeZoneDiameter, clearanceTolerance, multiFac, mountingHoleRadius, isPitchDistCheck, pitchDistanceType); // param "pitchDistanceType" can be removed once we have common FD & ED check 

            return tempProduct;
        }

        private static int CalculateAllEdgeWebPitchDist(IpvCheckProperty property, bool isEdgeDistanceCheck, string ipPartNumber, Product primStructProd,
            Selection selection, PartDocument partDoc, HybridBodies hybridBodiesDummyGeometricalSet, HybridBody mountingHolesAxisLinesGeometricalSet,
            double safeZoneDiameter, double clearanceTolerance, double multiFac, double mountingHoleRadius, bool isPitchDistCheck, string pitchDistanceType)
        {
            int retValue = 0;

            Part partDummyPart = partDoc.Part;
            SPAWorkbench spaWorkbenchDummyPart = (SPAWorkbench)partDoc.GetWorkbench("SPAWorkbench");
            HybridShapeFactory hsfDummyPart = (HybridShapeFactory)partDummyPart.HybridShapeFactory;
            Bodies tempPartBodies = partDummyPart.Bodies;
            Body bodySecondary = tempPartBodies.Item(2);
            Body bodyPrimStructure = tempPartBodies.Item(3);

            HybridShapes hybridShapesMountingHolesAxisLines = mountingHolesAxisLinesGeometricalSet.HybridShapes;
            List<int> retValueList = new List<int>();
            foreach (HybridShape mountingHoleAxisLine in hybridShapesMountingHolesAxisLines)
            {
                Reference referenceMountingHoleAxisLine = partDummyPart.CreateReferenceFromObject(mountingHoleAxisLine);
                Reference referenceBodyStructure = partDummyPart.CreateReferenceFromObject(bodyPrimStructure);

                // INTERSECT AXIS LINE WITH STRUCTURE BODY
                // THE RESULT WILL BE MULTIPLE POINTS
                // GET THE CLOSEST 2 POINTS
                HybridShapeIntersection holeAxisBodyIntersects;
                try
                {
                    holeAxisBodyIntersects = hsfDummyPart.AddNewIntersection(referenceMountingHoleAxisLine, referenceBodyStructure);
                    holeAxisBodyIntersects.Compute();
                    partDummyPart.UpdateObject(holeAxisBodyIntersects);
                }
                catch (Exception)
                {
                    retValue = 4005;
                    Log.Error($"Bracket/Hole Edge dist check: {mountingHoleAxisLine} is not intersecting with structure. Please check manually. " +
                        $"Please perform this check manually...");
                    break;
                }

                Reference holeAxisBodyIntersectsRef = partDummyPart.CreateReferenceFromObject(holeAxisBodyIntersects);
                Array holeAxisBodyIntersectsArray = hsfDummyPart.AddNewDatums(holeAxisBodyIntersectsRef);
                List<Dictionary<string, object>> listPoints = new List<Dictionary<string, object>>();

                // FOR EACH RESULT POINT IN INTERSECTION
                // MEASURE ITS DISTANCE TO BRACKET
                // APPEND TO A LIST

                for (int j = 0; j < holeAxisBodyIntersectsArray.Length; j++)
                {
                    object intersectionResult = holeAxisBodyIntersectsArray.GetValue(j);
                    Reference referenceIntersectionResult = partDummyPart.CreateReferenceFromObject(intersectionResult as Reference);
                    Reference referenceBodySecondary = partDummyPart.CreateReferenceFromObject(bodySecondary);
                    Measurable measurableSecondary = spaWorkbenchDummyPart.GetMeasurable(referenceBodySecondary);
                    double intersectPntSecondaryDist = measurableSecondary.GetMinimumDistance(referenceIntersectionResult);
                    Dictionary<string, object> dictPoint = new Dictionary<string, object>
                    {
                        { "minDistToSecondary", intersectPntSecondaryDist },
                        { "intersectionPoint", intersectionResult }
                    };
                    Log.Information($"Distance between intersection point (mounting hole axis to body) and bracket/cylinder: {intersectPntSecondaryDist}mm");
                    listPoints.Add(dictPoint);
                }

                // After mounting hole axis line intersection to the prim structure are found, do the computation for the checks
                retValue = MountingHoleToPrimStructChecks(property, isEdgeDistanceCheck, ipPartNumber, primStructProd,
                    selection, partDoc, hybridBodiesDummyGeometricalSet, safeZoneDiameter, clearanceTolerance, multiFac,
                    mountingHoleRadius, isPitchDistCheck, pitchDistanceType, partDummyPart, tempPartBodies,
                    bodyPrimStructure, mountingHoleAxisLine, listPoints);

                retValueList.Add(retValue);

                if (retValue > 10)
                {
                    break;
                }
            }

            foreach (int value in retValueList)
            {
                retValue = Math.Max(retValue, value);
            }

            return retValue;
        }

        private static int MountingHoleToPrimStructChecks(IpvCheckProperty property, bool isEdgeDistanceCheck, string ipPartNumber,
            Product primStructProd, Selection selection, PartDocument partDoc, HybridBodies hybridBodiesDummyGeometricalSet,
            double safeZoneDiameter, double clearanceTolerance, double multiFac, double mountingHoleRadius, bool isPitchDistCheck,
            string pitchDistanceType, Part partDummyPart, Bodies tempPartBodies, Body bodyPrimStructure,
            HybridShape mountingHoleAxisLine, List<Dictionary<string, object>> listPoints)
        {
            int retValue = 0;
            // Sort list based on "minDistToSecondary" key
            List<Dictionary<string, object>> sortedListPoints = listPoints.OrderBy(d => (double)d["minDistToSecondary"]).ToList();

            HybridBody safeZoneCirclesForWdCheckGeometricalSet = hybridBodiesDummyGeometricalSet.Add();
            safeZoneCirclesForWdCheckGeometricalSet.set_Name("SAFE ZONE CIRCLES FOR FILLET DISTANCE CHECK");

            HybridBody intersectsForWdCheckGeometricalSet = hybridBodiesDummyGeometricalSet.Add();
            intersectsForWdCheckGeometricalSet.set_Name("INTERSECTS FOR FILLET DISTANCE CHECK");
            // CHECK IF BRACKET MOUNTING HOLES ARE CLOSE ENOUGH TO STRUCTURE
            // BELOW IF CONDITION ADDED BECAUSE SOMETIMES, FOR EXAMPLE, EVEN THE BRACKET
            // IS PLACED ON LOWER FLANGE OF CROSSBEAM AND MOUNTING FASTENER IS NOT CONTACTING
            // LOWER FLANGE, ALGO CAN TAKE UPPER FLANGE IN TO ACCOUNT DURING CHECKS
            double distanceTolerance = Math.Sqrt(Math.Pow(clearanceTolerance, 2) + Math.Pow(mountingHoleRadius, 2));
            double distance = Convert.ToDouble(sortedListPoints[0]["minDistToSecondary"]);
            if (distance <= (distanceTolerance + EPSILON) * MULTIPEP)
            {
                object centerPoint1 = sortedListPoints[0]["intersectionPoint"];
                object centerPoint2 = sortedListPoints[1]["intersectionPoint"];
                List<object> listCenterPoints = new List<object> { centerPoint1, centerPoint2 };

                if (isEdgeDistanceCheck)
                {
                    if (pitchDistanceType.Contains("V2"))
                    {
                        // this if else condition and function "CheckEdgeDistanceV2Algo" can be removed once we have common FD & ED check
                        retValue = CheckEdgeDistanceV2Algo(property, partDoc, ipPartNumber, primStructProd, hybridBodiesDummyGeometricalSet,
                        listCenterPoints, (Reference)mountingHoleAxisLine, safeZoneDiameter * 2, tempPartBodies, selection);
                    }
                    else
                    {
                        retValue = CheckEdgeDistance(property, partDoc, ipPartNumber, primStructProd, hybridBodiesDummyGeometricalSet,
                        listCenterPoints, (Reference)mountingHoleAxisLine, safeZoneDiameter, tempPartBodies, selection);
                    }

                }
                else if (isPitchDistCheck)
                {
                    retValue = CheckPitchDistance(property, partDoc, ipPartNumber, primStructProd, hybridBodiesDummyGeometricalSet,
                        listCenterPoints, (Reference)mountingHoleAxisLine, multiFac, mountingHoleRadius, tempPartBodies, selection);
                }
                else
                {
                    if (pitchDistanceType.Contains("V2"))
                    {
                        // this if else condition and function "CheckWebDistanceV2Algo" can be removed once we have common FD & ED check
                        retValue = CheckWebDistanceV2Algo(property, partDoc, ipPartNumber, primStructProd,
                            safeZoneCirclesForWdCheckGeometricalSet, intersectsForWdCheckGeometricalSet,
                            listCenterPoints, (Reference)mountingHoleAxisLine, safeZoneDiameter * 2, bodyPrimStructure);
                    }
                    else
                    {
                        retValue = CheckWebDistance(property, partDoc, ipPartNumber, primStructProd,
                            safeZoneCirclesForWdCheckGeometricalSet, intersectsForWdCheckGeometricalSet,
                            listCenterPoints, (Reference)mountingHoleAxisLine, safeZoneDiameter, bodyPrimStructure);
                    }

                }

                partDummyPart.Update();

                //if (retValue > 0)
                //{
                //    break;
                //}
            }
            else
            {
                double tol = (distanceTolerance + EPSILON) * MULTIPEP;
                Log.Information($"Edge/Fillet Distance Check Failed: " +
                    $"Bracket/Cylinder is too far way {distance} from the intersection point on primary structure. " +
                    $"Should smaller than {tol}. Please Check manually");

                //property.ResultInfoList = new List<string>() { distance.ToString(), tol.ToString() };
                retValue = 4006;
            }

            return retValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="document"></param>
        /// <param name="safeZoneCirclesGeoSet"></param>
        /// <param name="edgeDistanceJoinsGeoSet"></param>
        /// <param name="intersectsForEdCheckGeoSet"></param>
        /// <param name="listCenterPoints"></param>
        /// <param name="axisLine"></param>
        /// <param name="safeZoneDiameter"></param>
        /// <param name="bodyStructure"></param>
        /// <param name="selectionProductDocument"></param>
        /// <returns></returns>
        private static int CheckEdgeDistance(IpvCheckProperty property, PartDocument document, string ipPartnumber, Product primStructProd,
            HybridBodies hybridBodiesDummyGeometricalSet, List<object> listCenterPoints, Reference axisLine,
            double safeZoneDiameter, Bodies tempPartBodies, Selection selectionProductDocument)
        {
            int retValue = 0;

            Body bodySecondary = tempPartBodies.Item(2);
            Body bodyPrimStructure = tempPartBodies.Item(3);
            Body bodyCube = tempPartBodies.Item(4);

            try
            {
                object centerPoint1 = listCenterPoints[0];
                object centerPoint2 = listCenterPoints[1];
                Part part = document.Part;
                HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
                ShapeFactory sf = (ShapeFactory)part.ShapeFactory;
                SPAWorkbench spa_workbench = (SPAWorkbench)document.GetWorkbench("SPAWorkbench");
                HybridBody geoSetSafeZoneCircle = hybridBodiesDummyGeometricalSet.Add();
                geoSetSafeZoneCircle.set_Name("SAFE ZONE CIRCLES FOR EDGE DISTANCE CHECK");
                // Create temp geometrical set
                HybridBody geoSetIntersect = hybridBodiesDummyGeometricalSet.Add();
                geoSetIntersect.set_Name("INTERSECTS FOR EDGE DISTANCE CHECK");

                // DIAMETER FOR SAFE EDGE DISTANCE ZONE
                // CREATE PLANES NORMAL TO AXIS LINE AT CENTER POINT LOCATIONS
                Reference referenceAxisLine = part.CreateReferenceFromObject(axisLine);

                // Calculate 2 Safe Zone Circles from both intesected points (Upper and lower surface of prim struct)
                HybridShapeCircleCtrRad safeZoneCircle1, safeZoneCircle2;
                retValue = ComputeSafeZoneCircle(property, safeZoneDiameter, bodyPrimStructure, centerPoint1, part, hsf,
                    geoSetSafeZoneCircle, geoSetIntersect, referenceAxisLine, out safeZoneCircle1);
                int retValue2 = ComputeSafeZoneCircle(property, safeZoneDiameter, bodyPrimStructure, centerPoint2, part, hsf,
                    geoSetSafeZoneCircle, geoSetIntersect, referenceAxisLine, out safeZoneCircle2);

                retValue = Math.Max(retValue, retValue2);
                //if (retValue > 0 && retValue < 10)
                //{
                //    Reference circleRef = part.CreateReferenceFromObject(safeZoneCircle1);

                //    string error = $"Edge/Fillet distance check failed, more than one domain of the safezone " +
                //        $"circle clashes with prim structure. Please check manually ";
                //    string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrimStructure, bodySecondary, bodyCube, safeZoneCircle1,
                //        circleRef, ipPartnumber, "Ed", error, property);
                //    return retValue;
                //}
                if (retValue >= 10)
                {
                    string error = $"Edge/Fillet distance check failed, more than one domain of the safezone " + 
                        $"circle clashes with prim structure. Please check manually ";
                    Log.Information(error);
                    return retValue;
                }

                // FILL SAFE ZONE CIRCLES
                Reference referenceSafeZoneCircle1 = part.CreateReferenceFromObject(safeZoneCircle1);
                HybridShapeFill fillCircle1 = hsf.AddNewFill();
                fillCircle1.AddBound(referenceSafeZoneCircle1);
                fillCircle1.Compute();
                Reference referenceSafeZoneCircle2 = part.CreateReferenceFromObject(safeZoneCircle2);
                HybridShapeFill fillCircle2 = hsf.AddNewFill();
                fillCircle2.AddBound(referenceSafeZoneCircle2);
                fillCircle2.Compute();

                // BLEND THE SURFACE OF CYLINDRICAL AREA
                HybridShapeBlend blendBetweenCircles = hsf.AddNewBlend();
                blendBetweenCircles.SetCurve(1, referenceSafeZoneCircle1);
                blendBetweenCircles.SetCurve(2, referenceSafeZoneCircle2);
                blendBetweenCircles.Compute();

                // CREATE A CYLINDRICAL JOIN SURFACE
                HybridBody edgeDistanceJoinsGeometricalSet = hybridBodiesDummyGeometricalSet.Add();
                edgeDistanceJoinsGeometricalSet.set_Name("JOINS FOR EDGE DISTANCE CHECK");
                Reference referenceBlendBetweenCircles = part.CreateReferenceFromObject(blendBetweenCircles);
                Reference referenceFillCircle1 = part.CreateReferenceFromObject(fillCircle1);
                Reference referenceFillCircle2 = part.CreateReferenceFromObject(fillCircle2);
                HybridShapeAssemble joinDummyEdCheck = hsf.AddNewJoin(referenceFillCircle1, referenceBlendBetweenCircles);
                joinDummyEdCheck.AddElement(referenceFillCircle2);
                joinDummyEdCheck.Compute();
                edgeDistanceJoinsGeometricalSet.AppendHybridShape(joinDummyEdCheck);

                // ADD A NEW DUMMY BODY
                Bodies bodiesDummyPart = part.Bodies;
                Body dummyEdCheckBody = bodiesDummyPart.Add();
                dummyEdCheckBody.set_Name("DummyBodyForEdgeDistanceCheck");

                // CREATE A CLOSED SURFACE SOLID
                part.InWorkObject = dummyEdCheckBody;
                Reference referenceJoinDummyEdCheck = part.CreateReferenceFromObject(joinDummyEdCheck);
                sf.AddNewCloseSurface(referenceJoinDummyEdCheck);
                part.UpdateObject(dummyEdCheckBody);

                // MEASURE INITIAL VOLUME OF DUMMY BODY
                Reference referenceDummyEdCheckBody = part.CreateReferenceFromObject(dummyEdCheckBody);
                Measurable measurableDummyBody = spa_workbench.GetMeasurable(referenceDummyEdCheckBody);
                double initialVolumeDummyBody = measurableDummyBody.Volume;

                // CREATE AN INTERSECTION BETWEEN STRUCTURE BODY AND DUMMY BODY
                part.InWorkObject = bodyPrimStructure;
                Intersect bodyIntersect = sf.AddNewIntersect(dummyEdCheckBody);
                part.UpdateObject(bodyPrimStructure);

                // MEASURE THE VOLUME OF INTERSECTION
                Reference referenceBodyStructure = part.CreateReferenceFromObject(bodyPrimStructure);
                Measurable measurableBodyIntersect = spa_workbench.GetMeasurable(referenceBodyStructure);
                double volumeOfBodyIntersect = measurableBodyIntersect.Volume;

                // DELETE INTERSECT BODY
                selectionProductDocument.Selection.Clear();
                selectionProductDocument.Selection.Add(bodyIntersect);
                selectionProductDocument.Selection.Delete();
                selectionProductDocument.Selection.Clear();

                // CALCULATE THE DELTA
                double delta = (volumeOfBodyIntersect - initialVolumeDummyBody) / volumeOfBodyIntersect;
                double deltaPercentage = delta * 100;

                if (deltaPercentage >= 0 || deltaPercentage < 0 && deltaPercentage > -EPSILON)
                {
                    Log.Information($"Edge Distance Check Success: Passed with volumen percentage {deltaPercentage}");
                    retValue = 0;
                }
                else
                {
                    string errorMsg = $"Edge Distance check failed, one edge distance has ratio of {delta}, ideal ratio = 0";
                    //Body adfBody = GetPart(adfPartProd).MainBody;
                    //Reference adfRef = GetPart(adfPartProd).CreateReferenceFromObject(adfBody);
                    string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrimStructure,
                        bodySecondary, bodyCube, dummyEdCheckBody,
                        referenceDummyEdCheckBody, ipPartnumber, "ED", errorMsg, property);

                    Log.Information($"Edge Distance Check Failed:  Difference of volumen percentage {deltaPercentage}");
                    retValue = 1;
                }

            }
            catch (Exception)
            {
                Log.Error("Edge Distance Check: Internel Error happens during CheckEdgeDistance(). Please check manually.");
                retValue = 1000;
            }

            return retValue;
        }

        private static int CheckEdgeDistanceV2Algo(IpvCheckProperty property, PartDocument document, string ipPartnumber, Product primStructProd,
            HybridBodies hybridBodiesDummyGeometricalSet, List<object> listCenterPoints, Reference axisLine,
            double safeZoneDiameter, Bodies tempPartBodies, Selection selectionProductDocument)
        {
            int retValue = 0;

            Body bodySecondary = tempPartBodies.Item(2);
            Body bodyPrimStructure = tempPartBodies.Item(3);
            Body bodyCube = tempPartBodies.Item(4);

            try
            {
                Part part = document.Part;
                HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
                ShapeFactory sf = (ShapeFactory)part.ShapeFactory;
                SPAWorkbench spa_workbench = (SPAWorkbench)document.GetWorkbench("SPAWorkbench");
                HybridBody geoSetSafeZoneCircle = hybridBodiesDummyGeometricalSet.Add();
                geoSetSafeZoneCircle.set_Name("SAFE ZONE CIRCLES FOR EDGE DISTANCE CHECK");
                // Create temp geometrical set
                HybridBody geoSetIntersect = hybridBodiesDummyGeometricalSet.Add();
                geoSetIntersect.set_Name("INTERSECTS FOR EDGE DISTANCE CHECK");

                // DIAMETER FOR SAFE EDGE DISTANCE ZONE
                // CREATE PLANES NORMAL TO AXIS LINE AT CENTER POINT LOCATIONS
                Reference referenceAxisLine = part.CreateReferenceFromObject(axisLine);
                //HybridShapeExtract centerPoint1, centerPoint2;
                HybridShapeCircle safeZoneCircle;
                Array datumsOfIntersection = BuildEdgeDistanceCheckElements(bodyPrimStructure, listCenterPoints, axisLine,
                    safeZoneDiameter, part, spa_workbench, geoSetSafeZoneCircle, geoSetIntersect, out safeZoneCircle);

                Reference referenceSafeZoneCircle = part.CreateReferenceFromObject(safeZoneCircle);
                // CHECK THE AMOUNT OF DATUMS IN INTERSECTION
                // RETURN FINAL EDGE DISTANCE CHECK RESULT
                if (datumsOfIntersection.Length == 1)
                {
                    retValue = 1;

                    string errorMsg = $"Edge Distance check failed, datums in intersection is 1";
                    //Body adfBody = GetPart(adfPartProd).MainBody;
                    //Reference adfRef = GetPart(adfPartProd).CreateReferenceFromObject(adfBody);
                    string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrimStructure,
                        bodySecondary, bodyCube, safeZoneCircle, referenceSafeZoneCircle, ipPartnumber, "ED", errorMsg, property);

                    Log.Information($"Edge Distance Check Failed:  Datums of intersection is 1");

                }
                else if (datumsOfIntersection.Length == 2)
                {
                    bool is1stCurveClosed = CheckIfCurveIsClosed(part, (AnyObject)datumsOfIntersection.GetValue(0));
                    bool is2ndCurveClosed = CheckIfCurveIsClosed(part, (AnyObject)datumsOfIntersection.GetValue(1));

                    if (is1stCurveClosed && is2ndCurveClosed)
                    {
                        retValue = 0;
                    }
                    else
                    {
                        Log.Error("Edge Distance Check: One of the curve from datums Of Intersection is not closed. Please check manually.");
                        retValue = 11;
                    }
                }
                else
                {
                    Log.Error($"Edge Distance Check: datums of intersection {datumsOfIntersection.Length} is greater than valid num 2 . Please check manually.");
                    retValue = 12;
                }
                return retValue;
            }
            catch (Exception)
            {
                Log.Error("Edge Distance Check: Internel Error happens during CheckEdgeDistance(). Please check manually.");
                retValue = 18;
            }

            return retValue;
        }

        private static Array BuildEdgeDistanceCheckElements(Body bodyPrimStructure, List<object> listCenterPoints,
            Reference axisLine, double safeZoneDiameter, Part part, SPAWorkbench spa_workbench, HybridBody geoSetSafeZoneCircle,
            HybridBody geoSetIntersect, out HybridShapeCircle safeZoneCircle1)
        {
            PartDocument partDocument = (PartDocument)part.Parent;

            HybridShapeExtract centerPoint1 = BuildExtractFromPoint(partDocument, (AnyObject)listCenterPoints[0]);
            HybridShapeExtract centerPoint2 = BuildExtractFromPoint(partDocument, (AnyObject)listCenterPoints[1]);

            // CREATE PLANES NORMAL TO AXIS LINE AT CENTER POINT 1
            HybridShapePlaneNormal planeNormalToAxisLineAtCp1 = BuildPlaneNormalToLine(part, centerPoint1, axisLine);

            // CREATE A LINE BETWEEN CENTER POINTS
            Line lineBetweenCp1AndCp2 = BuildLineBetweenTwoPoints(partDocument, centerPoint1, centerPoint2);

            // MEASURE THE LENGTH OF THE LINE BETWEEN
            Reference referenceLineBetweenCp1AndCp2 = part.CreateReferenceFromObject(lineBetweenCp1AndCp2);
            Measurable measurableLineBetweenCp1AndCp2 = spa_workbench.GetMeasurable(referenceLineBetweenCp1AndCp2);
            double lengthLineBetweenCp1AndCp2 = Math.Round(measurableLineBetweenCp1AndCp2.Length, 3);

            // CREATE SAFE ZONE CIRCLE
            safeZoneCircle1 = BuildCircleOnPlane(partDocument, planeNormalToAxisLineAtCp1, centerPoint1,
                                                                            safeZoneDiameter);

            // CREATE CIRCULAR EXTRUDE FROM SAFE ZONE CIRCLE 1
            HybridShapeExtrude extrudeSafeZoneCircle1 = BuildCircularExtrude(partDocument, safeZoneCircle1, lineBetweenCp1AndCp2,
                                                                  lengthLineBetweenCp1AndCp2, 0.5 * lengthLineBetweenCp1AndCp2);
            geoSetSafeZoneCircle.AppendHybridShape(extrudeSafeZoneCircle1);

            // CREATE INTERSECTION BETWEEN EXTRUDED SURFACE AND PRIMARY STRUCTURE BODY
            HybridShape intersectionPrimStructureBodyAndExtrudedSurface = BuildIntersection(part, bodyPrimStructure, extrudeSafeZoneCircle1);
            geoSetIntersect.AppendHybridShape(intersectionPrimStructureBodyAndExtrudedSurface);

            // CREATE DATUMS OF INTERSECTION
            Array datumsOfBoundary = BuildDatums(part, intersectionPrimStructureBodyAndExtrudedSurface);

            return datumsOfBoundary;
        }

        private static int CheckPitchDistance(IpvCheckProperty property, PartDocument document, string ipPartnumber, Product primStructProd,
            HybridBodies hybridBodiesDummyGeometricalSet, List<object> listCenterPoints, Reference axisLine,
            double multiFac, double mountingHoleRadius, Bodies tempPartBodies, Selection selectionProductDocument)
        {
            int retValue = 0;

            Body bodySecondary = tempPartBodies.Item(2);
            Body bodyPrimStructure = tempPartBodies.Item(3);
            Body bodyCube = tempPartBodies.Item(4);

            // Create a new geometrical set in the hybridBodiesDummyGeometricalSet

            // Create ELEMENTS FOR PITCH DISTANCE CHECK
            HybridBody elementsForPitchDistanceCheckGeometricalSet = hybridBodiesDummyGeometricalSet.Add();
            elementsForPitchDistanceCheckGeometricalSet.set_Name("ELEMENTS FOR PITCH DISTANCE CHECK");

            // Get hybrid bodies from elements for pitch distance check geometrical set
            HybridBodies hybridBodiesElementsForPitchDistanceCheckGeometricalSet = elementsForPitchDistanceCheckGeometricalSet.HybridBodies;

            // Create SUPPORTING ELEMENTS FOR PITCH DISTANCE CHECK
            HybridBody supportingElementsPdCheckGeometricalSet = hybridBodiesElementsForPitchDistanceCheckGeometricalSet.Add();
            supportingElementsPdCheckGeometricalSet.set_Name("SUPPORTING ELEMENTS FOR PITCH DISTANCE CHECK");

            // Create AXIS LINES FOR PITCH DISTANCE CHECK
            HybridBody axisLinesForPdCheckGeometricalSet = hybridBodiesElementsForPitchDistanceCheckGeometricalSet.Add();
            axisLinesForPdCheckGeometricalSet.set_Name("AXIS LINES FOR PITCH DISTANCE CHECK");

            HybridBody holeSurfacesGeoSet = (HybridBody)document.Part.HybridBodies.GetItem("HNF HOLE SURFACES FOR STRUCTURE");

            try
            {
                Part part = document.Part;
                SPAWorkbench spaworkbench = (SPAWorkbench)document.GetWorkbench("SPAWorkbench");
                Selection selection = document.Selection;

                // CREATE PITCH EFFECTIVE AREA SOLID
                double holeDiameter = mountingHoleRadius * 2;
                double effectiveAreaDiameter = 4 * multiFac * holeDiameter;
                Body bodyPitchEffectiveAreaSolid = BuildPitchEffectiveAreaSolid(part, spaworkbench,
                                                                                  supportingElementsPdCheckGeometricalSet,
                                                                                  listCenterPoints, effectiveAreaDiameter,
                                                                                  bodyPrimStructure, axisLine,
                                                                                  holeSurfacesGeoSet);

                // SEARCH ALL FACES OF PITCH EFF AREA SOLID AND APPEND INTO A LIST
                List<Face> listEffPitchAreaSolidFaces = SearchAndGetAllFacesOfBody(selection, bodyPitchEffectiveAreaSolid);

                // FILTER CYLINDRICAL HOLE FACES OF PITCH EFFECTIVE AREA SOLID
                List<Dictionary<string, object>> listDictPitchEffAreaSolidCylindricalHoleFaces = FilterCylindricalFaces(
                listEffPitchAreaSolidFaces, part, spaworkbench, supportingElementsPdCheckGeometricalSet,
                axisLinesForPdCheckGeometricalSet);

                // LOOP THROUGH ALL CYLINDRICAL HOLE FACES AND PERFORM PITCH DISTANCE CHECK FOR EACH
                List<bool> listCheckResultsAllFaces = new List<bool>();
                foreach (Dictionary<string, object> dictPitchEffAreaSolidCylindricalHoleFace in listDictPitchEffAreaSolidCylindricalHoleFaces)
                {
                    double diameterOfNearHole = Convert.ToDouble(dictPitchEffAreaSolidCylindricalHoleFace["diameter"]);
                    AnyObject axisLineOfNearHole = (AnyObject)dictPitchEffAreaSolidCylindricalHoleFace["axisLine"];
                    if (diameterOfNearHole != effectiveAreaDiameter)
                    {
                        bool checkResultForEachFace = PerformSinglePitchDistanceCheckBetweenTwoAxisLines(
                                            part, spaworkbench,
                                            diameterOfNearHole,
                                            holeDiameter,
                                            axisLineOfNearHole,
                                            axisLine,
                                            multiFac);

                        // APPEND EACH RESULT TO LIST
                        listCheckResultsAllFaces.Add(checkResultForEachFace);
                    }
                }

                // FINALLY, CHECK IF THERE IS FALSE IN LIST CHECK RESULT
                if (listCheckResultsAllFaces.Contains(false))
                {
                    string errorMsg = $"Bracket Pitch Distance Check failed, min distance is not in allowed range";
                    Reference solidRef = part.CreateReferenceFromObject(bodyPitchEffectiveAreaSolid);
                    string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyPrimStructure,
                        bodySecondary, bodyCube, bodyPitchEffectiveAreaSolid,
                        solidRef, ipPartnumber, "PD", errorMsg, property);

                    Log.Error($"Bracket Pitch Distance Check: Pitch Distance check failed for one of the HOLE FACES");
                    retValue = 1;
                }
                else
                {
                    Log.Information("Bracket Pitch Distance Check: Pitch distance check ok");
                    retValue = 0;
                }
                return retValue;
            }
            catch (Exception)
            {
                // Handle exception appropriately
                Log.Error($"Bracket Pitch Distance Check: Error happens while preparing for check");
                retValue = 1000;
            }
            return retValue;
        }

        private static int ComputeSafeZoneCircle(IpvCheckProperty property, double safeZoneDiameter, Body bodyStructure, 
            object centerPoint, Part part, HybridShapeFactory hsf, HybridBody safeZoneCirclesForEdCheckGeometricalSet, 
            HybridBody intersectsForEdCheckGeometricalSet, Reference referenceAxisLine, out HybridShapeCircleCtrRad safeZoneCircle)
        {
            int retValue = -1;
            Reference refCntPnt = part.CreateReferenceFromObject((AnyObject)centerPoint);
            HybridShapePlaneNormal planeNormalToCenterPoint = hsf.AddNewPlaneNormal(referenceAxisLine, refCntPnt);
            planeNormalToCenterPoint.Compute();

            // CREATE SAFE ZONE CIRCLES FOR BOTH CENTER POINTS
            Reference refPlaneNormToCntPnt = part.CreateReferenceFromObject(planeNormalToCenterPoint);
            safeZoneCircle = hsf.AddNewCircleCtrRad(refCntPnt, refPlaneNormToCntPnt, true, safeZoneDiameter);
            safeZoneCircle.Compute();
            safeZoneCirclesForEdCheckGeometricalSet.AppendHybridShape(safeZoneCircle);

            // CREATE AN INTERSECTION BETWEEN SAFE ZONE CIRCLE AND STRUCTURE BODY
            Reference referenceSafeZoneCircle = part.CreateReferenceFromObject(safeZoneCircle);
            Reference referenceBodyStructure = part.CreateReferenceFromObject(bodyStructure);

            try
            {
                HybridShapeIntersection intersectForCheck = hsf.AddNewIntersection(referenceSafeZoneCircle, referenceBodyStructure);
                part.UpdateObject(intersectForCheck);
                intersectsForEdCheckGeometricalSet.AppendHybridShape(intersectForCheck);

                // CHECK IF THE INTERSECT RESULT IS SINGLE DOMAIN
                var datumsOfIntersection1 = hsf.AddNewDatums(intersectForCheck as Reference);
                int domainAmounts1 = datumsOfIntersection1.Length;
                if (domainAmounts1 != 1)
                {
                    Log.Error($"Edge Distance Check Failed: Domain of intersection of safezone circle " +
                        $"with prim struct is NOT one (E.g. Secondary part has an angle regarding prim structure). Please check manually.");

                    if (property.IsHoleCheck)
                    {
                        retValue = 2008;
                    }
                    else
                    {
                        retValue = 4007;
                    }
                }
            }
            catch (Exception)
            {
                Log.Error($"Edge Distance Check Failed: Internal error happens for safe zone circle calculation. Please check manually.");
                retValue = 1000;
            }


            return retValue;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="document"></param>
        /// <param name="safeZoneCirclesGeoSet"></param>
        /// <param name="intersectsForChecksGeoSet"></param>
        /// <param name="listCenterPoints"></param>
        /// <param name="axisLine"></param>
        /// <param name="safeZoneDiameter"></param>
        /// <param name="bodyStructure"></param>
        /// <returns></returns>
        private static int CheckWebDistance(IpvCheckProperty property, PartDocument document, string ipPartNumber, Product primStructProd,
            HybridBody safeZoneCirclesGeoSet, HybridBody intersectsForChecksGeoSet,
            List<object> listCenterPoints, Reference axisLine, double safeZoneDiameter, Body bodyStructure)
        {
            int retValue = 0;
            try
            {
                List<bool> listWebDistanceCheckResults = new List<bool>();
                for (int i = 0; i < 2; i++)
                {
                    object centerPoint = listCenterPoints[i];
                    Part part = document.Part;
                    HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
                    SPAWorkbench spaWorkbench = (SPAWorkbench)document.GetWorkbench("SPAWorkbench");

                    // Create plane normal to axis line at center point location
                    Reference referenceAxisLine = part.CreateReferenceFromObject(axisLine);
                    Reference referenceCenterPoint = part.CreateReferenceFromObject((AnyObject)centerPoint);
                    HybridShapePlaneNormal planeNormalToCenterPoint = hsf.AddNewPlaneNormal(referenceAxisLine, referenceCenterPoint);
                    planeNormalToCenterPoint.Compute();

                    // Create safe zone circle
                    Reference referencePlaneNormalToCenterPoint = part.CreateReferenceFromObject(planeNormalToCenterPoint);
                    HybridShapeCircleCtrRad safeZoneCircle = hsf.AddNewCircleCtrRad(referenceCenterPoint, referencePlaneNormalToCenterPoint,
                                                                                    true, safeZoneDiameter);

                    safeZoneCircle.Compute();
                    safeZoneCirclesGeoSet.AppendHybridShape(safeZoneCircle);

                    // Create an intersection between safe zone circle and structure body
                    Reference referenceSafeZoneCircle = part.CreateReferenceFromObject(safeZoneCircle);
                    Reference referenceBodyStructure = part.CreateReferenceFromObject(bodyStructure);
                    HybridShapeIntersection intersectForCheck = hsf.AddNewIntersection(referenceSafeZoneCircle, referenceBodyStructure);
                    part.UpdateObject(intersectForCheck);
                    intersectsForChecksGeoSet.AppendHybridShape(intersectForCheck);

                    Array datumsOfIntersection = hsf.AddNewDatums(intersectForCheck as Reference);
                    if (datumsOfIntersection.Length != 1)
                    {
                        if (property.IsHoleCheck)
                        {
                            retValue = 2008;
                        }
                        else
                        {
                            retValue = 4007;
                        }
                        Log.Information($"Distance to Fillet Check Failed: More than one domain is found for intesecting safe zone with prim sturct.");
                        //string errorMsg = $"Distance to Fillet Check failed, multi domain found during distance calculation. Please check primary structure and check manually.";
                        //string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyStructure, null, null, safeZoneCircle,
                        //    referenceSafeZoneCircle, ipPartNumber, "WD", errorMsg, property);
                        listWebDistanceCheckResults.Add(false);
                        continue;
                    }

                    // Measure the length of intersection and circle
                    // Check if the length values are equal
                    Measurable measurableSafeZoneCircle = spaWorkbench.GetMeasurable(referenceSafeZoneCircle);
                    Reference referenceIntersectForCheck = part.CreateReferenceFromObject(intersectForCheck);
                    Measurable measurableIntersectForCheck = spaWorkbench.GetMeasurable(referenceIntersectForCheck);

                    double lengthOfSafeZoneCircle = Math.Round(measurableSafeZoneCircle.Length, 3);
                    double lengthOfIntersectForCheck = Math.Round(measurableIntersectForCheck.Length, 3);
                    Log.Information($"Distance to Fillet Check: Safe zone circle length {lengthOfSafeZoneCircle}mm");
                    Log.Information($"Distance to Fillet Check: Intersection line length {lengthOfIntersectForCheck}mm");

                    if (lengthOfSafeZoneCircle == lengthOfIntersectForCheck)
                    {
                        listWebDistanceCheckResults.Add(true);
                    }
                    else
                    {
                        listWebDistanceCheckResults.Add(false);
                        string errorMsg = $"Distance to Fillet edge failed, a Fillet edge distance has ratio of {lengthOfIntersectForCheck / lengthOfSafeZoneCircle}, ideal ratio = 1";
                        string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyStructure, null, null, safeZoneCircle,
                            referenceSafeZoneCircle, ipPartNumber, "holeWD", errorMsg, property);
                    }
                }

                // Return final Distance to Fillet Check result
                if (listWebDistanceCheckResults[0] && listWebDistanceCheckResults[1])
                {
                    Log.Information($"Distance to Fillet Check Success: Both intersecting points for mounting hole axis passes the check");
                }
                else
                {
                    retValue = Math.Max(retValue, 1);
                    Log.Information($"Distance to Fillet Check Failed: Result {listWebDistanceCheckResults[0]} - {listWebDistanceCheckResults[1]}");
                }

            }
            catch (Exception e)
            {
                retValue = 1000;
                Log.Error($"Distance to Fillet Check: Internal error happens during CheckWebDistance(). {e.ToString()}");
            }

            return retValue;
        }

        private static int CheckWebDistanceV2Algo(IpvCheckProperty property, PartDocument document, string ipPartNumber, Product primStructProd,
            HybridBody safeZoneCirclesGeoSet, HybridBody intersectsForChecksGeoSet,
            List<object> listCenterPoints, Reference axisLine, double safeZoneDiameter, Body bodyStructure)
        {
            int retValue = 0;

            try
            {
                Part part = document.Part;
                SPAWorkbench spaWorkbench = (SPAWorkbench)document.GetWorkbench("SPAWorkbench");
                Selection selection = document.Selection;

                HybridShapeCircle safeZoneCircle = null;

                // CREATE SOLID BODY FOR WEB DISTANCE CHECK
                Body bodySolidForWebDistanceCheck = BuildSolidForWebDistanceCheck(document, safeZoneCirclesGeoSet, listCenterPoints,
                        axisLine, safeZoneDiameter, bodyStructure, part, spaWorkbench, out safeZoneCircle);

                Reference referenceSafeZoneCircle = part.CreateReferenceFromObject(safeZoneCircle);

                // SEARCH FACES OF INTERSECTED BODY
                List<Face> listFacesOfIntersectedBody = SearchAndGetAllFacesOfBody(selection, bodySolidForWebDistanceCheck);

                // CHECK IF THERE IS EXACT 3 FACES
                // RETURN FINAL WEB DISTANCE CHECK RESULT
                if (listFacesOfIntersectedBody.Count == 3)
                {
                    Log.Information($"Distance to Fillet Check Success: Both intersecting points for mounting hole axis passes the check");
                    retValue = 0;
                }
                else
                {
                    retValue = 1;

                    string errorMsg = $"Distance to Fillet edge failed, one of the intersect body as more faces {listFacesOfIntersectedBody.Count} which should be 3";
                    string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(bodyStructure, null, null, safeZoneCircle,
                        referenceSafeZoneCircle, ipPartNumber, "FD", errorMsg, property);

                    Log.Information($"Distance to Fillet Check Failed: More than one domain is found for intesecting safe zone with prim sturct.");
                }
                return retValue;
            }
            catch (Exception e)
            {
                retValue = 31;
                Log.Error($"Distance to Fillet Check: Internal error happens during CheckWebDistance(). {e.ToString()}");
            }

            return retValue;
        }

        private static Body BuildSolidForWebDistanceCheck(PartDocument document, HybridBody safeZoneCirclesGeoSet,
            List<object> listCenterPoints, Reference axisLine, double safeZoneDiameter, Body bodyStructure,
            Part part, SPAWorkbench spaWorkbench, out HybridShapeCircle safeZoneCircle)
        {
            HybridShapeExtract centerPoint1 = BuildExtractFromPoint(document, (AnyObject)listCenterPoints[0]);
            HybridShapeExtract centerPoint2 = BuildExtractFromPoint(document, (AnyObject)listCenterPoints[1]);

            // CREATE PLANES NORMAL TO AXIS LINE AT CENTER POINT 1
            HybridShapePlaneNormal planeNormalToAxisLineAtCp1 = BuildPlaneNormalToLine(part, centerPoint1, axisLine);

            // CREATE A LINE BETWEEN CENTER POINTS
            Line lineBetweenCp1AndCp2 = BuildLineBetweenTwoPoints(document, centerPoint1, centerPoint2);

            // MEASURE THE LENGTH OF THE LINE BETWEEN
            Reference referenceLineBetweenCp1AndCp2 = part.CreateReferenceFromObject(lineBetweenCp1AndCp2);
            Measurable measurableLineBetweenCp1AndCp2 = spaWorkbench.GetMeasurable(referenceLineBetweenCp1AndCp2);
            double lengthLineBetweenCp1AndCp2 = Math.Round(measurableLineBetweenCp1AndCp2.Length, 3);

            // CREATE SAFE ZONE CIRCLE
            safeZoneCircle = BuildCircleOnPlane(document, planeNormalToAxisLineAtCp1, centerPoint1,
                                                                            safeZoneDiameter);
            // CREATE CIRCULAR EXTRUDE FROM SAFE ZONE CIRCLE 1
            HybridShapeExtrude extrudeSafeZoneCircle1 = BuildCircularExtrude(document, safeZoneCircle, lineBetweenCp1AndCp2,
                                                                  lengthLineBetweenCp1AndCp2, 0.5 * lengthLineBetweenCp1AndCp2);
            safeZoneCirclesGeoSet.AppendHybridShape(extrudeSafeZoneCircle1);

            // ADD A NEW BODY
            Body bodySafeZone = AddNewBody(part, "BodySafeZone");

            // CREATE A SOLID UNDER NEW BODY BY CLOSING EXTRUDED SURFACE OF SAFE ZONE
            CloseSurface closeSurfaceSafeZone = BuildCloseSurface(part, bodySafeZone, extrudeSafeZoneCircle1);

            // CREATE A DUPLICATED PRIMARY STRUCTURE BODY
            Body bodyDuplicatedPrimaryStructure = BuildDuplicateOfAnExistingBody(part, bodyStructure,
                                                                    "DummyBodyForWebDistanceCheck");

            // INTERSECT TWO BODIES
            Intersect intersection = BuildIntersectionOfTwoBodies(part, bodyDuplicatedPrimaryStructure,
                                                                bodySafeZone);
            return bodyDuplicatedPrimaryStructure;
        }

        private static int CalculateCylinderAxisLine(PartDocument tempPartDoc, Selection selectionProductDocument,
            HybridBodies hybridBodiesDummyGeometricalSet, HybridBody mountingHolesAxisLinesGeometricalSet, 
            Product secondarytProd)
        {
            int result = -1;

            Bodies tempPartBodies = tempPartDoc.Part.Bodies;

            AnyObject bodySecondStructure = (AnyObject)tempPartBodies.GetItem("SECONDARY");
            PartDocument partDocForExtraction = tempPartDoc;
            // For the case that we have disassemblied cylinders, we will use the single datum for surface search
            if (bodySecondStructure == null)
            {
                return 2007;
            }

            // FIND ALL FACES OF BRACKET BODY
            // APPEND EACH FACE TO A LIST
            //Part tempPart = tempPartDoc.Part;
            SPAWorkbench spaWorkbenchDummyPart = (SPAWorkbench)partDocForExtraction.GetWorkbench("SPAWorkbench");
            HybridShapeFactory hsfDummyPart = (HybridShapeFactory)partDocForExtraction.Part.HybridShapeFactory;

            List<Face> listSelectedFaces;
            List<string> listSelectedTypes;
            GetAllFacesOfBody(tempPartDoc, bodySecondStructure, out listSelectedFaces, out listSelectedTypes);

            int j = 0;
            foreach (var face in listSelectedFaces)
            {
                // After updateobject() function, error will be thrown if face is not cylindical
                try
                {
                    var faceExtract = hsfDummyPart.AddNewExtract(face);
                    faceExtract.PropagationType = 2;
                    faceExtract.Compute();
                    Reference extractFaceRef = partDocForExtraction.Part.CreateReferenceFromObject(faceExtract as Reference);
                    HybridShapeAxisLine axisLine = hsfDummyPart.AddNewAxisLine(extractFaceRef);
                    axisLine.AxisLineType = 3;
                    axisLine.Compute();
                    partDocForExtraction.Part.UpdateObject(axisLine);

                    mountingHolesAxisLinesGeometricalSet.AppendHybridShape(axisLine);
                    result = 0;
                }
                catch (Exception e)
                {
                    Log.Debug($"For the selected face type ({listSelectedTypes[j]}), it is not able to create axis line for it. {e.ToString()}");
                }
                j++;

            }

            if (result < 0)
            {
                result = 2006;
            }

            return result;
        }

        private static void GetAllFacesOfBody(PartDocument partDoc, AnyObject SecondStructure,
            out List<Face> listSelectedFaces, out List<string> listSelectedTypes)
        {
            Selection selection = partDoc.Selection;
            selection.Clear();
            selection.Add(SecondStructure);
            selection.Search("Topology.Face,sel");

            listSelectedFaces = new List<Face>();
            listSelectedTypes = new List<string>();
            for (int i = 0; i < selection.Count2; i++)
            {
                try
                {
                    object selectedFace = selection.Item2(i + 1).Value;
                    listSelectedTypes.Add(selection.Item2(i + 1).Type);
                    listSelectedFaces.Add((Face)selectedFace);
                }
                catch (Exception)
                {
                    Log.Debug("Exception by adding found faces of backet to internal list.");
                }
            }
        }

        private static int DetectMountingAndInterfaceAxisLines(PartDocument tempPartDoc, Selection selectionProductDocument,
            HybridBodies geoSetTempPartHybridBodies, HybridBody mountingHolesAxisLinesGeometricalSet,
            HybridBody interfaceHolesAxisLinesGeometricalSet, List<double> listMountingHoleDiameters,
            double clearanceTolerance, List<Body> publishedTmpCubeBodies, bool isStandard)
        {
            Log.Information("Start detecting mouting and interface hole axis......");
            Bodies tempPartBodies = tempPartDoc.Part.Bodies;
            Body bodyBracket = tempPartBodies.Item(2);
            Body bodyPrimStructure = tempPartBodies.Item(3);
            Body bodyIpCube = null;
            try
            {
                bodyIpCube = tempPartBodies.Item(4);
            }
            catch (Exception)
            {
                Log.Debug($"DetectMountingAndInterfaceAxisLines: No cube body found");
            }

            int result = 0;
            Part tempPart = tempPartDoc.Part;
            SPAWorkbench spaWorkbenchTempPart = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
            HybridShapeFactory hsfTempPart = (HybridShapeFactory)tempPart.HybridShapeFactory;

            // FIND ALL FACES OF BRACKET BODY
            // APPEND EACH FACE TO A LIST            
            Selection selectionDummyPart = tempPartDoc.Selection;
            selectionDummyPart.Clear();
            if (isStandard)
            {
                // this is new update for some std brackets type, no difference now for std and none std parts
                HybridBody hybridShapesBracketFacesGeometricalSet = (HybridBody)geoSetTempPartHybridBodies.GetItem("BRACKET FACES");
                selectionDummyPart.Add(hybridShapesBracketFacesGeometricalSet);
            }
            else
            {
                selectionDummyPart.Add(bodyBracket);
            }
            selectionDummyPart.Search("Topology.Face,sel");
            List<Face> listBracketFaces = new List<Face>();
            for (int i = 0; i < selectionDummyPart.Count2; i++)
            {
                try
                {
                    object selectedFace = selectionDummyPart.Item2(i + 1).Value;
                    listBracketFaces.Add((Face)selectedFace);
                }
                catch (Exception)
                {
                    Log.Debug("Exception by adding found faces of backet to internal list.");
                }
            }

            selectionDummyPart.Clear();

            Log.Information($"Found {listBracketFaces.Count} faces on the bracket");
            HybridBody geoSetHoleFace = geoSetTempPartHybridBodies.Add();
            geoSetHoleFace.set_Name("BRACKET HOLE FACE EXTRACTS");

            ExtractHolesFromPart(tempPartDoc, listBracketFaces, geoSetHoleFace);

            // FOR EACH HOLE FACES OF BRACKET
            HybridShapes bracketHoleExtracts = geoSetHoleFace.HybridShapes;
            Log.Information($"Totally, we found {bracketHoleExtracts.Count} extracts of bracket hole face.");

            List<object> mountingHoleFaces, interfaceHoleFaces;
            DetectMountingInterfaceHoleFaces(tempPartDoc, bodyPrimStructure, bodyIpCube, bracketHoleExtracts,
                clearanceTolerance, publishedTmpCubeBodies, out mountingHoleFaces, out interfaceHoleFaces);

            // CHECK IF THE LIST MOUNTING HOLE IS EMPTY OR NOT
            if (mountingHoleFaces.Count == 0)
            {
                result = 4008;
                Log.Error($"Bracket Edge dist check: No mounting hole can be found !!! Please perform this check manually...");
                //return result;
            }

            // GET MOUNTING HOLE DIAMETER
            // WILL BE USED IN FURTHER STEPS
            foreach (var extractMountingHoleFace in mountingHoleFaces)
            {
                Reference mountingHoleFaceRef = tempPart.CreateReferenceFromObject(extractMountingHoleFace as Reference);
                Measurable mountingHoleFaceMeasure = spaWorkbenchTempPart.GetMeasurable(mountingHoleFaceRef);
                double mountingHoleRadius = Math.Round(mountingHoleFaceMeasure.Radius, 3);
                // IF SAME MOUNTING HOLE DIAMETER NOT IN LIST MOUNTING HOLE DIAMETERS
                // THEN APPEND TO LIST
                if (!listMountingHoleDiameters.Contains(mountingHoleRadius * 2.0))
                {
                    listMountingHoleDiameters.Add(mountingHoleRadius * 2.0);
                }
                Log.Information($"Found Mounting Hole Diameter: {mountingHoleRadius * 2.0}");
            }

            // CREATE AXIS LINES FOR MOUNTING HOLES
            foreach (var extractMountingHoleFace in mountingHoleFaces)
            {
                var referenceExtractMountingHoleFace = tempPart.CreateReferenceFromObject(extractMountingHoleFace as Reference);
                var mountingHoleAxisLine = hsfTempPart.AddNewAxisLine(referenceExtractMountingHoleFace);
                mountingHoleAxisLine.Compute();
                mountingHolesAxisLinesGeometricalSet.AppendHybridShape(mountingHoleAxisLine);
            }

            // IDENTIFY AND DELETE SAME AXIS LINES FOR MOUNTING HOLES
            DeleteSameAxisLines(tempPartDoc, selectionProductDocument, mountingHolesAxisLinesGeometricalSet, spaWorkbenchTempPart);

            // CREATE AXIS LINES FOR INTERFACE HOLES
            foreach (var extractInterfaceHoleFace in interfaceHoleFaces)
            {
                var referenceExtractInterfaceHoleFace = tempPart.CreateReferenceFromObject(extractInterfaceHoleFace as Reference);
                var interfaceHoleAxisLine = hsfTempPart.AddNewAxisLine(referenceExtractInterfaceHoleFace);
                interfaceHoleAxisLine.Compute();
                interfaceHolesAxisLinesGeometricalSet.AppendHybridShape(interfaceHoleAxisLine);
            }

            // IDENTIFY AND DELETE SAME AXIS LINES FOR INTERFACE HOLES
            DeleteSameAxisLines(tempPartDoc, selectionProductDocument, interfaceHolesAxisLinesGeometricalSet, spaWorkbenchTempPart);

            return result;
        }

        private static void DetectMountingInterfaceHoleFaces(PartDocument tempPartDoc, Body bodyPrimStructure, Body bodyIpCube,
            HybridShapes bracketHoleExtracts, double clearanceTolerance, List<Body> publishedTmpCubeBodies,
            out List<object> mountingHoleFaces, out List<object> interfaceHoleFaces)
        {
            Part tempPart = tempPartDoc.Part;
            SPAWorkbench spaWorkbenchTempPart = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
            HybridShapeFactory hsfTempPart = (HybridShapeFactory)tempPart.HybridShapeFactory;

            List<Dictionary<string, object>> listDictBracketHoles = new List<Dictionary<string, object>>();
            foreach (HybridShape holeFace in bracketHoleExtracts)
            {
                // CREATE A DICTIONARY FOR EACH HOLE
                Dictionary<string, object> dictBracketHole = new Dictionary<string, object>();
                dictBracketHole["extractObject"] = holeFace;

                // CREATE MEASURABLE OBJECT FOR HOLE FACE EXTRACT
                Reference referenceBracketHoleFaceExtract = tempPart.CreateReferenceFromObject(holeFace);
                Measurable measurableBracketHoleFaceExtract = spaWorkbenchTempPart.GetMeasurable(referenceBracketHoleFaceExtract);

                // MEASURE THE DISTANCE BETWEEN HOLE FACE AND STRUCTURE
                Reference referenceBodyStructure = tempPart.CreateReferenceFromObject(bodyPrimStructure);
                double minDistanceBetweenBracketHoleFaceAndBodyStructure = measurableBracketHoleFaceExtract.GetMinimumDistance(referenceBodyStructure);
                dictBracketHole["minDistanceBetweenHoleFaceAndBodyStructure"] = minDistanceBetweenBracketHoleFaceAndBodyStructure;
                Log.Information($"Min Distance of one hole face to the primary structure is {minDistanceBetweenBracketHoleFaceAndBodyStructure}mm");

                // CREATE AN AXIS LINE FOR EACH HOLE
                // IF IT IS NOT POSSIBLE TO UPDATE AXIS LINE
                // PASS AND CONTINUE TO LOOPING
                HybridShapeAxisLine bracketHoleFaceAxisLine;
                try
                {
                    bracketHoleFaceAxisLine = hsfTempPart.AddNewAxisLine(referenceBracketHoleFaceExtract);
                    tempPart.UpdateObject(bracketHoleFaceAxisLine);
                }
                catch (Exception)
                {
                    continue;
                }

                Reference referenceBracketHoleFaceAxisLine = tempPart.CreateReferenceFromObject(bracketHoleFaceAxisLine);
                Measurable measurableBracketHoleFaceAxisLine = spaWorkbenchTempPart.GetMeasurable(referenceBracketHoleFaceAxisLine);

                double minDistCubeAndBracketHoleAxis = -100;
                //if (null != bodyIpCube)
                //{
                //    Reference referenceBodyIpCube = tempPart.CreateReferenceFromObject(bodyIpCube);
                //    minDistanceBetweenBracketHoleAxisLineAndBodyIpCube = measurableBracketHoleFaceAxisLine.GetMinimumDistance(referenceBodyIpCube);
                //}
                foreach (Body cubeBody in publishedTmpCubeBodies)
                {
                    Reference cubeRef = tempPart.CreateReferenceFromObject(cubeBody);
                    double calcDist = measurableBracketHoleFaceAxisLine.GetMinimumDistance(cubeRef);
                    if (minDistCubeAndBracketHoleAxis == -100)
                    {
                        minDistCubeAndBracketHoleAxis = calcDist;
                    }
                    else
                    {
                        minDistCubeAndBracketHoleAxis = Math.Min(minDistCubeAndBracketHoleAxis, calcDist);
                    }
                }

                dictBracketHole["minDistanceBetweenHoleAxisLineAndBodyIpCube"] = minDistCubeAndBracketHoleAxis;
                Log.Information($"Minimun Distance of one bracket hole axis line to the IP Cube is {minDistCubeAndBracketHoleAxis}mm");

                listDictBracketHoles.Add(dictBracketHole);
            }

            // SEGMENT MOUNTING HOLES AND INTERFACE HOLES
            mountingHoleFaces = new List<object>();
            interfaceHoleFaces = new List<object>();
            foreach (Dictionary<string, object> dctBracketHole in listDictBracketHoles)
            {
                double holeBodyDist = Convert.ToDouble(dctBracketHole["minDistanceBetweenHoleFaceAndBodyStructure"]);
                double holeCubeDist = Convert.ToDouble(dctBracketHole["minDistanceBetweenHoleAxisLineAndBodyIpCube"]);

                // Try to find the mounting holes
                if (holeBodyDist >= 0 && holeBodyDist <= (clearanceTolerance + EPSILON) * MULTIPEP &&
                    holeCubeDist != 0)
                {
                    mountingHoleFaces.Add(dctBracketHole["extractObject"]);
                }
                // Try to find the interface hole
                else if (holeCubeDist == 0)
                {
                    interfaceHoleFaces.Add(dctBracketHole["extractObject"]);
                }
            }
        }

        /// <summary>
        /// Find holes from input extracted faces
        /// </summary>
        /// <param name="tempPartDoc">The part document for getting workbenches</param>
        /// <param name="listBracketFaces">The input face list</param>
        /// <param name="geoSetHoleFace">The result geometry set to insert found holes</param>
        private static void ExtractHolesFromPart(PartDocument tempPartDoc, List<Face> listBracketFaces, HybridBody geoSetHoleFace)
        {
            Part tempPart = tempPartDoc.Part;
            SPAWorkbench spaWorkbenchTempPart = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
            HybridShapeFactory hsfTempPart = (HybridShapeFactory)tempPart.HybridShapeFactory;

            // FOR EACH FACE IN BRACKET BODIES
            // FIND THE HOLES
            foreach (var bracketFace in listBracketFaces)
            {
                try
                {
                    var measurable = spaWorkbenchTempPart.GetMeasurable(bracketFace);
                    var radius = measurable.Radius;
                    var extractOfFace = hsfTempPart.AddNewExtract(bracketFace);
                    // extractOfFace.PropagationType = 2;
                    extractOfFace.Compute();
                    // CREATE BOUNDARY OF THE EXTRACTED FACES
                    var boundary = hsfTempPart.AddNewBoundaryOfSurface(extractOfFace as Reference);
                    // TRY TO JOIN BOUNDARY AND UPDATE
                    try
                    {
                        var join = hsfTempPart.AddNewJoin(boundary as Reference, boundary as Reference);
                        join.RemoveElement(1);
                        tempPart.UpdateObject(join);
                        Log.Debug($"BracketFace({bracketFace.get_Name()}) NOT a hole face found");
                    }
                    // THIS EXCEPTION WILL OCCUR IF BOUNDARY IS NOT A SINGLE CLOSED CURVE
                    catch (Exception)
                    {
                        ExtractHoleFromMultiBoundary(geoSetHoleFace, tempPart, spaWorkbenchTempPart,
                            hsfTempPart, bracketFace, extractOfFace, boundary);
                    }
                }
                catch (Exception)
                {
                    Log.Debug($"BracketFace({bracketFace.get_Name()}) is NOT the face for holes");
                }
            }
        }

        /// <summary>
        /// By getting a boundary object, we try to disassemble it and if we get two objects with same length, we found the hole
        /// </summary>
        /// <param name="geoSetHoleFace">The result geometry set to insert found holes</param>
        /// <param name="tempPart"></param>
        /// <param name="spaWorkbenchTempPart"></param>
        /// <param name="hsfTempPart"></param>
        /// <param name="potentialHoleFace">The potential hole face to added to the geometry set</param>
        /// <param name="extractOfFace">The face used to try to create axes for it directly</param>
        /// <param name="boundary">The input boundary to disassemble</param>
        private static void ExtractHoleFromMultiBoundary(HybridBody geoSetHoleFace, Part tempPart,
            SPAWorkbench spaWorkbenchTempPart, HybridShapeFactory hsfTempPart, Face potentialHoleFace,
            HybridShapeExtract extractOfFace, HybridShapeBoundary boundary)
        {
            try
            {
                // TRY TO DISASSEMBLE THE BOUNDARY
                Array datumsOfBoundary = hsfTempPart.AddNewDatums(boundary as Reference);
                // IF BOUNDARY IS CONSISTING OF TWO CURVES
                // CHECK IF THE CURVES HAVE THE SAME LENGTH
                // ONLY CYLINDRICAL HOLES CUTOUT EDGES WILL HAVE SAME LENGTHS
                if (datumsOfBoundary.Length == 2)
                {
                    var referenceFirstDatum = tempPart.CreateReferenceFromObject((AnyObject)datumsOfBoundary.GetValue(0));
                    var measurableFirstDatum = spaWorkbenchTempPart.GetMeasurable(referenceFirstDatum);
                    var lengthFirstDatum = measurableFirstDatum.Length;
                    var roundLengthFirstDatum = Math.Round(lengthFirstDatum, 3);
                    var referenceSecondDatum = tempPart.CreateReferenceFromObject((AnyObject)datumsOfBoundary.GetValue(1));
                    var measurableSecondDatum = spaWorkbenchTempPart.GetMeasurable(referenceSecondDatum);
                    var lengthSecondDatum = measurableSecondDatum.Length;
                    var roundLengthSecondDatum = Math.Round(lengthSecondDatum, 3);
                    if (roundLengthFirstDatum == roundLengthSecondDatum)
                    {
                        var extractOfBracketHoleFace = hsfTempPart.AddNewExtract(potentialHoleFace);
                        extractOfBracketHoleFace.Compute();
                        geoSetHoleFace.AppendHybridShape(extractOfBracketHoleFace);
                        Log.Information($"BracketFace({potentialHoleFace.get_Name()}) FOUND holes faces and added to bracketHoleFaceExtracts" +
                            $", 2 face-boundary lengths with same value {roundLengthSecondDatum}mm");
                    }
                    else
                    {
                        try
                        {
                            var tempAxis = hsfTempPart.AddNewAxisLine(extractOfFace as Reference);
                            if (tempAxis != null)
                            {
                                var extractOfBracketHoleFace = hsfTempPart.AddNewExtract(potentialHoleFace);
                                extractOfBracketHoleFace.Compute();
                                geoSetHoleFace.AppendHybridShape(extractOfBracketHoleFace);
                                Log.Information($"BracketFace({potentialHoleFace.get_Name()}) FOUND holes faces and added to bracketHoleFaceExtracts" +
                                    $", 2 face-boundary length has different values {roundLengthFirstDatum}mm and {roundLengthSecondDatum}mm");
                            }
                            else
                            {
                                Log.Debug($"BracketFace({potentialHoleFace.get_Name()}) found 2 face-boundary length with " +
                                    $"different values {roundLengthFirstDatum}mm and {roundLengthSecondDatum}mm. " +
                                    $"Not able to create axis for this face and NOT treated as hole");
                            }
                        }
                        catch (Exception e)
                        {
                            Log.Debug($"BracketFace({potentialHoleFace.get_Name()}) found 2 face-boundary length with " +
                                $"different values {roundLengthFirstDatum}mm and {roundLengthSecondDatum}mm. " +
                                $"Not able to create axis for this face and NOT treated as hole. {e.ToString()}");
                        }

                    }
                }
            }
            catch (Exception)
            {
                Log.Debug($"BracketFace({potentialHoleFace.get_Name()}) found multiple disconnected boundaries, but still not for holes.");
            }
        }

        private static void DeleteSameAxisLines(PartDocument documentDummyPart, Selection selectionRootProduct, HybridBody geometricalSet, SPAWorkbench spaWorkbenchDummyPart)
        {
            Part part = documentDummyPart.Part;

            // IDENTIFY SAME AXIS LINES AND DELETE DUPLICATES
            List<HybridShape> listLines = new List<HybridShape>();
            foreach (HybridShape hybridShapeLine in geometricalSet.HybridShapes)
            {
                listLines.Add(hybridShapeLine);
            }

            List<HybridShape> listAxisLinesToBeDeleted = new List<HybridShape>();
            foreach (var combination in GetCombinations(listLines, 2))
            {
                var res = combination.ToArray();
                var x = res[0];
                var y = res[1];
                Reference refX = part.CreateReferenceFromObject(x);
                Reference refY = part.CreateReferenceFromObject(y);
                Measurable measurableX = spaWorkbenchDummyPart.GetMeasurable(refX);
                double angleBetweenTwoAxisLines = Math.Round(measurableX.GetAngleBetween(refY), 3);
                double distanceBetweenTwoAxisLines = Math.Round(measurableX.GetMinimumDistance(refY), 3);
                if (angleBetweenTwoAxisLines % 180.0 == 0 && distanceBetweenTwoAxisLines == 0)
                {
                    if (!listAxisLinesToBeDeleted.Contains(y))
                    {
                        listAxisLinesToBeDeleted.Add(y);
                    }
                }
            }

            foreach (HybridShape axisLineToBeDeleted in listAxisLinesToBeDeleted)
            {
                selectionRootProduct.Clear();
                selectionRootProduct.Add(axisLineToBeDeleted);
                selectionRootProduct.Delete();
                selectionRootProduct.Clear();
            }
        }

        private static IEnumerable<IEnumerable<T>> GetCombinations<T>(IEnumerable<T> elements, int k)
        {
            return k == 0 ? new[] { new T[0] } :
                elements.SelectMany((element, index) => GetCombinations(elements.Skip(index + 1), k - 1).Select(c => (new[] { element }).Concat(c)));
        }

        /// <summary>
        /// Find the side surface of the drum, get two edege, find center points and 
        /// connect the center points to get the axis of the drum, could be circle or elliptic
        /// </summary>
        /// <param name="selection"></param>
        /// <param name="drumProd"></param>
        /// <param name="bodyDrum"></param>
        /// <param name="hbFactory"></param>
        /// <param name="nonPfHbBody"></param>
        /// <param name="centerPtHbBody"></param>
        /// <param name="checkHbBody"></param>
        /// <param name="partDoc"></param>
        /// <param name="partnumber"></param>
        /// <param name="axisLineOfDrum"></param>
        private static void CreateAxisLineForNonPlanarSurfaceOfDrum(Selection selection, Product drumProd,
            Body bodyDrum, HybridShapeFactory hbFactory, HybridBody nonPfHbBody, HybridBody centerPtHbBody,
            HybridBody checkHbBody, HybridBody boundariesBody, PartDocument partDoc, string partnumber,
            out HybridShapeLinePtPt axisLineOfDrum)
        {
            axisLineOfDrum = null;

            // FIND ALL FACES OF DRUM BODY
            // AND APPEND INTO A LIST
            selection.Clear();
            selection.Add(bodyDrum);
            selection.Search("Topology.Face,sel");

            List<Face> faceList = new List<Face>();
            for (int i = 1; i <= selection.Count; i++)
            {
                Face selectedFace = (Face)selection.Item2(i).Value;
                faceList.Add(selectedFace);
            }

            selection.Clear();

            // FOR EACH DRUM FACE
            // TRY TO IDENTIFY NON PLANAR FACES
            foreach (Face face in faceList)
            {
                if (!(face is PlanarFace))
                {
                    //CREATE AN EXTRACT FROM CYLINDRICAL/ELLIPTICAL DRUM FACE
                    partDoc.Part.InWorkObject = nonPfHbBody;
                    var extractOfNonPlanarDrumFace = hbFactory.AddNewExtract(face);
                    extractOfNonPlanarDrumFace.PropagationType = 3;
                    extractOfNonPlanarDrumFace.Compute();
                    nonPfHbBody.AppendHybridShape(extractOfNonPlanarDrumFace);

                    // CREATE AN AXIS LINE FROM NON PLANAR SURFACE
                    //var extract_of_non_planar_drum_face1 = nonPfHbBody.HybridShapes.Item(1);
                    //var boundaryOfNonPlanarDrumFace = hbFactory.AddNewBoundaryOfSurface(extract_of_non_planar_drum_face1 as Reference);
                    var boundaryOfNonPlanarDrumFace = hbFactory.AddNewBoundaryOfSurface(extractOfNonPlanarDrumFace as Reference);
                    boundaryOfNonPlanarDrumFace.Compute();

                    var datumsOfBoundary = hbFactory.AddNewDatums(boundaryOfNonPlanarDrumFace as Reference);
                    foreach (var eachDatum in datumsOfBoundary)
                    {
                        var extractEdge = hbFactory.AddNewExtract(eachDatum as Reference);
                        extractEdge.Compute();
                        // Add extracted drum boundary edges to the hybrid body, they will be used to compute radius later
                        boundariesBody.AppendHybridShape(extractEdge);
                        Point centerPointOfExtractedEdge = hbFactory.AddNewPointCenter(extractEdge as Reference);
                        centerPointOfExtractedEdge.Compute();
                        centerPtHbBody.AppendHybridShape(centerPointOfExtractedEdge);
                    }

                    Point centerPoint1OfDrumEdge = centerPtHbBody.HybridShapes.Item(1) as Point;
                    Point centerPoint2OfDrumEdge = centerPtHbBody.HybridShapes.Item(2) as Point;
                    axisLineOfDrum = hbFactory.AddNewLinePtPt(centerPoint1OfDrumEdge as Reference, centerPoint2OfDrumEdge as Reference);
                    axisLineOfDrum.SetLengthType(1);
                    axisLineOfDrum.Compute();
                    checkHbBody.AppendHybridShape(axisLineOfDrum);
                }
            }
        }

        /// <summary>
        /// Create a point hybrid shape using cog of a given part
        /// </summary>
        /// <param name="partProd">The input part to create point from cog</param>
        /// <param name="targetPartDoc">The working part need to be updated</param>
        /// <param name="hbFactory"></param>
        /// <param name="hbBody"></param>
        /// <returns></returns>
        private static HybridShapePointCoord CreatePartCogPoint(Product partProd, PartDocument targetPartDoc,
            HybridShapeFactory hbFactory, HybridBody hbBody)
        {
            double[] cubeCog = CatiaProdUtils.GetProductCogPosition(partProd);
            HybridShapePointCoord pointOfCog = hbFactory.AddNewPointCoord(cubeCog[0], cubeCog[1], cubeCog[2]);
            hbBody.AppendHybridShape(pointOfCog);
            targetPartDoc.Part.Update();
            return pointOfCog;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="selection"></param>
        /// <param name="bodyBoundingBox"></param>
        /// <param name="hbFactory"></param>
        /// <param name="intSolidFacesHbBody"></param>
        /// <param name="edgOfFtHoleHbBody"></param>
        /// <param name="axisHbBody"></param>
        /// <param name="spaWorkBench"></param>
        /// <param name="partDoc"></param>
        public static int ComputeAxisOfFeedthroughHole(Selection selection, Body bodyBoundingBox, HybridShapeFactory hbFactory, HybridBody intSolidFacesHbBody,
                                                HybridBody edgOfFtHoleHbBody, HybridBody axisHbBody, SPAWorkbench spaWorkBench, PartDocument partDoc)
        {
            int result = 0;
            Part part = partDoc.Part;

            // FIND ALL FACES OF BOUNDING BOX INTERSECT BODY
            // AND APPEND INTO A LIST
            selection.Clear();
            selection.Add(bodyBoundingBox);
            selection.Search("Topology.Face,sel");
            List<Face> listBoundingBoxIntersectFaces = new List<Face>();

            for (int i = 1; i <= selection.Count2; i++)
            {
                Face selected_face = (Face)selection.Item2(i).Value;
                listBoundingBoxIntersectFaces.Add(selected_face);
            }
            selection.Clear();

            // FOR EACH BOUNDING BOX INTERSECT FACE
            // TRY TO FIND THE FEED THROUGH HOLE FACE
            foreach (Face boundingBoxIntersectFace in listBoundingBoxIntersectFaces)
            {
                ExtractHoleFromSingleFace(hbFactory, intSolidFacesHbBody, edgOfFtHoleHbBody,
                    spaWorkBench, partDoc, boundingBoxIntersectFace);
            }

            // CREATE AN AXIS LINE OF FEED THROUGH CUTOUT FACE
            HybridShapes geoSetCircleEdgeOfFt = edgOfFtHoleHbBody.HybridShapes;
            double maxDrumRadius = 0.0;
            double secondMaxDrumRadius = 0.0;
            HybridShapeExtract feedThroughHoleFaceEdge1 = null;
            HybridShapeExtract feedThroughHoleFaceEdge2 = null;

            // Calculate the two edges with max radius
            foreach (HybridShapeExtract edge in geoSetCircleEdgeOfFt)
            {
                double drumRadius = CalculateRadiusOfHoleEdge(spaWorkBench, hbFactory, part, edge);
                if (drumRadius > maxDrumRadius)
                {
                    feedThroughHoleFaceEdge2 = feedThroughHoleFaceEdge1;
                    feedThroughHoleFaceEdge1 = edge;
                    maxDrumRadius = drumRadius;
                }
                else if (drumRadius > secondMaxDrumRadius)
                {
                    feedThroughHoleFaceEdge2 = edge;
                    secondMaxDrumRadius = drumRadius;
                }
            }

            Point circleEdgeCenterPoint1 = hbFactory.AddNewPointCenter(feedThroughHoleFaceEdge1 as Reference);
            Point circleEdgeCenterPoint2 = hbFactory.AddNewPointCenter(feedThroughHoleFaceEdge2 as Reference);
            HybridShapeLinePtPt axisLineOfFeedThroughHole = hbFactory.AddNewLinePtPt(
                circleEdgeCenterPoint1 as Reference,
                circleEdgeCenterPoint2 as Reference);
            // infinite line
            axisLineOfFeedThroughHole.SetLengthType(1);
            axisLineOfFeedThroughHole.Compute();
            axisHbBody.AppendHybridShape(axisLineOfFeedThroughHole);
            Log.Information($"Feedthrough 2.5mm check: Axes line for the Feedthrough hole created");

            return result;
        }

        private static void ExtractHoleFromSingleFace(HybridShapeFactory hbFactory, HybridBody intSolidFacesHbBody,
            HybridBody edgOfFtHoleHbBody, SPAWorkbench spaWorkBench, PartDocument partDoc, Face boundingBoxIntersectFace)
        {
            try
            {
                // CREATE AN EXTRACT FROM FACE AND APPEND INTO GEOMETRICAL SET
                HybridShapeExtract extractOfFace = hbFactory.AddNewExtract(boundingBoxIntersectFace);
                extractOfFace.PropagationType = 2;
                extractOfFace.Compute();
                intSolidFacesHbBody.AppendHybridShape(extractOfFace);
                // CREATE BOUNDARY OF THE EXTRACTED FACES
                var boundary = hbFactory.AddNewBoundaryOfSurface(extractOfFace as Reference);
                // TRY TO JOIN BOUNDARY AND UPDATE
                try
                {
                    // TRY TO JOIN BOUNDARY AND UPDATE
                    var join = hbFactory.AddNewJoin(boundary as Reference, boundary as Reference);
                    join.RemoveElement(1);
                    partDoc.Part.UpdateObject(join);
                }
                // THIS EXCEPTION WILL OCCUR IF BOUNDARY IS NOT A SINGLE CLOSED CURVE
                catch (Exception)
                {
                    try
                    {
                        // TRY TO DISASSEMBLE THE BOUNDARY
                        var datumsOfBoundary = hbFactory.AddNewDatums(boundary as Reference);
                        // IF BOUNDARY IS CONSISTING OF TWO CURVES
                        // CHECK IF THE CURVES HAVE THE SAME LENGTH
                        // ONLY CYLINDRICAL HOLES AND ELLIPTICAL/HOLES CUTOUT EDGES WILL HAVE SAME LENGTHS
                        if (datumsOfBoundary.Length == 2)
                        {
                            Reference referenceFirstDatum = partDoc.Part.CreateReferenceFromObject((AnyObject)datumsOfBoundary.GetValue(0));
                            Measurable measurableFirstDatum = spaWorkBench.GetMeasurable(referenceFirstDatum);
                            double lengthFirstDatum = measurableFirstDatum.Length;
                            double roundLengthFirstDatum = Math.Round(lengthFirstDatum, 3);
                            Reference referenceSecondDatum = partDoc.Part.CreateReferenceFromObject((AnyObject)datumsOfBoundary.GetValue(1));
                            Measurable measurableSecondDatum = spaWorkBench.GetMeasurable(referenceSecondDatum);
                            double lengthSecondDatum = measurableSecondDatum.Length;
                            double roundLengthSecondDatum = Math.Round(lengthSecondDatum, 3);

                            if (roundLengthFirstDatum == roundLengthSecondDatum)
                            {
                                var extractFeedThroughCutoutEdge1 = hbFactory.AddNewExtract(datumsOfBoundary.GetValue(0) as Reference);
                                extractFeedThroughCutoutEdge1.Compute();
                                edgOfFtHoleHbBody.AppendHybridShape(extractFeedThroughCutoutEdge1);
                                var extractFeedThroughCutoutEdge2 = hbFactory.AddNewExtract(datumsOfBoundary.GetValue(1) as Reference);
                                extractFeedThroughCutoutEdge2.Compute();
                                edgOfFtHoleHbBody.AppendHybridShape(extractFeedThroughCutoutEdge2);
                                Log.Information($"Feedthrough 2.5mm check: Feedthrough boundary from the intersection body found");
                            }
                        }
                    }
                    catch (Exception)
                    {
                        Log.Debug($"Feedthrough 2.5mm check: Error happens by finding cut out edges with same length.");
                    }
                }
            }
            catch (Exception)
            {
                Log.Debug($"Feedthrough 2.5mm check: Error happens by extracting bounding box cut out faces and boundaries.");
            }

        }

        private static void CreateSphereAndIntersectWithCrossbeam(Product cubeProd, Product crossBeamProd, Selection selection,
            PartDocument partDoc, HybridShapeFactory hbFactory, ShapeFactory shapeFactory, double drumRadius,
            HybridBody checkHbBody, out HybridShapePointCoord pointOfCog, out string partnumber)
        {
            pointOfCog = CreatePartCogPoint(cubeProd, partDoc, hbFactory, checkHbBody);
            Reference refCog = partDoc.Part.CreateReferenceFromObject(pointOfCog);
            HybridShapeSphere cogSphere = hbFactory.AddNewSphere(refCog, null, drumRadius * 2.0, -90, 90, 0, 360);
            // value 1 for whole sphere
            cogSphere.Limitation = 1;
            checkHbBody.AppendHybridShape(cogSphere);
            partDoc.Part.UpdateObject(cogSphere);

            // create sphere body
            partDoc.Part.InWorkObject = partDoc.Part.MainBody;
            Reference sphereRef = partDoc.Part.CreateReferenceFromObject(cogSphere);
            var closedSphere = shapeFactory.AddNewCloseSurface(sphereRef);
            partDoc.Part.Update();

            Part crossBeamPart = ((PartDocument)crossBeamProd.ReferenceProduct.Parent).Part;
            partnumber = crossBeamProd.get_PartNumber();
            Body crossBeanBody = (Body)crossBeamPart.MainBody;

            // Publish crossbeam body
            double[] absTrafoCrossbeam = new double[12];
            string pathCrossbeam = "";
            CatiaProdUtils.GetAbsTrafo(crossBeamProd, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoCrossbeam, ref pathCrossbeam);
            //PublishFirstBody(crossBeamProd, crossBeamPart, pathCrossbeam);

            selection.Clear();
            //selection.Add((AnyObject)crossBeamProd.Publications.Item(publishName).Valuation);
            selection.Add(GetReferenceToRootFirstBody(crossBeamPart, pathCrossbeam));
            //selection.Add(crossBeanBody);
            selection.Copy();
            selection.Clear();
            selection.Add(partDoc.Part);
            selection.PasteSpecial("CATPrtResultWithOutLink");
            selection.Clear();

            Intersect intesetBody = shapeFactory.AddNewIntersect(partDoc.Part.MainBody);
            partDoc.Part.Update();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cubeProd"></param>
        /// <param name="crossBeamProd"></param>
        /// <param name="selection"></param>
        /// <param name="partDoc"></param>
        /// <param name="hbFactory"></param>
        /// <param name="shapeFactory"></param>
        /// <param name="drumRadius"></param>
        /// <param name="checkHbBody"></param>
        /// <param name="pointOfCog"></param>
        /// <param name="partnumber"></param>
        /// <param name="bodyBoundingBox"></param>
        private static int CreateBoundingBoxAndIntersectWithCrossbeam(Product cubeProd, PartDocument partDoc, HybridShapeFactory hbFactory,
            ShapeFactory shapeFactory, double drumRadius, HybridBody checkHbBody, out HybridShapePointCoord pointOfCog,
            out string partnumber, out Body bodyBoundingBox)
        {
            int result = -1;
            Part tempPart = partDoc.Part;
            partnumber = cubeProd.get_PartNumber();
            Bodies tempPartBodies = tempPart.Bodies;
            Body cubeBody = tempPartBodies.Item("IP_CUBE");
            Body structureBody = tempPartBodies.Item("STRUCTURE");

            Reference referenceBodyIpCube = partDoc.Part.CreateReferenceFromObject(cubeBody);
            pointOfCog = CreatePartCogPoint(cubeProd, partDoc, hbFactory, checkHbBody);
            HybridShapeExtract extractBodyIpCube = hbFactory.AddNewExtract(referenceBodyIpCube);
            extractBodyIpCube.Compute();
            bodyBoundingBox = partDoc.Part.Bodies.Add();
            bodyBoundingBox.set_Name("BOUNDING BOX");
            partDoc.Part.InWorkObject = bodyBoundingBox;
            shapeFactory.AddNewCloseSurface(extractBodyIpCube as Reference);

            // DIVIDING 2.5 IS DUE TO CUBE EDGE LENGTHS
            double scalingFactor = drumRadius / 2.5 * SCALING_FACTOR_MULTIPLIER_FOR_BOUNDING_BOX_CONSTRUCTION;

            shapeFactory.AddNewScaling(pointOfCog as Reference, scalingFactor);
            partDoc.Part.UpdateObject(bodyBoundingBox);

            try
            {
                // INTERSECT BODIES OF BOUNDING BOX AND STRUCTURE
                Intersect intersect_body = shapeFactory.AddNewIntersect(structureBody);
                partDoc.Part.UpdateObject(intersect_body);
                partDoc.Part.UpdateObject(bodyBoundingBox);
                bodyBoundingBox.set_Name("INTERSECT_SOLID_FOR_CHECK");
                Log.Information($"Feedthrough 2.5mm check: Intersect of bounding cube with primary structure found");
            }
            catch (Exception)
            {
                Log.Error($"Feedthrough 2.5mm check: Failed by intersecting bounding box with primary structure");
                result = 3004;
            }

            return result;
        }

        private static void CopyCubeCrossBeanToTemp(Product cubeProd, Product crossBeamProd, Selection selection, Product tempProduct)
        {
            selection.Clear();
            selection.Add(crossBeamProd);
            selection.Add(cubeProd);
            selection.Copy();
            selection.Clear();
            selection.Add(tempProduct);
            selection.Paste();
            selection.Clear();
        }

        private static int CalulateDrumRadiusMajorAxis(Body secondaryBody, Selection selection, SPAWorkbench spaWorkBench, PartDocument partDoc,
            Line axisLineOfDrum, HybridShapeFactory hbFactory, HybridBody nonPfHbBody, HybridBody boundariesBody, out double drumRadius)
        {
            Part part = partDoc.Part;
            drumRadius = 0.0;
            //selection.Add(secondaryBody);
            //selection.Search("Topology.Edge,sel");
            //List<SelectedElement> drumEdgeList = new List<SelectedElement>();
            //for (int i = 1; i <= selection.Count; i++)
            //{
            //    drumEdgeList.Add(selection.Selection.Item(i));
            //}

            // Try use boundary edge instead of drum body extract
            //HybridShapeExtract drumFace = (HybridShapeExtract)nonPfHbBody.HybridShapes.Item(1);
            //drumRadius = CalculateRadiusOfHoleEdge(spaWorkBench, hbFactory, part, drumFace);

            HybridShapeExtract boundaryEdge = (HybridShapeExtract)boundariesBody.HybridShapes.Item(1);
            drumRadius = CalculateRadiusOfHoleEdge(spaWorkBench, hbFactory, part, boundaryEdge);

            //ArrayList centerList = new ArrayList();
            //foreach (SelectedElement edge in drumEdgeList)
            //{
            //    string type = edge.Type;
            //    if (!type.Contains("TriDimFeatEdge"))
            //    {
            //        continue;
            //    }

            //    HybridShapeExtract extractShape = hbFactory.AddNewExtract(edge.Reference);
            //    drumRadius = CalculateRadiusOfHoleEdge(spaWorkBench, hbFactory, part, extractShape);

            //    if (drumRadius > EPSILON)
            //    {
            //        break;
            //    }
            //}

            if (drumRadius < EPSILON)
            {
                Log.Error($"Feedthrough 2.5mm check: Drum radius({drumRadius}) is too small.");
                return 1;
            }

            return 0;
        }

        private static double CalculateRadiusOfHoleEdge(SPAWorkbench spaWorkBench, HybridShapeFactory hbFactory,
             Part part, HybridShapeExtract extractShape)
        {
            double drumRadius = 0.0;
            Reference extractRef = part.CreateReferenceFromObject(extractShape);
            Measurable measure = spaWorkBench.GetMeasurable(extractRef);
            // TRY TO MEASURE RADIUS OF DRUM WITH measurable.radius
            try
            {
                drumRadius = measure.Radius;
                Log.Information($"Feedthrough 2.5mm check: found circle drum radius {drumRadius}");
                // THIS EXCEPTION WILL OCCUR FOR ELLIPTICAL FEED THROUGH CUTOUTS
            }
            catch (Exception)
            {
                // GET ELLIPTICAL FEED TROUGH CUTOUTS SEMI MINOR AXES LENGTH FROM MEASURING THE DISTANCE BETWEEN
                // AXIS LINE AND OUTER SURFACE
                try
                {
                    HybridShapeAxisLine drumMajorAxis = hbFactory.AddNewAxisLine(extractRef);
                    drumMajorAxis.AxisLineType = 1;
                    drumMajorAxis.Compute();
                    Reference axisRef = part.CreateReferenceFromObject(drumMajorAxis);
                    HybridShapeIntersection intersectionMajorAxisWithEdge = hbFactory.AddNewIntersection(axisRef, extractRef);
                    intersectionMajorAxisWithEdge.Compute();
                    //Reference intersectionRef = part.CreateReferenceFromObject(intersectionMajorAxisWithEdge);
                    //Array intersectionDatums = hbFactory.AddNewDatums(intersectionRef);
                    Array intersectionDatums = hbFactory.AddNewDatums(intersectionMajorAxisWithEdge as Reference);
                    if (intersectionDatums.Length == 2)
                    {
                        object point1 = intersectionDatums.GetValue(0);
                        Reference point1Ref = part.CreateReferenceFromObject((AnyObject)point1);
                        object point2 = intersectionDatums.GetValue(1);
                        Reference point2Ref = part.CreateReferenceFromObject((AnyObject)point2);
                        Measurable measureLength = spaWorkBench.GetMeasurable(point1Ref);
                        double length = measureLength.GetMinimumDistance(point2Ref);
                        drumRadius = length / 2.0;
                        Log.Information($"Feedthrough 2.5mm check: found elliptic drum major axis {length} radius {drumRadius}");
                    }
                }
                catch (Exception e)
                {
                    Log.Information($"Feedthrough 2.5mm check: Error happend by calculating elliptic drum radius on one edge, contine... {e.ToString()}");
                }
            }

            return drumRadius;
        }

        public static void GetSecondaryFromIp(IpvCheckProperty property, Product prod, ref ICollection<Product> secondaryList,
            string secondaryType, List<string> proposalPartListFromDB)
        {
            secondaryList.Clear();
            property.OriginProposalList.Clear();

            // Bugfixing: as for non-std bracket, the type is extended as follows
            if (secondaryType == AdfPart && property.IsBracketCheck && !property.IsStandard) // adfPart was previously for non-std parts
            {
                if (property.Is3cCheck)
                {
                    secondaryType = "ADF-ASSY/ADAP-ASSY";
                }
                else if (property.IsEdgeDistCheck || property.IsFilletDistCheck || 
                    property.IsBboxCheck || property.IsPitchDistCheck || property.Is2Dot5mmCheck)
                {
                    secondaryType = "ADF-Part/ADAP-Part";
                }
            }

            ICollection<Product> foundList = new HashSet<Product>();
            if (prod is null)
            {
                secondaryList = (ICollection<Product>)secondaryList.Concat(foundList.ToList());
                property.OriginProposalList = (ICollection<Product>)secondaryList.Concat(foundList.ToList());
                return;
            }

            // Get all siblings of the IP product and check the type
            foreach (Product p in (Products)prod.Parent)
            {
                p.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);

                // Either find the proposal using catia attribute or using DB query result
                if ((null != proposalPartListFromDB &&
                    proposalPartListFromDB.Count > 0 &&
                    !string.IsNullOrWhiteSpace(p.get_PartNumber()) &&
                    proposalPartListFromDB.Contains(p.get_PartNumber()))
                    || (p != null && !string.IsNullOrWhiteSpace(p.get_Nomenclature()) 
                    && secondaryType.ToLower().Contains(p.get_Nomenclature().ToLower())) )
                {
                    foundList.Add(p);
                }
                else
                {
                    GetSecondaryFromIpRecursive(p, ref foundList, secondaryType, proposalPartListFromDB);
                }
            }
            secondaryList = foundList.ToList();
            property.OriginProposalList = foundList.ToList();
            Log.Information($"GetSecondaryFromIp() found {foundList.Count} {secondaryType} nodes");
        }

        private static void GetSecondaryFromIpRecursive(Product prod, ref ICollection<Product> secondaryList,
            string secondaryType, List<string> proposalPartListFromDB)
        {
            foreach (Product p in (Products)prod.Products)
            {
                p.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);

                // Either find the proposal using catia attribute or using DB query result
                if ((null != proposalPartListFromDB &&
                    proposalPartListFromDB.Count > 0 &&
                    !string.IsNullOrWhiteSpace(p.get_PartNumber()) &&
                    proposalPartListFromDB.Contains(p.get_PartNumber()))
                    || (p != null && !string.IsNullOrWhiteSpace(p.get_Nomenclature()) &&
                    secondaryType.ToLower().Contains(p.get_Nomenclature().ToLower())) )
                {
                    secondaryList.Add(p);
                }
                else
                {
                    GetSecondaryFromIpRecursive(p, ref secondaryList, secondaryType, proposalPartListFromDB);
                }
            }
        }

        public static void GetSecondaryFromIpForTrend(Product prod, ref ICollection<Product> secondaryList,
            List<string> proposalPartListFromDB)
        {
            //secondaryList.Clear();
            ICollection<Product> foundList = new HashSet<Product>();
            if (prod is null)
            {
                secondaryList = (ICollection<Product>)secondaryList.Concat(foundList.ToList());
                return;
            }

            string rootProdName = System.IO.Path.GetFileNameWithoutExtension(CatiaCommonUtils.GetNameActiveDoc());

            // PUT secondaryProd PRODUCT IN DESIGN MODE IF NOT
            try
            {
                string _ = prod.get_PartNumber();
            }
            catch (Exception)
            {
                prod.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
            }

            Products ps = null;
            if (prod.get_PartNumber() == rootProdName)
            {
                ps = (Products)prod;
            }
            else
            {
                string checkPartNumber = ((Product)prod.Parent).get_PartNumber();
                if (checkPartNumber != rootProdName && checkPartNumber.ToLower().Contains("bfh"))
                {
                    ps = (Products)prod.Parent;
                }
                else
                {
                    return;
                }


            }

            // Get all siblings of the IP product and check the type
            foreach (Product p in ps)
            {
                p.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                if (p.get_PartNumber() == rootProdName)
                {
                    continue;
                }

                if (p != null && proposalPartListFromDB.Contains(p.get_PartNumber().ToLower(), StringComparer.OrdinalIgnoreCase))
                {
                    foundList.Add(p);
                }
                else
                {
                    GetSecondaryFromIpRecursiveForTrend(p, ref foundList, proposalPartListFromDB);
                }
            }
            secondaryList = foundList.Distinct().ToList();
            Log.Information($"GetSecondaryFromIpForTrend() found {foundList.Count} nodes");
        }

        private static void GetSecondaryFromIpRecursiveForTrend(Product prod,
            ref ICollection<Product> secondaryList, List<string> proposalPartListFromDB)
        {
            foreach (Product p in (Products)prod.Products)
            {
                if (proposalPartListFromDB.Contains(p.get_PartNumber().ToLower(), StringComparer.OrdinalIgnoreCase))
                {
                    secondaryList.Add(p);
                }
                else
                {
                    GetSecondaryFromIpRecursiveForTrend(p, ref secondaryList, proposalPartListFromDB);
                }
            }
        }

        //public static List<Product> GetBracketFromIp(Product ipProc, bool isStd)
        //{
        //    HashSet<Product> foundList = new HashSet<Product>();
        //    if (null != ipProc)
        //    {
        //        if (isStd)
        //        {
        //            return GetStandardPartFromIp(ipProc);
        //        }

        //        foreach (Product parentProd in (Products)ipProc.Parent)
        //        {
        //            //if (isStd && (parentProd.get_PartNumber().StartsWith("NAS") || parentProd.get_PartNumber().StartsWith("ABS")))
        //            if (!isStd && parentProd.get_Definition().Contains("BRACKET") && parentProd.Products.Count == 0)
        //            {
        //                string bracketPartNumber = parentProd.get_PartNumber();
        //                foundList.Add(parentProd);
        //            }
        //            else
        //            {
        //                RecursiveFindBracketFromIP(parentProd, isStd, ref foundList);
        //            }
        //        }
        //    }

        //    return foundList.ToList();
        //}

        /// <summary>
        /// Get ADF-PART instances from the given IP product.
        /// We will first go up to parent node and then start search recursively to the leaf
        /// </summary>
        /// <param name="ipProd">starting product</param>
        /// <returns></returns>
        //public static List<Product> GetAdfPartFromIp(Product ipProd)
        //{
        //    HashSet<Product> foundList = new HashSet<Product>();

        //    if (ipProd is null)
        //    {
        //        return foundList.ToList(); ;
        //    }

        //    Products products = null;
        //    if (ipProd.Parent is Products)
        //    {
        //        products = ipProd.Parent as Products;
        //    }

        //    if (ipProd.Parent is Product || (null != products) && products.Parent is Product)
        //    {
        //        Product parentProd = (Product)products?.Parent ?? (Product)ipProd.Parent;

        //        if (parentProd.get_Nomenclature().StartsWith("ADF-PART")) //&& (parentProd.get_Definition().Contains("Cylinder")))
        //        {
        //            foundList.Add(parentProd);
        //        }
        //        else
        //        {
        //            RecursiveAdfPartFromIp(parentProd, ref foundList);
        //        }
        //    }

        //    Log.Information($"GetAdfPartFromIp() found {foundList.Count} ADF-PART nodes");
        //    return foundList.ToList();
        //}

        public static Part GetPart(Product bracketProd)
        {
            if (bracketProd != null)
            {
                PartDocument bracketDoc = (PartDocument)bracketProd.ReferenceProduct.Parent;
                if (null != bracketDoc)
                {
                    return bracketDoc.Part as Part;
                }
            }
            return null;
        }

        //private static List<Product> GetStandardPartFromIp(Product ipProd)
        //{
        //    HashSet<Product> foundList = new HashSet<Product>();

        //    if (ipProd is null)
        //    {
        //        return foundList.ToList(); ;
        //    }

        //    Products products = null;
        //    if (ipProd.Parent is Products)
        //    {
        //        products = ipProd.Parent as Products;
        //    }

        //    if (ipProd.Parent is Product || (null != products) && products.Parent is Product)
        //    {
        //        Product parentProd = (Product)products?.Parent ?? (Product)ipProd.Parent;

        //        if (parentProd.get_Nomenclature().ToLower().StartsWith("std")) //&& (parentProd.get_Definition().Contains("Cylinder")))
        //        {
        //            foundList.Add(parentProd);
        //        }
        //        else
        //        {
        //            RecursiveStandardPartFromIp(parentProd, ref foundList);
        //        }
        //    }

        //    Log.Information($"GetAdfPartFromIp() found {foundList.Count} ADF-PART nodes");
        //    return foundList.ToList();
        //}
        //private static void RecursiveStandardPartFromIp(Product prod, ref HashSet<Product> foundList)
        //{
        //    foreach (Product p in (Products)prod.Products)
        //    {
        //        if (p.get_Nomenclature().ToLower().StartsWith("std"))// && (p.get_Definition().Contains("Cylinder")))
        //        {
        //            foundList.Add(p);
        //        }
        //        else
        //        {
        //            RecursiveStandardPartFromIp(p, ref foundList);
        //        }
        //    }
        //}

        //private static void RecursiveAdfPartFromIp(Product prod, ref HashSet<Product> foundList)
        //{
        //    foreach (Product p in (Products)prod.Products)
        //    {
        //        if (p.get_Nomenclature().StartsWith("ADF-PART"))// && (p.get_Definition().Contains("Cylinder")))
        //        {
        //            foundList.Add(p);
        //        }
        //        else
        //        {
        //            RecursiveAdfPartFromIp(p, ref foundList);
        //        }
        //    }
        //}

        //private static void RecursiveFindBracketFromIP(Product prod, Boolean isStd, ref HashSet<Product> foundList)
        //{
        //    foreach (Product childProd in (Products)prod.Products)
        //    {
        //        if (isStd && (childProd.get_PartNumber().StartsWith("NAS") || childProd.get_PartNumber().StartsWith("ABS")))
        //        {
        //            foundList.Add(childProd);
        //        }
        //        else if (isStd == false && childProd.get_Definition().Contains("BRACKET") && childProd.Products.Count == 0)
        //        {
        //            foundList.Add(childProd);
        //        }
        //        else
        //        {
        //            RecursiveFindBracketFromIP(childProd, isStd, ref foundList);
        //        }
        //    }
        //}

        public static List<Product> GetCubesFromIp(Product ipProduct)
        {
            List<Product> listCubes = new List<Product>();
            foreach (Product childProd in ipProduct.Products)
            {
                if (childProd.get_Name().Contains("CUB"))
                {
                    listCubes.Add(childProd);
                }
            }
            return listCubes;
        }

        /// <summary>
        /// Ask user to selected the cross bean
        /// </summary>
        /// <returns></returns>
        public static Product SelectCrossBeam()
        {
            Document activeDoc = CatiaCommonUtils.GetActiveDoc();

            if (null != activeDoc)
            {
                activeDoc.Selection.Clear();
                object[] filters = new object[1] { "Face" };
                string status = activeDoc.Selection.SelectElement2(filters, "Can you please select a face from the CrossBeam of the bracket", true);
                if (status != "Cancel")
                {
                    return (Product)activeDoc.Selection.Item2(1).LeafProduct;
                }
            }

            return null;
        }

        /// <summary>
        /// Get X value from the selected cross beam part
        /// </summary>
        /// <returns></returns>
        public static string GetXFromCrossBeam()
        {
            Product selectedBean = SelectCrossBeam();

            if (selectedBean != null)
            {
                return selectedBean.get_Definition();
            }

            return "";
        }

        /// <summary>
        /// Get related CI/DS from the IP based on the nomenclature value
        /// </summary>
        /// <param name="ipProd"></param>
        /// <param name="nomenclature"></param>
        /// <returns></returns>
        public static Product GetCiDs(Product ipProd, string nomenclature)
        {
            Product ci = ipProd;
            if (ipProd != null)
            {
                do
                {
                    ci = (Product)ci.Parent;
                } while (null != ci && !(ci.get_Nomenclature() == nomenclature));

            }
            return ci;
        }

        /// <summary>
        /// Check if bracket clashs
        /// </summary>
        /// <param name="firstProd">Product could be cylinder, bracket</param>
        /// <param name="cubeProd">Product of the Cube</param>
        /// <returns></returns>
        public static IpvClashResult ComputeClash(IpvCheckProperty property, Product firstProd, ref Product cubeProd,
            ref Product primStructProd, string ipPartNumber = null, double tolerance = 0.0)
        {
            IpvClashResult clashResult = new IpvClashResult();
            ProductDocument activeDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            if (activeDoc is null)
            {
                return null;
            }

            Selection currentSelection = activeDoc.Selection;
            currentSelection.Clear();
            // Get the Clash factory object (Clashes) with GetTechnologicalObject()
            Product activeProd = (Product)activeDoc.Product;
            Clashes clashes = (Clashes)activeProd.GetTechnologicalObject("Clashes");

            if (null != firstProd)
            {
                // Initialize Clash by adding only product to the Clash object
                // The clash will calcuate peneration, contact and clearance
                // The clash calculation is between the product and all other products in the active document
                // The clearance value is set at 5mm currently

                currentSelection.Add(firstProd);
                Clash clash = clashes.AddFromSel();
                clash.ComputationType = CatClashComputationType.catClashComputationTypeAgainstAll;
                clash.InterferenceType = CatClashInterferenceType.catClashInterferenceTypeClearance;
                if (Math.Abs(tolerance) < EPSILON)
                {
                    clash.Clearance = 0.0;
                }
                else
                {
                    clash.Clearance = Math.Abs(tolerance) + EPSILON;
                }
                clash.Compute();
                currentSelection.Clear();
                Log.Information($"Used Tolerance value for clash/clearance computation: {clash.Clearance}");

                foreach (Conflict conflict in clash.Conflicts)
                {
                    ComputeClashValidateSingleResult(property, ref cubeProd, ref primStructProd, clashResult, conflict, ipPartNumber);
                }
            }

            // If from the first input parameter firstProd we don't find any clashes with cube and from the
            // second input parameter cubeProd we have a value, we will execise this test
            if (!clashResult.isClashWithCube && null != cubeProd)
            {
                // Compute cube clashes against all other products in the active document
                currentSelection.Clear();
                currentSelection.Add(cubeProd);
                Clash clash = clashes.AddFromSel();
                clash.Compute();
                currentSelection.Clear();

                if (clash.Conflicts.Count == 0)
                {
                    clashResult.isCubeClashWithSomething = false; //cube have no contact no clash
                }
                else
                {
                    clashResult.isCubeClashWithSomething = true;
                }
            }

            if (clashResult.isClashWithCube && !clashResult.isClashWithOthers && !clashResult.isContactWithPrimaryStruct
                && !clashResult.isClashWithStayOutZone)
            {
                clashResult.isClashOnlyWithCubePrimaryStruct = true;
            }

            return clashResult;
        }

        private static void ComputeClashValidateSingleResult(IpvCheckProperty property, ref Product cubeProd, ref Product primStructProd,
            IpvClashResult clashResult, Conflict conflict, string ipPartNumber = null)
        {
            // Filling secondary object type flag
            bool isSecondPrimStruct = false;
            bool isSecondCube = false;
            bool isSecondStayOutZone = false;
            ValidateClashResultSecondProduct(property, conflict.SecondProduct, primStructProd, ref isSecondPrimStruct, ref isSecondCube, isSecondStayOutZone);
            Log.Information($"Clash Check - Conflict Type: {conflict.Type}, Conflict Value: {conflict.Value}");

            // Dealing with Primary Structure
            if (isSecondPrimStruct)
            {
                if (primStructProd is null)
                {
                    primStructProd = conflict.SecondProduct;
                    Log.Information($"Clash Check: Contact/Clashed/Clearance primary structure found with inst name - {primStructProd.get_Name()}");
                }
                else if (property.PrimStructPartNumber.Length == 0 && conflict.SecondProduct.get_Name() != primStructProd.get_Name())
                {
                    clashResult.isMultiPrimaryStructFound = true;
                    Log.Warning($"Clash Check: More than one clashed primary structure found - {conflict.SecondProduct.get_Name()}");
                }
                else if (property.PrimStructPartNumber.Length > 0 && conflict.SecondProduct.get_PartNumber().ToLower() == property.PrimStructPartNumber.ToLower())
                {
                    primStructProd = conflict.SecondProduct;
                    Log.Information($"Clash Check: Contact/Clashed/Clearance primary structure found with inst name - {primStructProd.get_Name()}");
                }

                //Contact with structure = yes (bracket contact with structure)
                clashResult.isContactWithPrimaryStruct = conflict.Type == CatConflictType.catConflictTypeContact;
                //Clash with structure = yes (input part clashes with structure)
                if (conflict.SecondProduct.get_Name() == primStructProd.get_Name())
                {
                    clashResult.isClashWithPrimaryStruct = conflict.Type == CatConflictType.catConflictTypeClash;
                }
                clashResult.isWithinClearanceToPrimaryStruct = conflict.Type == CatConflictType.catConflictTypeClearance;
            }
            // Dealing with cubes
            else if (isSecondCube)
            {
                ComputeClashSecondaryCube(ref cubeProd, clashResult, conflict, ipPartNumber);
            }
            else if (isSecondStayOutZone && conflict.Type == CatConflictType.catConflictTypeClash)
            {
                clashResult.isClashWithStayOutZone = true;
                clashResult.isClashWithOthers = true;
                if (conflict.FirstProduct.get_Name().ToLower().Contains("cub"))
                {
                    clashResult.isClashWithCube = true;
                    clashResult.isCubeClashWithSomething = true;
                }
            }
            else if (conflict.Type == CatConflictType.catConflictTypeClash)
            {
                clashResult.isClashWithOthers = true;
                Log.Information($"Clash Check: Clash with others found with inst name - {conflict.SecondProduct.get_Name()}");
            }
        }
        private static void ComputeClashSecondaryCube(ref Product cubeProd, IpvClashResult clashResult, Conflict conflict, string ipPartNumber = null)
        {
            if (cubeProd is null)
            {
                if (isCubeValid(conflict.SecondProduct, ipPartNumber))
                {
                    cubeProd = conflict.SecondProduct;
                    if (conflict.Type == CatConflictType.catConflictTypeClash)
                    {
                        Log.Information($"Clash Check: Clashed cube found with inst name - {cubeProd.get_Name()}");
                    }
                    if (conflict.Type == CatConflictType.catConflictTypeContact)
                    {
                        Log.Information($"Clash Check: Contacted cube found with inst name - {cubeProd.get_Name()}");
                    }
                    else if (conflict.Type == CatConflictType.catConflictTypeClearance)
                    {
                        Log.Information($"Clash Check: Clearanced cube found with inst name - {cubeProd.get_Name()}");
                    }
                }
            }
            else
            {
                Log.Warning($"Clash Check: More than one clashed/contacted/clearanced cube found - {conflict.SecondProduct.get_Name()}");
            }

            if (conflict.Type == CatConflictType.catConflictTypeClash)
            {
                clashResult.isClashWithCube = true;
                clashResult.isCubeClashWithSomething = true;
            }
        }
        private static bool isCubeValid(Product cubeProd, string ipNumberForTrend = null)
        {
            if (cubeProd is null)
            {
                return false;
            }

            ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            if (rootDoc is null)
            {
                return false;
            }

            Product parentIpProd = (Product)cubeProd.Parent;

            // For Trend, we have a flat product structure, parent of the cube is the root product
            if (parentIpProd.get_PartNumber() == rootDoc.Product.get_PartNumber())
            {
                return true;
            }

            if (ipNumberForTrend != null)
            {
                if (parentIpProd.get_PartNumber().ToLower().Contains(ipNumberForTrend.ToLower()))
                {
                    return true;
                }
            }

            string nomenclature = parentIpProd.get_Nomenclature();
            if (!nomenclature.ToLower().Contains("ip"))
            {
                return false;
            }

            double[] absTrafo = new double[12];
            string pathIp = "";
            CatiaProdUtils.GetAbsTrafo(parentIpProd, rootDoc.Product, ref absTrafo, ref pathIp);
            string[] pathToken = pathIp.Split('/');
            pathIp = "";
            Array.ForEach(pathToken, t => pathIp += $"/{t}");

            List<Product> validIpList = null;
            List<Product> ipList = new List<Product>();
            List<string> ipPathList = new List<string>();

            ipList.Add(parentIpProd);
            ipPathList.Add(pathIp);

            validIpList = FilterValideIps(ipList, ipPathList);
            if (validIpList.Count != 1)
            {
                Log.Error($"Found cube is not valid with path {pathIp}");
                return false;
            }

            return true;
        }

        private static void ValidateClashResultSecondProduct(IpvCheckProperty property, Product secondProduct, Product primProduct,
            ref bool isSecondPrimStruct, ref bool isSecondCube, bool isSecondStayOutZone)
        {
            secondProduct.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
            string definition = secondProduct.get_Definition();
            string partNum = secondProduct.get_PartNumber();

            // Check Secondary Primary Structure
            string inputPrimStructPartNum = property.PrimStructPartNumber;
            if (inputPrimStructPartNum.Length > 0 && inputPrimStructPartNum.ToLower() == partNum.ToLower())
            {
                isSecondPrimStruct = true;
            }
            else
            {
                string primStructDefinition = "";
                if (primProduct != null)
                {
                    primStructDefinition = primProduct.get_Definition();
                }
                string[] structureNode = GetPrimStructList(property, primStructDefinition).ToArray();
                isSecondPrimStruct = structureNode.Any(definition.ToUpper().Contains);
                //if (isSecondPrimStruct)  // if we have multiple structure then it considers only last result in loop
                //{
                //    property.PrimStructPartNumber = partNum;
                //}
            }

            // Check others
            isSecondCube = partNum.ToLower().Contains("cub");
            isSecondStayOutZone = partNum.ToLower().Contains("stayoutzone");
            Log.Information($"Clash Check - Second Product is: PrimStruct({isSecondPrimStruct}), Cube({isSecondCube}), StayOutZone({isSecondStayOutZone})");

        }

        //CHECK IF CUBE IN CENTER OF HOLE ACKET
        public static bool? IsCubeCenterOfHoleBracket(IpvCheckProperty property, Product cubeProd, Product ipProd, String proposal)
        {
            ProductDocument prodDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            if (prodDoc is null)
            {
                return null;
            }

            // get ADF-Part list from Data base, later used to find actual proposal 
            string dbSecType = !proposal.Contains("(NonStd") ? Standard : Bracket;
            List<string> proposalPartListFromDB = GetProposalPartNumTrend(property.SecondaryNameList, dbSecType);

            ICollection<Product> bracketProdList = new List<Product>();
            GetSecondaryFromIp(property, ipProd, ref bracketProdList, !proposal.Contains("(NonStd") ? Std : Bracket, proposalPartListFromDB);
            Product bracketProd = bracketProdList.First();
            Part bracketPart = GetPart(bracketProd);

            if (bracketPart is null)
            {
                return null;
            }

            double myx = 5000;
            double myy = 5000;
            double myz = 5000;

            //GET POSITION BRACKET
            object[] coordsBracket = new object[12];
            bracketProd.Position.GetComponents(coordsBracket);
            double xBracket = (Double)coordsBracket[9];
            double yBracket = (Double)coordsBracket[10];
            double zBracket = (Double)coordsBracket[11];

            //GET COG OF CYLINDER PAD
            object[] pointInformations = new object[3];
            SPAWorkbench SPAWkBnch = (SPAWorkbench)prodDoc.GetWorkbench("SPAWorkbench");

            Pad myPad = (Pad)bracketPart.MainBody.Shapes.Item(2);
            Measurable measurablePoint = SPAWkBnch.GetMeasurable((Reference)myPad);
            measurablePoint.GetCOG(pointInformations);
            double xPadBracket = (double)pointInformations[0];
            double yPadBracket = (double)pointInformations[1];
            double zPadBracket = (double)pointInformations[2];

            //get COG of Cube
            double[] cubeCog = CatiaProdUtils.GetProductCogPosition(cubeProd);
            //CHECK Y & Z :
            myy = Math.Round(Math.Abs(yBracket - cubeCog[1]) - Math.Abs(yPadBracket), 3);
            myz = Math.Round(Math.Abs(zBracket - cubeCog[2]) - Math.Abs(zPadBracket), 3);

            //CHECK X :      
            Product myNewPart = prodDoc.Product.Products.AddNewComponent("Part", "");
            PartDocument myNewPPart = (PartDocument)myNewPart.ReferenceProduct.Parent;
            Part myPart = myNewPPart.Part;
            HybridBody myHbNewPart = myPart.HybridBodies.Add();
            HybridShapeFactory myHSFNewPart = (HybridShapeFactory)myPart.HybridShapeFactory;
            HybridShapePointCoord myPointNewPart = myHSFNewPart.AddNewPointCoord(cubeCog[0], cubeCog[1], cubeCog[2]);
            myHbNewPart.AppendHybridShape(myPointNewPart);
            HybridShapePlaneOffsetPt myPlaneNewPart = myHSFNewPart.AddNewPlaneOffsetPt((Reference)myPart.OriginElements.PlaneYZ, (Reference)myPointNewPart);
            myHbNewPart.AppendHybridShape(myPlaneNewPart);
            HybridShapeCircleCtrRad myCircle = myHSFNewPart.AddNewCircleCtrRad((Reference)myPointNewPart, (Reference)myPlaneNewPart, false, 11.55 / 2);
            myCircle.SetLimitation(1);
            HybridShapeFill myFill = myHSFNewPart.AddNewFill();
            myFill.AddBound((Reference)myCircle);
            myHbNewPart.AppendHybridShape(myFill);
            myPart.InWorkObject = myPart.MainBody;
            ShapeFactory mySH = (ShapeFactory)myPart.ShapeFactory;
            ThickSurface myFillSurface = mySH.AddNewThickSurface((Reference)myFill, 0, -1, 0);
            myPart.Update();
            Clashes myClashes = (SPATypeLib.Clashes)prodDoc.Product.GetTechnologicalObject("Clashes");
            prodDoc.Selection.Clear();
            prodDoc.Selection.Add(myNewPart);
            Clash myClash = myClashes.AddFromSel();
            myClash.ComputationType = CatClashComputationType.catClashComputationTypeAgainstAll;
            myClash.InterferenceType = CatClashInterferenceType.catClashInterferenceTypeContact;
            myClash.Compute();
            foreach (Conflict myConflict in myClash.Conflicts)
            {
                if (myConflict.Type == CatConflictType.catConflictTypeContact
                    && myConflict.SecondProduct.get_PartNumber() == bracketProd.get_PartNumber())
                {
                    myx = 0;
                }
            }
            prodDoc.Selection.Delete();
            prodDoc.Selection.Clear();

            if (myx == 0 && myy == 0 && myz == 0)
            {
                return true;
            }

            return false;
        }

        private static int GetCubeSecondaryListTrend(IpvCheckProperty property, List<(double, double, double)> ipCoordinatesList,
            ref PartDocument tempPartDoc, ref ICollection<Product> cubeCheckList,
            ref ICollection<Product> secondaryPartCheckList, List<string> proposalPartListFromDB = null)
        {
            int result = 0;

            cubeCheckList = new List<Product>();
            secondaryPartCheckList = new List<Product>();

            Selection selection = CatiaCommonUtils.GetSelection();

            // Add temp product under root product to add sphere
            ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            //PartDocument tempPartDoc = null;
            tempPartDoc = null;
            //HybridBodies tempGeoSet = null;

            // 1. loop all list of IP coordinates fetched from DB
            //for (int i = 0; i < ipCoordinatesList.GetLength(0); i++)
            foreach (var ipCoord in ipCoordinatesList)
            {
                // Get the number of columns in the array
                //int columns = ipCoordinatesList.GetLength(1);

                // get X,Y,Z coordinated from the array for individual cubes
                //double[] singleIpCoordinates = new double[3];
                //for (int column = 0; column < columns; column++)
                //{
                //    singleIpCoordinates[column] = ipCoordinatesList[i, column];
                //}

                double[] singleIpCoordinates = { ipCoord.Item1, ipCoord.Item2, ipCoord.Item3 };

                // 2. create Sphere on the IP cube point cords and compute Clash to get the IP cube and proposal
                //Product tempProductForTrend = CreateSphereToComputeIpCube(rootDoc, singleIpCoordinates, out tempPartDoc);

                // 2. create Cube on the IP cube cog point cords received from DB
                // compute Clash to get the IP cube and proposal
                Product tempProductForTrend = null;
                Product cubeProd = null;
                Product proposal = null;
                IpvClashResult clashResult = new IpvClashResult();

                try
                {
                    // 2.1. create the cube from coooridation and check whether clashes with others
                    tempProductForTrend = CreateCubeOnCogToComputeIpCube(rootDoc, singleIpCoordinates, out tempPartDoc);
                    clashResult = ComputeClashToGetAdfAndIpCubeListForTrend(property, tempPartDoc.Product,
                        proposalPartListFromDB, ref cubeProd, ref proposal);
                }
                catch (Exception e)
                {
                    result = 4009;
                    Log.Warning($"Failed during clash computation for trend cube detection. {e.ToString()}");
                }

                // delete the temp product
                if (null != tempProductForTrend)
                {
                    selection.Clear();
                    selection.Add(tempProductForTrend);
                    selection.Delete();
                    selection.Clear();
                    rootDoc.Product.Update();
                }

                if (result > 0)
                {
                    return result;
                }

                try
                {
                    result = CubeProposalTrendClashCheck(property, cubeCheckList, ref secondaryPartCheckList,
                        proposalPartListFromDB, ref cubeProd, ref proposal, ref clashResult);
                }
                catch (Exception e)
                {
                    result = 4009;
                    Log.Warning($"Failed during clash computation for trend proposal detection. {e.ToString()}");
                }

                if (result > 0)
                {
                    return result;
                }
            }

            return result;
        }

        private static int CubeProposalTrendClashCheck(IpvCheckProperty property, ICollection<Product> cubeCheckList,
            ref ICollection<Product> secondaryPartCheckList, List<string> proposalPartListFromDB, ref Product cubeProd,
            ref Product proposal, ref IpvClashResult clashResult)
        {
            if (cubeProd is null || !clashResult.isClashWithCube)
            {
                Log.Error($"Sphere and Cube clash check: check failed - no cube found at IP cube coordinates");
                return 1;
            }
            else if (cubeProd != null && clashResult.isClashWithCube)
            {
                cubeCheckList.Add(cubeProd);
            }

            //get proposal by clashing cube if not clashing with sphere
            if (proposal is null && cubeProd != null)
            {
                clashResult = ComputeClashToGetAdfAndIpCubeListForTrend(property, cubeProd,
                    proposalPartListFromDB, ref cubeProd, ref proposal);
            }

            //2.2.check if Cube clashes with Proposal
            if (!clashResult.isClashWithSecondaryProposal && proposalPartListFromDB != null)
            {
                // 2.2.1 check for proposal from cube parents parent node if the proposal is not found in clash result
                Product ipProductNode = (Product)cubeProd.Parent;
                GetSecondaryFromIpForTrend(ipProductNode, ref secondaryPartCheckList, proposalPartListFromDB);

                if (!secondaryPartCheckList.Any())
                {
                    Log.Error($"Trend proposal not found - either not clashing with cube({cubeProd.get_Name()}) or no BFH node found");
                    return 2;
                }
            }
            else if (proposal != null && clashResult.isClashWithSecondaryProposal)
            {
                if (!secondaryPartCheckList.Contains(proposal))
                    secondaryPartCheckList.Add(proposal);
            }

            return 0;
        }

        private static Product CreateSphereToComputeIpCube(ProductDocument rootDoc, double[] singleIpCoordinates, out PartDocument tempPartDoc)
        {

            // Add temp product under root product for calculation and copy cube and crossbean into it
            Product tempProduct = rootDoc.Product.Products.AddNewComponent("Product", "");
            Product tempPart = tempProduct.Products.AddNewComponent("Part", "");
            tempPartDoc = (PartDocument)tempPart.ReferenceProduct.Parent;
            HybridBodies hybridBodies = tempPartDoc.Part.HybridBodies;

            // CREATE THE NECESSARY GEOMETRICAL SETS
            HybridBody dummyGeometricalSet = hybridBodies.Add();
            dummyGeometricalSet.set_Name("DUMMY WORKING ELEMENTS");

            // Create a new point
            HybridShapeFactory hybridShapeFactory = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;
            Point point = hybridShapeFactory.AddNewPointCoord(singleIpCoordinates[0], singleIpCoordinates[1], singleIpCoordinates[2]);

            dummyGeometricalSet.AppendHybridShape(point);

            //tempPartDoc.Part.InWorkObject = point;

            // Update the part
            tempPartDoc.Part.Update();

            // Create a sphere centered on the reference point
            HybridShapeSphere cogSphere = hybridShapeFactory.AddNewSphere((Reference)point, null, 3.54, -90, 90, 0, 360);
            // value 1 for whole sphere
            cogSphere.Limitation = 1;

            dummyGeometricalSet.AppendHybridShape(cogSphere);
            //tempPartDoc.Part.InWorkObject = cogSphere;

            // Update the part
            tempPartDoc.Part.Update();

            tempProduct.Update();

            return tempProduct;
        }

        private static Product CreateCubeOnCogToComputeIpCube(ProductDocument rootDoc, double[] singleIpCoordinates, out PartDocument tempPartDoc)
        {
            // Add temp product under root product for calculation and copy cube and crossbean into it
            Product tempProduct = rootDoc.Product.Products.AddNewComponent("Product", "");
            Product tempPart = tempProduct.Products.AddNewComponent("Part", "");
            tempPartDoc = (PartDocument)tempPart.ReferenceProduct.Parent;
            HybridBodies hybridBodies = tempPartDoc.Part.HybridBodies;
            Bodies bodies = tempPartDoc.Part.Bodies;
            Selection selection = rootDoc.Selection;
            ShapeFactory shapeFactory = (ShapeFactory)tempPartDoc.Part.ShapeFactory;
            HybridShapeFactory hybridShapeFactory = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;

            // CREATE THE NECESSARY GEOMETRICAL SETS
            HybridBody dummyGeometricalSet = hybridBodies.Add();
            dummyGeometricalSet.set_Name("DUMMY WORKING ELEMENTS");

            // Add a new body
            Body bodyDummyCube = bodies.Add();
            bodyDummyCube.set_Name("DummyCubeBody");

            double cubeLen = 2.5;
            HybridShapePointCoord hShapePointIpCubeCog = hybridShapeFactory.AddNewPointCoord(singleIpCoordinates[0], singleIpCoordinates[1], singleIpCoordinates[2]);
            hShapePointIpCubeCog.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapePointIpCubeCog);

            // Create points at IP CUBE corners
            double[] p1CoordIp = { singleIpCoordinates[0] - cubeLen, singleIpCoordinates[1] - cubeLen, singleIpCoordinates[2] - cubeLen };
            double[] p2CoordIp = { singleIpCoordinates[0] + cubeLen, singleIpCoordinates[1] - cubeLen, singleIpCoordinates[2] - cubeLen };
            double[] p3CoordIp = { singleIpCoordinates[0] + cubeLen, singleIpCoordinates[1] + cubeLen, singleIpCoordinates[2] - cubeLen };
            double[] p4CoordIp = { singleIpCoordinates[0] - cubeLen, singleIpCoordinates[1] + cubeLen, singleIpCoordinates[2] - cubeLen };

            double[] p5CoordIp = { singleIpCoordinates[0] - cubeLen, singleIpCoordinates[1] - cubeLen, singleIpCoordinates[2] + cubeLen };
            double[] p6CoordIp = { singleIpCoordinates[0] + cubeLen, singleIpCoordinates[1] - cubeLen, singleIpCoordinates[2] + cubeLen };
            double[] p7CoordIp = { singleIpCoordinates[0] + cubeLen, singleIpCoordinates[1] + cubeLen, singleIpCoordinates[2] + cubeLen };
            double[] p8CoordIp = { singleIpCoordinates[0] - cubeLen, singleIpCoordinates[1] + cubeLen, singleIpCoordinates[2] + cubeLen };

            double[][] listPointCoordinatesIp = { p1CoordIp, p2CoordIp, p3CoordIp, p4CoordIp, p5CoordIp, p6CoordIp, p7CoordIp, p8CoordIp };

            // For each point in list, create CATIA point
            List<Reference> listReferencePointsIp = new List<Reference>();
            foreach (double[] pointCoordIp in listPointCoordinatesIp)
            {
                HybridShapePointCoord hShapePointIp = hybridShapeFactory.AddNewPointCoord(pointCoordIp[0], pointCoordIp[1], pointCoordIp[2]);
                hShapePointIp.Compute();
                dummyGeometricalSet.AppendHybridShape(hShapePointIp);
                Reference refHShapePointIp = tempPartDoc.Part.CreateReferenceFromObject(hShapePointIp);
                listReferencePointsIp.Add(refHShapePointIp);
            }

            // Create bottom square wire
            HybridShapePolyline hShapePolyLineBottomSquare = hybridShapeFactory.AddNewPolyline();
            hShapePolyLineBottomSquare.InsertElement(listReferencePointsIp[0], 1);
            hShapePolyLineBottomSquare.InsertElement(listReferencePointsIp[1], 2);
            hShapePolyLineBottomSquare.InsertElement(listReferencePointsIp[2], 3);
            hShapePolyLineBottomSquare.InsertElement(listReferencePointsIp[3], 4);
            hShapePolyLineBottomSquare.InsertElement(listReferencePointsIp[0], 5);
            hShapePolyLineBottomSquare.Closure = false;
            hShapePolyLineBottomSquare.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapePolyLineBottomSquare);

            // Create top square wire
            HybridShapePolyline hShapePolyLineTopSquare = hybridShapeFactory.AddNewPolyline();
            hShapePolyLineTopSquare.InsertElement(listReferencePointsIp[4], 1);
            hShapePolyLineTopSquare.InsertElement(listReferencePointsIp[5], 2);
            hShapePolyLineTopSquare.InsertElement(listReferencePointsIp[6], 3);
            hShapePolyLineTopSquare.InsertElement(listReferencePointsIp[7], 4);
            hShapePolyLineTopSquare.InsertElement(listReferencePointsIp[4], 5);
            hShapePolyLineTopSquare.Closure = false;
            hShapePolyLineTopSquare.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapePolyLineTopSquare);

            // Fill bottom square wire
            HybridShapeFill hShapeBottomFill = hybridShapeFactory.AddNewFill();
            Reference refHShapePolyLineBottomSquare = tempPartDoc.Part.CreateReferenceFromObject(hShapePolyLineBottomSquare);
            hShapeBottomFill.AddBound(refHShapePolyLineBottomSquare);
            hShapeBottomFill.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapeBottomFill);

            // Fill top square wire
            HybridShapeFill hShapeTopFill = hybridShapeFactory.AddNewFill();
            Reference refHShapePolyLineTopSquare = tempPartDoc.Part.CreateReferenceFromObject(hShapePolyLineTopSquare);
            hShapeTopFill.AddBound(refHShapePolyLineTopSquare);
            hShapeTopFill.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapeTopFill);

            // Blend wall
            HybridShapeBlend hShapeBlendWall = hybridShapeFactory.AddNewBlend();
            hShapeBlendWall.Coupling = 1;
            hShapeBlendWall.SetCurve(1, refHShapePolyLineBottomSquare);
            hShapeBlendWall.SetOrientation(1, 1);
            hShapeBlendWall.SetCurve(2, refHShapePolyLineTopSquare);
            hShapeBlendWall.SetOrientation(2, 1);
            hShapeBlendWall.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapeBlendWall);

            // Join bottom, top, and wall surfaces
            Reference refHShapeBottomFill = tempPartDoc.Part.CreateReferenceFromObject(hShapeBottomFill);
            Reference refHShapeTopFill = tempPartDoc.Part.CreateReferenceFromObject(hShapeTopFill);
            Reference refHShapeBlendWall = tempPartDoc.Part.CreateReferenceFromObject(hShapeBlendWall);
            HybridShapeAssemble hShapeJoin = hybridShapeFactory.AddNewJoin(refHShapeBottomFill, refHShapeBlendWall);
            hShapeJoin.AddElement(refHShapeTopFill);
            hShapeJoin.Compute();
            dummyGeometricalSet.AppendHybridShape(hShapeJoin);

            // Create a closed surface
            tempPartDoc.Part.InWorkObject = bodyDummyCube;
            Reference refHShapeJoin = tempPartDoc.Part.CreateReferenceFromObject(hShapeJoin);
            Shape shapeClosedSurface = shapeFactory.AddNewCloseSurface(refHShapeJoin);
            tempPartDoc.Part.Update();

            // Hide geometrical elements
            selection.Clear();
            selection.Add(dummyGeometricalSet);
            selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            selection.Clear();

            // Change vis properties of IP CUBE body
            selection.Clear();
            selection.Add(bodyDummyCube);
            selection.VisProperties.SetRealColor(255, 255, 0, 0);
            selection.Clear();

            // Update the part
            tempPartDoc.Part.Update();

            tempProduct.Update();

            return tempProduct;

        }

        private static List<string> GetProposalPartNumTrend(IDictionary<string, string> secondaryInstanceName,
            string targetType)
        {
            List<string> adfPartListFromDB = new List<string>();

            if (secondaryInstanceName is null)
            {
                return adfPartListFromDB;
            }

            if (targetType == AdfPart)
            {
                targetType = "ADF-Part/ADAP-Part";
            }

            foreach (var instNameType in secondaryInstanceName)
            {
                string type = instNameType.Value;
                string name = instNameType.Key;

                if (String.IsNullOrWhiteSpace(name) || String.IsNullOrWhiteSpace(type))
                {
                    continue;
                }

                if (targetType.ToLower().Contains(type.ToLower()))
                {
                    string[] inputString = name.Split('.');
                    // add found secondary proposal to list
                    adfPartListFromDB.Add(inputString.Length > 0 ? inputString[0] : name);
                }
            }

            //// Get the number of rows in the array
            //int rows = secondaryInstanceName.GetLength(0);
            //for (int row = 0; row < rows; row++)
            //{
            //    // Access the second column data
            //    string currentInstanceFunctionalType = secondaryInstanceName[row, 1];

            //    // Check the value in the second column
            //    if (currentInstanceFunctionalType.ToLower() == secondaryInstanceFunctionalType.ToLower())
            //    {
            //        string[] inputString = secondaryInstanceName[row, 0].Split('.');
            //        if (inputString.Length > 0)
            //            // add ADF-PART to list
            //            adfPartListFromDB.Add(inputString[0]);
            //        else
            //            // add ADF-PART to list
            //            adfPartListFromDB.Add(secondaryInstanceName[row, 0]);

            //    }

            //}

            return adfPartListFromDB;
        }

        public static IpvClashResult ComputeClashToGetAdfAndIpCubeListForTrend(IpvCheckProperty property, Product firstProd,
            List<string> proposalPartListFromDB, ref Product cubeProd, ref Product proposal, double tolerance = 0.0)
        {
            IpvClashResult clashResult = new IpvClashResult();
            ProductDocument activeDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            if (activeDoc is null)
            {
                return null;
            }

            Selection currentSelection = activeDoc.Selection;
            currentSelection.Clear();
            // Get the Clash factory object (Clashes) with GetTechnologicalObject()
            Product activeProd = (Product)activeDoc.Product;
            Clashes clashes = (Clashes)activeProd.GetTechnologicalObject("Clashes");

            if (null != firstProd)
            {
                // Initialize Clash by adding only product to the Clash object
                // The clash will calcuate peneration, contact and clearance
                // The clash calculation is between the product and all other products in the active document
                // The clearance value is set at 5mm currently

                currentSelection.Add(firstProd);
                Clash clash = clashes.AddFromSel();
                clash.ComputationType = CatClashComputationType.catClashComputationTypeAgainstAll;
                clash.InterferenceType = CatClashInterferenceType.catClashInterferenceTypeClearance;

                if (Math.Abs(tolerance) < EPSILON)
                {
                    clash.Clearance = 0.0;
                }
                else
                {
                    clash.Clearance = Math.Abs(tolerance) + EPSILON;
                }

                clash.Compute();
                currentSelection.Clear();
                Log.Information($"Used Tolerance value for clash/clearance computation: {clash.Clearance}");

                foreach (Conflict conflict in clash.Conflicts)
                {
                    bool isSecondPrimStruct = false;
                    bool isSecondCube = false;
                    bool isSecondProposal = false;
                    bool isSecondStayOutZone = false;

                    ValidateClashResultSecondProduct(property, conflict.SecondProduct, ref isSecondPrimStruct,
                        ref isSecondCube, ref isSecondProposal, isSecondStayOutZone, proposalPartListFromDB);
                    Log.Information($"Clash Check - Conflict Type: {conflict.Type}, Conflict Value: {conflict.Value}");

                    CheckSigleCubeResultTrend(ref cubeProd, ref proposal, clashResult, conflict, isSecondCube, isSecondProposal);
                }
            }
            return clashResult;
        }

        private static void CheckSigleCubeResultTrend(ref Product cubeProd, ref Product proposal,
            IpvClashResult clashResult, Conflict conflict, bool isSecondCube, bool isSecondProposal)
        {
            if (isSecondCube)
            {
                if (conflict.Type == CatConflictType.catConflictTypeClash || conflict.Type == CatConflictType.catConflictTypeContact)
                {
                    clashResult.isClashWithCube = true;
                    clashResult.isCubeClashWithSomething = true;
                }

                if (cubeProd is null)
                {
                    cubeProd = conflict.SecondProduct;
                    Log.Information($"Clash Check: Clashed cube found with inst name - {cubeProd.get_Name()}");
                }
                else
                {
                    Log.Warning($"Clash Check: More than one clashed cube found - {conflict.SecondProduct.get_Name()}");
                }

            }
            else if (isSecondProposal)
            {
                if (conflict.Type == CatConflictType.catConflictTypeClash || conflict.Type == CatConflictType.catConflictTypeContact)  // this validation required for hole and STD Bracket
                {
                    clashResult.isClashWithSecondaryProposal = true;

                    if (proposal is null)
                    {
                        proposal = conflict.SecondProduct;
                        Log.Information($"Clash Check: Clashed Proposal found with inst name - {proposal.get_Name()}");
                    }
                    else
                    {
                        Log.Warning($"Clash Check: More than one clashed Proposal found - {conflict.SecondProduct.get_Name()}");
                    }
                }
            }
        }

        private static void ValidateClashResultSecondProduct(IpvCheckProperty property, Product secondProduct, ref bool isSecondPrimStruct,
            ref bool isSecondCube, ref bool isSecondProposal, bool isSecondStayOutZone, List<string> proposalPartListFromDB = null)
        {
            secondProduct.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
            string definition = secondProduct.get_Definition();
            string partNum = secondProduct.get_PartNumber();
            //string productNomenclature = secondProduct.get_Nomenclature();

            string[] structureNode = GetPrimStructList(property).ToArray();
            isSecondPrimStruct = structureNode.Any(definition.ToLower().Contains);
            isSecondCube = partNum.ToLower().Contains("cub");
            if (proposalPartListFromDB != null)
                isSecondProposal = proposalPartListFromDB.Contains(partNum);
            //isSecondProposal = productNomenclature.ToLower().Contains("adf-part");
            isSecondStayOutZone = partNum.ToLower().Contains("stayoutzone");
            Log.Information($"Clash Check - Second Product is: PrimStruct({isSecondPrimStruct}), Cube({isSecondCube}), Proposal({isSecondProposal})");
        }

        /// <summary>
        /// Get the permitted user names from the USerAccess.txt file from bin Folder of the project
        /// </summary>
        /// <returns>List of user names</returns>
        private static List<string> GetPrimStructList(IpvCheckProperty property, string primStructDefinition = "")
        {
            // Use ToolDB info if it exits
            if (property != null && property.PrimStructList != null)
            {
                if (property.PrimStructList.Count > 0)
                {
                    return property.PrimStructList;
                }
            }

            List<string> fixList = new List<string>() { "CROSSBEAM", "Z-STRUT", "SHEAR WEB", "ROLLER TRACK", "CARGO RAIL" };
            if (!string.IsNullOrWhiteSpace(primStructDefinition))
            {
                fixList.Add(primStructDefinition);
            }

            List<string> primStructList = new List<string>();
            Assembly assembly = Assembly.GetExecutingAssembly();
            string path = System.IO.Path.GetDirectoryName(assembly.Location);
            path += @"\Resources\primstructlist.txt";

            try
            {
                string[] lines = System.IO.File.ReadAllLines(path);
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] primStrut = lines[i].Split(';');
                    primStructList.Add(primStrut[0].ToUpper());
                }
            }
            catch
            {
                Log.Information($"File not found {path} or we have problem by parse");
            }
            finally
            {
                if (primStructList.Count == 0)
                {
                    primStructList = fixList;
                }
            }

            if (primStructList.Count == 0)
            {
                primStructList = fixList;
            }

            return primStructList;
        }

        private static Product PrepareTempPartsForBoundingBox(Selection selection, ProductDocument rootDoc, Product nonStdBracketProd,
                                out PartDocument tempPartDoc, out HybridBodies tempGeoSet)
        {
            // Add temp product under root product for calculation and copy non-std bracket and axis system into it
            Product tempPart = rootDoc.Product.Products.AddNewComponent("Part", "");
            tempPart.ActivateDefaultShape();
            tempPartDoc = (PartDocument)tempPart.ReferenceProduct.Parent;

            Part partBracketPartDocument = tempPartDoc.Part;
            Product productNonStdBracket = nonStdBracketProd;

            // Put NON STD BRACKET in design mode
            productNonStdBracket.ApplyWorkMode(CatWorkModeType.DESIGN_MODE);

            // Publish NON STD BRACKET body
            Part partNonStdBracket = ((PartDocument)productNonStdBracket.ReferenceProduct.Parent).Part;
            double[] absTrafoNonStdBracketProd = new double[12];
            string pathNonStdBracketProd = "";
            CatiaProdUtils.GetAbsTrafo(productNonStdBracket, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoNonStdBracketProd, ref pathNonStdBracketProd);
            //PublishFirstBody(productNonStdBracket, partNonStdBracket, pathNonStdBracketProd);

            selection.Clear();
            //selection.Add((AnyObject)productNonStdBracket.Publications.Item(publishName).Valuation);
            selection.Add(GetReferenceToRootFirstBody(partNonStdBracket, pathNonStdBracketProd));
            selection.Copy();
            selection.Clear();
            selection.Add(tempPartDoc.Part);
            selection.PasteSpecial("CATPrtResultWithOutLink");
            selection.Clear();

            // Get AXIS SYSTEM of NON STD BRACKET PART
            AxisSystem axisSystemNonStdBracket = GetCurrentAxisSystem(partNonStdBracket);

            // Publish AXIS SYSTEM
            double[] absTrafoNonStdBracketASProd = new double[12];
            string pathNonStdBracketASProd = "";
            CatiaProdUtils.GetAbsTrafo(productNonStdBracket, CatiaCommonUtils.GetActiveRootProd(), ref absTrafoNonStdBracketASProd, ref pathNonStdBracketASProd);
            pathNonStdBracketASProd = pathNonStdBracketASProd + "!" + axisSystemNonStdBracket.get_Name();
            //PublishFirstBody(productNonStdBracket, partNonStdBracket, pathNonStdBracketASProd, "AnyObject");

            // Delete default AXIS SYSTEM in DUMMY PART if available
            if (partBracketPartDocument.AxisSystems.Count == 1)
            {
                selection.Clear();
                selection.Add(partBracketPartDocument.AxisSystems.Item(1));
                selection.Delete();
                selection.Clear();
            }

            // Copy published AXIS SYSTEM into DUMMY PART
            //selection.Add((AnyObject)productNonStdBracket.Publications.Item(publishName).Valuation);

            selection.Add(GetReferenceToRootFirstBody(axisSystemNonStdBracket, pathNonStdBracketASProd, "AnyObject"));

            selection.Copy();
            selection.Clear();
            selection.Add(tempPartDoc.Part);
            selection.PasteSpecial("CATPrtResultWithOutLink");
            selection.Clear();

            tempPartDoc.Part.Update();

            // Get copied NON STD BRACKET MAIN BODY
            Body bodyCopiedNonStdBracket = partBracketPartDocument.Bodies.Item(2);

            // CREATE THE NECESSARY GEOMETRICAL SETS
            HybridBodies hybridBodies = tempPartDoc.Part.HybridBodies;
            HybridBody dummyGeometricalSet = hybridBodies.Add();
            dummyGeometricalSet.set_Name("Bounding Box");
            tempGeoSet = dummyGeometricalSet.HybridBodies;

            tempPartDoc.Part.Update();
            return tempPart;

        }

        private static int NonStdBracketSingleCheck(NotificationStoreBase notifStore, string ipPartNumber, Selection selection,
                                    ProductDocument rootDoc, Product nonStdBracketProd, Product ipProduct)
        {
            int result = 0;

            Log.Information($"Standard/Non-Standard part Bounding Box parameter check: start check for instance ({nonStdBracketProd.get_Name()})");

            // Publish all needed part bodies and copy them to temp part for later use
            PartDocument tempPartDoc = null;
            HybridBodies tempGeoSet = null;

            Product tempProduct = PrepareTempPartsForBoundingBox(selection, rootDoc, nonStdBracketProd, out tempPartDoc, out tempGeoSet);

            Log.Information("Temp Product and Part created for staring the calculation");

            HybridBody hBodyConsElements = tempGeoSet.Add();
            hBodyConsElements.set_Name("Construction_Elements");

            // Get copied NON STD BRACKET MAIN BODY
            Body bodyCopiedNonStdBracket = tempPartDoc.Part.Bodies.Item(2);

            HybridShapeFactory hsfDummyPart = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;

            // Get AXIS SYSTEM of temp PART
            AxisSystem axisSystemDummyPart = tempPartDoc.Part.AxisSystems.Item(1);

            // Rename AXIS SYSTEM as "Global_Axis_System"
            axisSystemDummyPart.set_Name("Global_Axis_System");

            //Create 6 single points using the extremums as refs
            Point[] hShapePoint = CreateExtremumPoint(tempPartDoc, hBodyConsElements, bodyCopiedNonStdBracket, hsfDummyPart, axisSystemDummyPart);
            Log.Information($"Standard/Non-Standard part Bounding Box parameter check: Extremum points created)");

            // create geometric elements for creating bounding box sketch
            Reference refHShapePlaneZmin;
            HybridShapeLinePtPt hShapeLineGuide;
            CreateGeometricalElementsForVolumeMap(tempPartDoc, hBodyConsElements, hsfDummyPart, axisSystemDummyPart, hShapePoint,
                                                    out refHShapePlaneZmin, out hShapeLineGuide);
            Log.Information($"Standard/Non-Standard part Bounding Box parameter check: geometric elements added to create Sketch)");

            // create sketch for bounding box with Sweep
            Body tempPartMainBody;
            CloseSurface shapeCloseSurface;
            CreateBoundingBoxForVolumeMap(tempPartDoc, hBodyConsElements, hsfDummyPart, hShapePoint, refHShapePlaneZmin,
                            hShapeLineGuide, out tempPartMainBody, out shapeCloseSurface);
            Log.Information($"Standard/Non-Standard part Bounding Box parameter check: Bounding Box created for Volume Map)");

            // Hide CONSTRUCTION ELEMENTS geometrical set
            SetHide(tempPartDoc.Selection, hBodyConsElements);

            // Change color of BOUNDING BOX BODY
            SetColor(tempPartDoc.Selection, tempPartMainBody, (0, 0, 0));

            // Change transparency of BOUNDING BOX BODY
            CatiaImageAnnotationUtils.selectToTransperent(tempPartMainBody);
            //set_opacity(selection_dummy_part, h_body_bounding_box, 0); // reused the existing code

            // Create RESULTS geometrical set
            HybridBody hBodyResults = tempGeoSet.Add();
            hBodyResults.set_Name("Results");

            // Process the Bounding Box to get the properties 
            ProcessBoundingBoxCheck(selection, rootDoc, tempPartDoc, hBodyConsElements, bodyCopiedNonStdBracket,
                                hsfDummyPart, shapeCloseSurface, hBodyResults);
            Log.Information($"Standard/Non-Standard part Bounding Box parameter check: Retrieved bounding box parameter)");

            return result;
        }

        private static void CreateBoundingBoxForVolumeMap(PartDocument tempPartDoc, HybridBody hBodyConsElements, HybridShapeFactory hsfDummyPart, Point[] hShapePoint, Reference refHShapePlaneZmin, HybridShapeLinePtPt hShapeLineGuide, out Body tempPartMainBody, out CloseSurface shapeCloseSurface)
        {
            // Create a sketch, with the X and Y boundary
            Sketches sketches = hBodyConsElements.HybridSketches;
            Sketch standardBodySketch = sketches.Add(refHShapePlaneZmin);
            Factory2D factory2d = standardBodySketch.OpenEdition();

            // Create a square in the sketch
            int ponto = 20000;
            Point2D point2d1 = factory2d.CreatePoint(-ponto, -ponto);
            Point2D point2d2 = factory2d.CreatePoint(ponto, -ponto);
            Point2D point2d3 = factory2d.CreatePoint(ponto, ponto);
            Point2D point2d4 = factory2d.CreatePoint(-ponto, ponto);

            Line2D line2d1to2 = factory2d.CreateLine(-ponto, -ponto, ponto, -ponto);
            line2d1to2.StartPoint = point2d1;
            line2d1to2.EndPoint = point2d2;

            Line2D line2d2to3 = factory2d.CreateLine(ponto, -ponto, ponto, ponto);
            line2d2to3.StartPoint = point2d2;
            line2d2to3.EndPoint = point2d3;

            Line2D line2d3to4 = factory2d.CreateLine(-ponto, ponto, ponto, ponto);
            line2d3to4.StartPoint = point2d4;
            line2d3to4.EndPoint = point2d3;

            Line2D line2d4to1 = factory2d.CreateLine(-ponto, -ponto, -ponto, ponto);
            line2d4to1.StartPoint = point2d1;
            line2d4to1.EndPoint = point2d4;

            // Create reference lines and constraints
            Reference refLine1To2Sketch1 = tempPartDoc.Part.CreateReferenceFromObject(line2d1to2);
            Reference refLine2To3Sketch1 = tempPartDoc.Part.CreateReferenceFromObject(line2d2to3);
            Reference refLine3To4Sketch1 = tempPartDoc.Part.CreateReferenceFromObject(line2d3to4);
            Reference refLine4To1Sketch1 = tempPartDoc.Part.CreateReferenceFromObject(line2d4to1);

            Constraints sketchConstraints = standardBodySketch.Constraints;
            Reference refHShapePoint1 = tempPartDoc.Part.CreateReferenceFromObject(hShapePoint[0]);
            Reference refHShapePoint2 = tempPartDoc.Part.CreateReferenceFromObject(hShapePoint[1]);
            Reference refHShapePoint3 = tempPartDoc.Part.CreateReferenceFromObject(hShapePoint[2]);
            Reference refHShapePoint4 = tempPartDoc.Part.CreateReferenceFromObject(hShapePoint[3]);

            Constraint constraint2To3 = sketchConstraints.AddBiEltCst(CatConstraintType.catCstTypeDistance, refHShapePoint1, refLine2To3Sketch1);
            Constraint constraint3To4 = sketchConstraints.AddBiEltCst(CatConstraintType.catCstTypeDistance, refHShapePoint3, refLine3To4Sketch1);
            Constraint constraint4To1 = sketchConstraints.AddBiEltCst(CatConstraintType.catCstTypeDistance, refLine4To1Sketch1, refHShapePoint2);
            Constraint constraint1To2 = sketchConstraints.AddBiEltCst(CatConstraintType.catCstTypeDistance, refLine1To2Sketch1, refHShapePoint4);

            constraint2To3.Dimension.Value = 0;
            constraint3To4.Dimension.Value = 0;
            constraint4To1.Dimension.Value = 0;
            constraint1To2.Dimension.Value = 0;

            Constraint constraintParallel1 = sketchConstraints.AddBiEltCst(CatConstraintType.catCstTypeParallelism, refLine1To2Sketch1, refLine3To4Sketch1);
            Constraint constraintParallel2 = sketchConstraints.AddBiEltCst(CatConstraintType.catCstTypeParallelism, refLine2To3Sketch1, refLine4To1Sketch1);

            standardBodySketch.CloseEdition();
            tempPartDoc.Part.Update();

            // Sweep the Z line around the XY boundary. This will be closed
            Reference refSweepProfile = tempPartDoc.Part.CreateReferenceFromObject(standardBodySketch);
            Reference refSweepGuide = tempPartDoc.Part.CreateReferenceFromObject(hShapeLineGuide);
            HybridShapeSweep hShapeSweep = hsfDummyPart.AddNewSweepExplicit(refSweepProfile, refSweepGuide);
            hShapeSweep.Compute();
            hBodyConsElements.AppendHybridShape(hShapeSweep);

            // Close the sweep
            ShapeFactory sfDummyPart = (ShapeFactory)tempPartDoc.Part.ShapeFactory;
            Reference refHShapeSweep = tempPartDoc.Part.CreateReferenceFromObject(hShapeSweep);
            tempPartMainBody = tempPartDoc.Part.MainBody;
            tempPartDoc.Part.InWorkObject = tempPartMainBody;
            shapeCloseSurface = sfDummyPart.AddNewCloseSurface(refHShapeSweep);
            shapeCloseSurface.set_Name("BoundingBox");

            tempPartDoc.Part.Update();
        }

        private static void CreateGeometricalElementsForVolumeMap(PartDocument tempPartDoc, HybridBody hBodyConsElements,
            HybridShapeFactory hsfDummyPart, AxisSystem axisSystemDummyPart, Point[] hShapePoint, out Reference refHShapePlaneZmin, out HybridShapeLinePtPt hShapeLineGuide)
        {
            // Get the components of the X and Y axis of the axis system
            object[] oXAxis = new object[3];
            object[] oYAxis = new object[3];
            axisSystemDummyPart.GetXAxis(oXAxis);
            axisSystemDummyPart.GetYAxis(oYAxis);

            // Convert object array to double array
            double[] xCoords = oXAxis.OfType<double>().ToArray();
            double[] yCoords = oYAxis.OfType<double>().ToArray();

            // Create the direction vectors for X, Y and Z directions
            var lineHorizontalDirection = BuildDirection(hsfDummyPart, xCoords);
            var lineVerticaldirection = BuildDirection(hsfDummyPart, yCoords);

            // Create the Max Z and Min Z planes
            Reference refLineHDirection = tempPartDoc.Part.CreateReferenceFromObject((Reference)lineHorizontalDirection);
            Reference refLineVDirection = tempPartDoc.Part.CreateReferenceFromObject((Reference)lineVerticaldirection);
            HybridShapePlane2Lines hShapePlaneOrigin = hsfDummyPart.AddNewPlane2Lines(refLineHDirection, refLineVDirection);
            Reference refHShapePlaneOrigin = tempPartDoc.Part.CreateReferenceFromObject(hShapePlaneOrigin);
            Reference refHShapePoint5 = tempPartDoc.Part.CreateReferenceFromObject(hShapePoint[4]);
            Reference refHShapePoint6 = tempPartDoc.Part.CreateReferenceFromObject(hShapePoint[5]);
            HybridShapePlaneOffsetPt hShapePlaneZmin = hsfDummyPart.AddNewPlaneOffsetPt(refHShapePlaneOrigin, refHShapePoint6);
            hBodyConsElements.AppendHybridShape(hShapePlaneZmin);
            refHShapePlaneZmin = tempPartDoc.Part.CreateReferenceFromObject(hShapePlaneZmin);
            HybridShapePlaneOffsetPt hShapePlaneZmax = hsfDummyPart.AddNewPlaneOffsetPt(refHShapePlaneOrigin, refHShapePoint5);
            hBodyConsElements.AppendHybridShape(hShapePlaneZmax);
            Reference refHShapePlaneZmax = tempPartDoc.Part.CreateReferenceFromObject(hShapePlaneZmax);

            // Creates the line that sweeps around the XY Sketch boundary
            HybridShapePointCoord hShapePointOnZmin = hsfDummyPart.AddNewPointCoordWithReference(0, 0, 0, refHShapePoint6);
            hBodyConsElements.AppendHybridShape(hShapePointOnZmin);
            Reference refHShapePointOnZmin = tempPartDoc.Part.CreateReferenceFromObject(hShapePointOnZmin);
            HybridShapeProject hShapeProjectedPointOnZmax = hsfDummyPart.AddNewProject(refHShapePoint6, refHShapePlaneZmax);
            Reference refHShapeProjectedPointOnZmax = tempPartDoc.Part.CreateReferenceFromObject(hShapeProjectedPointOnZmax);
            hBodyConsElements.AppendHybridShape(hShapeProjectedPointOnZmax);
            HybridShapePointCoord hShapePointOnZmax = hsfDummyPart.AddNewPointCoordWithReference(0, 0, 0, refHShapeProjectedPointOnZmax);
            hBodyConsElements.AppendHybridShape(hShapePointOnZmax);
            Reference refHShapePointOnZmax = tempPartDoc.Part.CreateReferenceFromObject(hShapePointOnZmax);

            hShapeLineGuide = hsfDummyPart.AddNewLinePtPt(refHShapePointOnZmax, refHShapePointOnZmin);
            hBodyConsElements.AppendHybridShape(hShapeLineGuide);
            Reference refHShapeLineGuide = tempPartDoc.Part.CreateReferenceFromObject(hShapeLineGuide);
            hShapeLineGuide.BeginOffset.Value = 0;
            hShapeLineGuide.EndOffset.Value = 0;

            Constraints constraintsForZ = tempPartDoc.Part.Constraints;
            constraintsForZ.AddMonoEltCst(CatConstraintType.catCstTypeLength, refHShapeLineGuide);
            tempPartDoc.Part.Update();
        }

        private static void ProcessBoundingBoxCheck(Selection selection, ProductDocument rootDoc, PartDocument tempPartDoc, HybridBody hBodyConsElements, Body bodyCopiedNonStdBracket, HybridShapeFactory hsfDummyPart, CloseSurface shapeCloseSurface, HybridBody hBodyResults)
        {
            // Find all edges of BOUNDING BOX BODY and create hybrid shape extracts
            selection.Clear();
            selection.Add(shapeCloseSurface);
            selection.Search("Topology.Edge,sel");
            List<object> listBoBEdges = new List<object>();

            for (int i = 0; i < selection.Count2; i++)
            {
                object selectedEdge = selection.Item2(i + 1).Value;
                HybridShapeExtract hShapeExtractBoBEdge = hsfDummyPart.AddNewExtract((Reference)selectedEdge);
                hShapeExtractBoBEdge.PropagationType = 3;
                hShapeExtractBoBEdge.ComplementaryExtract = false;
                hShapeExtractBoBEdge.IsFederated = false;
                hShapeExtractBoBEdge.Compute();
                hBodyResults.AppendHybridShape(hShapeExtractBoBEdge);
                listBoBEdges.Add(hShapeExtractBoBEdge);
            }
            selection.Clear();

            // We need a point at any corner of BOUNDING BOX BODY
            // Create a point at first edge's start point
            object hShapeExtractBoBOneEdge = listBoBEdges[0];
            Reference refHShapeExtractBoBOneEdge = tempPartDoc.Part.CreateReferenceFromObject((AnyObject)hShapeExtractBoBOneEdge);
            HybridShapePointOnCurve hShapePointEdgeStart = hsfDummyPart.AddNewPointOnCurveFromPercent(refHShapeExtractBoBOneEdge, 0, false);
            hShapePointEdgeStart.Compute();
            Reference refHShapePointEdgeStart = tempPartDoc.Part.CreateReferenceFromObject(hShapePointEdgeStart);

            var index_color = 0;

            // For each extracted edge of BOUNDING BOX BODY in list
            foreach (var hShapeExtractBoBEdge in listBoBEdges)
            {
                // Measure the minimum distance between extracted edge and point on BOUNDING BOX corner
                Reference refHShapeExtractBoBEdge = tempPartDoc.Part.CreateReferenceFromObject((Reference)hShapeExtractBoBEdge);
                SPAWorkbench spaWorkBench = (SPAWorkbench)tempPartDoc.GetWorkbench("SPAWorkbench");
                Measurable measurableHShapeExtractBoBEdge = spaWorkBench.GetMeasurable(refHShapeExtractBoBEdge);
                double minDistBetweenPointAndBoBEdge = Math.Round(measurableHShapeExtractBoBEdge.GetMinimumDistance(refHShapePointEdgeStart), 3);

                // There will be 3 edges connects with this point
                if (minDistBetweenPointAndBoBEdge == 0)
                {
                    // Measure length of extracted edge
                    double lengthOfEdge = Math.Round(measurableHShapeExtractBoBEdge.Length, 3);

                    // Create center point of edge
                    HybridShapePointOnCurve hShapePointOnBoBEdgeCenter = hsfDummyPart.AddNewPointOnCurveFromPercent(refHShapeExtractBoBEdge, 0.5, false);
                    hShapePointOnBoBEdgeCenter.Compute();
                    hBodyConsElements.AppendHybridShape(hShapePointOnBoBEdgeCenter);

                    // Measure the coordinates of points that will be used to position 3d texts
                    Reference refHShapePointOnBoBEdgeCenter = tempPartDoc.Part.CreateReferenceFromObject(hShapePointOnBoBEdgeCenter);
                    Measurable measurableHShapePointOnBoBEdgeCenter = spaWorkBench.GetMeasurable(refHShapePointOnBoBEdgeCenter);
                    object[] coordsPointOnCenter = new object[3];
                    measurableHShapePointOnBoBEdgeCenter.GetPoint(coordsPointOnCenter);

                    // Define colors
                    (int, int, int) rgb;
                    if (index_color == 0)
                        rgb = (0, 255, 0);       //green
                    else if (index_color == 1)
                        rgb = (255, 255, 0);    // yellow
                    else
                        rgb = (255, 0, 255);    // purple

                    // Create 3d text to represent L-W-H dimensions
                    var marker3D = Build3DText(rootDoc, coordsPointOnCenter, lengthOfEdge.ToString(), coordsPointOnCenter, refHShapePointOnBoBEdgeCenter);

                    // Change color of 3d text
                    SetColor(tempPartDoc.Selection, marker3D, rgb);

                    // Change color of extracted edge
                    SetColor(tempPartDoc.Selection, (AnyObject)hShapeExtractBoBEdge, rgb);

                    // Change line thickness of extracted edge
                    SetLineWidth(tempPartDoc.Selection, (AnyObject)hShapeExtractBoBEdge, 3);
                }
                else
                {
                    // Hide extracted edge
                    SetHide(tempPartDoc.Selection, (AnyObject)hShapeExtractBoBEdge);
                }

                index_color++;
            }

            // Hide NON STD BRACKET BODY in DUMMY PART document
            SetHide(tempPartDoc.Selection, bodyCopiedNonStdBracket);

            // Update DUMMY PART
            tempPartDoc.Part.Update();

            // Clear selections
            selection.Clear();
        }

        private static Point[] CreateExtremumPoint(PartDocument tempPartDoc, HybridBody hBodyConsElements, Body bodyCopiedNonStdBracket, HybridShapeFactory hsfDummyPart,
                                                AxisSystem axisSystemDummyPart)
        {
            Point[] hShapePoint = new Point[6];
            // Get X, Y and Z directions of AXIS SYSTEM
            object[] oXAxis = new object[3];
            object[] oYAxis = new object[3];
            object[] oZAxis = new object[3];

            axisSystemDummyPart.GetXAxis(oXAxis);
            axisSystemDummyPart.GetYAxis(oYAxis);
            axisSystemDummyPart.GetZAxis(oZAxis);

            // Convert object array to double array
            double[] xCoords = oXAxis.OfType<double>().ToArray();
            double[] yCoords = oYAxis.OfType<double>().ToArray();
            double[] zCoords = oZAxis.OfType<double>().ToArray();

            // Create the direction vectors for X, Y and Z directions
            HybridShapeDirection hShapeDirX = BuildDirection(hsfDummyPart, xCoords);
            HybridShapeDirection hShapeDirY = BuildDirection(hsfDummyPart, yCoords);
            HybridShapeDirection hShapeDirZ = BuildDirection(hsfDummyPart, zCoords);

            // Create the 6 extremums for the NON STD BRACKET BODY
            HybridShapeExtremum hShapeExtremum1 = BuildExtremum(bodyCopiedNonStdBracket, tempPartDoc.Part, hsfDummyPart,
                                                     hShapeDirX, 1, "max_X", hBodyConsElements);
            HybridShapeExtremum hShapeExtremum2 = BuildExtremum(bodyCopiedNonStdBracket, tempPartDoc.Part, hsfDummyPart,
                                                     hShapeDirX, 0, "min_X", hBodyConsElements);
            HybridShapeExtremum hShapeExtremum3 = BuildExtremum(bodyCopiedNonStdBracket, tempPartDoc.Part, hsfDummyPart,
                                                     hShapeDirY, 1, "max_Y", hBodyConsElements);
            HybridShapeExtremum hShapeExtremum4 = BuildExtremum(bodyCopiedNonStdBracket, tempPartDoc.Part, hsfDummyPart,
                                                     hShapeDirY, 0, "min_Y", hBodyConsElements);
            HybridShapeExtremum hShapeExtremum5 = BuildExtremum(bodyCopiedNonStdBracket, tempPartDoc.Part, hsfDummyPart,
                                                     hShapeDirZ, 1, "max_Z", hBodyConsElements);
            HybridShapeExtremum hShapeExtremum6 = BuildExtremum(bodyCopiedNonStdBracket, tempPartDoc.Part, hsfDummyPart,
                                                     hShapeDirZ, 0, "min_Z", hBodyConsElements);

            // Create 6 single points using the extremums as refs
            hShapePoint[0] = BuildPointOnExtremum(hShapeExtremum1, tempPartDoc.Part, hsfDummyPart, hBodyConsElements);
            hShapePoint[1] = BuildPointOnExtremum(hShapeExtremum2, tempPartDoc.Part, hsfDummyPart, hBodyConsElements);
            hShapePoint[2] = BuildPointOnExtremum(hShapeExtremum3, tempPartDoc.Part, hsfDummyPart, hBodyConsElements);
            hShapePoint[3] = BuildPointOnExtremum(hShapeExtremum4, tempPartDoc.Part, hsfDummyPart, hBodyConsElements);
            hShapePoint[4] = BuildPointOnExtremum(hShapeExtremum5, tempPartDoc.Part, hsfDummyPart, hBodyConsElements);
            hShapePoint[5] = BuildPointOnExtremum(hShapeExtremum6, tempPartDoc.Part, hsfDummyPart, hBodyConsElements);

            return hShapePoint;
        }

        public static Point BuildPointOnExtremum(AnyObject anyObject, Part part, HybridShapeFactory hybridShapeFactory,
                                            HybridBody hybridBody)
        {
            Reference refAnyObject = part.CreateReferenceFromObject(anyObject);
            Point hShapePoint = hybridShapeFactory.AddNewPointCoordWithReference(0, 0, 0, refAnyObject);
            hShapePoint.Compute();
            hybridBody.AppendHybridShape(hShapePoint);
            return hShapePoint;
        }

        public static HybridShapeExtremum BuildExtremum(AnyObject anyObject, Part part, HybridShapeFactory hybridShapeFactory,
                                  HybridShapeDirection direction, int minMax, string name, HybridBody hybridBody)
        {
            Reference refAnyObject = part.CreateReferenceFromObject(anyObject);
            HybridShapeExtremum hShapeExtremum = hybridShapeFactory.AddNewExtremum(refAnyObject, direction, minMax);
            hShapeExtremum.set_Name(name);
            hybridBody.AppendHybridShape(hShapeExtremum);
            return hShapeExtremum;
        }

        public static HybridShapeDirection BuildDirection(HybridShapeFactory hybridShapeFactory, double[] coordinates)
        {
            HybridShapeDirection hShapeDir = hybridShapeFactory.AddNewDirectionByCoord(coordinates[0], coordinates[1], coordinates[2]);
            hShapeDir.Compute();
            return hShapeDir;
        }

        public static AnyObject Build3DText(Document document, object[] textCoordinates, string text, object[] objectCoordinates, AnyObject anyObject)
        {
            Workbench workbench = document.GetWorkbench("NavigatorWorkbench");
            NavigatorWorkbench navigatorWorkbench = (NavigatorWorkbench)workbench;
            Marker3Ds marker3Ds = navigatorWorkbench.Marker3Ds;
            Marker3D marker3D = marker3Ds.Add3DText(textCoordinates,
                                                    text, objectCoordinates, anyObject);
            marker3D.set_TextFont("Swiss.pfb");
            marker3D.TextSize = 4;
            marker3D.Fill = 0;
            marker3D.Update();
            return marker3D;
        }

        public static void SetHide(Selection selection, AnyObject anyObject)
        {
            selection.Clear();
            selection.Add(anyObject);
            selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            selection.Clear();
        }

        public static void SetColor(Selection selection, AnyObject anyObject, (int, int, int) color)
        {
            selection.Clear();
            selection.Add(anyObject);
            selection.VisProperties.SetRealColor(color.Item1, color.Item2, color.Item3, 0);
            selection.Clear();
        }

        public static void SetLineWidth(Selection selection, AnyObject anyObject, int width)
        {
            selection.Clear();
            selection.Add(anyObject);
            selection.VisProperties.SetRealWidth(width, 0);
            selection.Clear();
        }

        public static AxisSystem GetCurrentAxisSystem(Part part)
        {
            var axisSystems = part.AxisSystems;
            AxisSystem currentAxisSystem = null;

            for (int i = 0; i < axisSystems.Count; i++)
            {
                if (axisSystems.Item(i + 1).IsCurrent == true)
                {
                    currentAxisSystem = axisSystems.Item(i + 1);
                    break;
                }
            }

            return currentAxisSystem;
        }

        private static int PerformClsIp25Dot4MmCheck(ProductDocument rootDoc, string ipPartnumber, double tolerance,
            SPAWorkbench spaWorkBench, HybridShapeFactory hybridShapeFactory, HybridBody dummyGeometricalSet,
            PartDocument tempPartDoc, List<(double X, double Y, double Z)> sortedList)
        {
            int result = 0;
            // Loop through the sorted list to access pairs of adjacent points
            for (int i = 0; i < sortedList.Count - 1; i++)
            {
                var firstPoint = sortedList[i];
                var secondPoint = sortedList[i + 1];

                // Create reference points at cog point coordinates
                Reference point1Reference = (Reference)hybridShapeFactory.AddNewPointCoord(firstPoint.X, firstPoint.Y, firstPoint.Z);
                Reference point2Reference = (Reference)hybridShapeFactory.AddNewPointCoord(secondPoint.X, secondPoint.Y, secondPoint.Z);

                // Calculate the distance between the two points
                double distance = CalculateDistance(firstPoint.X, firstPoint.Y, firstPoint.Z, secondPoint.X, secondPoint.Y, secondPoint.Z);

                if (Math.Abs(distance - 25.4) >= tolerance + EPSILON)
                {
                    result = 1;

                    HybridShapeLinePtPt hShapeLineBetween = hybridShapeFactory.AddNewLinePtPt(point1Reference, point2Reference);
                    hShapeLineBetween.Compute();
                    dummyGeometricalSet.AppendHybridShape(hShapeLineBetween);

                    // Create center point of line
                    HybridShapePointOnCurve hShapePointOnMeasureLine = hybridShapeFactory.AddNewPointOnCurveFromPercent((Reference)hShapeLineBetween, 0.5, false);
                    hShapePointOnMeasureLine.Compute();
                    dummyGeometricalSet.AppendHybridShape(hShapePointOnMeasureLine);

                    // Measure the coordinates of points that will be used to position 3d texts
                    Reference refHShapePointOnMeasureLine = tempPartDoc.Part.CreateReferenceFromObject(hShapePointOnMeasureLine);
                    Measurable measurableHShapePointOnMeasureLine = spaWorkBench.GetMeasurable(refHShapePointOnMeasureLine);
                    object[] coordsPointOnCenter = new object[3];
                    measurableHShapePointOnMeasureLine.GetPoint(coordsPointOnCenter);

                    CatiaImageAnnotationUtils.selectToTransperent(hShapeLineBetween);

                    string errorMsg = $"Distance between cubes is : { distance }mm ";
                    Log.Error($"CLS IP 25.4mm Distance Check: " + errorMsg);

                    // Create 3d text to represent L-W-H dimensions
                    Marker3D marker3D = (Marker3D)Build3DText(rootDoc, coordsPointOnCenter, errorMsg, coordsPointOnCenter, refHShapePointOnMeasureLine);

                    // Change color of 3d text
                    SetColor(tempPartDoc.Selection, marker3D, (255, 0, 255));

                    // Change color of extracted edge
                    SetColor(tempPartDoc.Selection, (AnyObject)hShapeLineBetween, (255, 0, 255));

                    // Change line thickness of extracted edge
                    SetLineWidth(tempPartDoc.Selection, (AnyObject)hShapeLineBetween, 1);

                    /*string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(null, null, null, hShapeLineBetween,
                                null, ipPartnumber, "CLS_IP_25.4mm", errorMsg, property);*/
                }
            }

            tempPartDoc.Part.Update();
            return result;
        }

        public static List<HybridShapeInstance> SearchHoleHnfInPartDocument(PartDocument partDocument, Selection selection)
        {
            Part part = partDocument.Part;
            // SEARCH HnF INSTANCES IN PART DOCUMENT DOCUMENT
            string searchQuery = "(((FreeStyle.Userfeature + 'Part Design'.Userfeature) + 'Generative Shape Design'.Userfeature) + 'Functional Molded Part'.Userfeature),sel";
            selection.Clear();
            selection.Add(part);
            selection.Search(searchQuery);
            List<HybridShapeInstance> listHnfInstances = new List<HybridShapeInstance>();
            for (int i = 1; i <= selection.Count2; i++)
            {
                // CREATE HYBRID SHAPE INSTANCE FOR HnF FEATURES
                HybridShapeInstance hShapeInstanceHnf = (HybridShapeInstance)selection.Item2(i).Value;
                // TRY TO GET HOLE FAMILY PARAMETER
                // IF HnF INSTANCE IS TYPE IS NOT HOLE, THEN EXCEPTION WILL OCCUR
                try
                {
                    hShapeInstanceHnf.GetParameter("Hole_Family");
                }
                catch (Exception e)
                {
                    Log.Warning($"Not able to get parameter Hole_Family, code will continue... {e.ToString()}");
                    continue;
                }
                // CHECK IF THE HnF PARENT NAME AND MAIN BODY NAME IS SAME
                HybridBody hnfGeometricalSet = (HybridBody)hShapeInstanceHnf.Parent;
                Body hnfParentBody = (Body)hnfGeometricalSet.Parent;
                Body mainBody = partDocument.Part.MainBody;
                if (hnfParentBody.get_Name() == mainBody.get_Name())
                {
                    listHnfInstances.Add(hShapeInstanceHnf);
                }
            }
            selection.Clear();
            return listHnfInstances;
        }

        public static HybridShapeExtrude ExtractHnfGeometry(PartDocument partDocument, HybridShapeInstance hnfInstance, HybridBody hybridBodyGeoSet)
        {
            Part part = partDocument.Part;
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            SPAWorkbench spaWorkbench = (SPAWorkbench)partDocument.GetWorkbench("SPAWorkbench");

            // GET HNF OUTPUTS
            Reference drillingAxis = (Reference)hnfInstance.GetOutput("Drilling_Axis");
            Reference drillingStartPoint = (Reference)hnfInstance.GetOutput("Drilling_Point");
            Reference drillingEndPoint = (Reference)hnfInstance.GetOutput("End_Point");

            // GET THE HOLE DIAMETER
            Parameter parameterHoleDia = (Parameter)hnfInstance.GetParameter("Fastener_Diameter");
            RealParam realParameterHoleDia = (RealParam)parameterHoleDia;
            double holeDia = Math.Round(realParameterHoleDia.Value, 3);
            double holeRadius = Math.Round(holeDia / 2, 3);

            // CREATE AN EXTRACT OF DRILLING POINT
            HybridShapeExtract hShapeDrillingStartPoint = hsf.AddNewExtract(drillingStartPoint);
            hShapeDrillingStartPoint.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeDrillingStartPoint);

            // CREATE AN EXTRACT OF END POINT
            HybridShapeExtract hShapeDrillingEndPoint = hsf.AddNewExtract(drillingEndPoint);
            hShapeDrillingEndPoint.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeDrillingEndPoint);

            // CREATE A LINE BETWEEN DRILLING START AND END POINT
            Reference referenceHShapeDrillingStartPoint = part.CreateReferenceFromObject(hShapeDrillingStartPoint);
            Reference referenceHShapeDrillingEndPoint = part.CreateReferenceFromObject(hShapeDrillingEndPoint);
            HybridShapeLinePtPt hShapeLineBetween = hsf.AddNewLinePtPt(referenceHShapeDrillingStartPoint, referenceHShapeDrillingEndPoint);
            hShapeLineBetween.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeLineBetween);

            // MEASURE THE LINE LENGTH
            Reference referenceHShapeLineBetween = part.CreateReferenceFromObject(hShapeLineBetween);
            Measurable measurableHShapeLineBetween = spaWorkbench.GetMeasurable(referenceHShapeLineBetween);
            double lengthLineBetween = Math.Round(measurableHShapeLineBetween.Length, 3);

            // CREATE A DRILLING START PLANE
            HybridShapePlaneOffset hShapeDrillingStartPlane = hsf.AddNewPlaneOffset(drillingAxis, 0, true);
            hShapeDrillingStartPlane.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeDrillingStartPlane);

            // CREATE A DRILLING END PLANE
            HybridShapePlaneOffsetPt hShapeDrillingEndPlane = hsf.AddNewPlaneOffsetPt((Reference)hShapeDrillingStartPlane, drillingEndPoint);
            hShapeDrillingEndPlane.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeDrillingEndPlane);

            // CREATE INNER HOLE CIRCLE
            Reference referenceHShapeDrillingStartPlane = part.CreateReferenceFromObject(hShapeDrillingStartPlane);
            HybridShapeCircleCtrRad hShapeInnerHoleCircle = hsf.AddNewCircleCtrRad(referenceHShapeDrillingStartPoint, referenceHShapeDrillingStartPlane, true, holeRadius);
            hShapeInnerHoleCircle.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeInnerHoleCircle);

            // CREATE HOLE SURFACE
            Reference referenceHShapeInnerHoleCircle = part.CreateReferenceFromObject(hShapeInnerHoleCircle);
            HybridShapeDirection hShapeDirection = hsf.AddNewDirection(referenceHShapeLineBetween);
            hShapeDirection.Compute();
            double lengthLim1 = lengthLineBetween + 0.5;
            double lengthLim2 = 0.5;
            HybridShapeExtrude hShapeExtrudeHoleSurface = hsf.AddNewExtrude(referenceHShapeInnerHoleCircle, lengthLim1, lengthLim2, hShapeDirection);
            hShapeExtrudeHoleSurface.Compute();
            hybridBodyGeoSet.AppendHybridShape(hShapeExtrudeHoleSurface);

            return hShapeExtrudeHoleSurface;
        }

        // Helper method to calculate the distance between two points using basic math
        private static double CalculateDistance(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            double distanceSquared = Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2) + Math.Pow(z2 - z1, 2);
            double distance = Math.Round(Math.Sqrt(distanceSquared), 3);
            return distance;
        }

        private static int CreateClsIpCubeCogPoint(IpvCheckProperty property, string ipPartNumber, ICollection<Product> cubeCheckList, ProductDocument rootDoc,
            List<(double X, double Y, double Z)> pointsList, bool isTrend, out HybridShapeFactory hybridShapeFactory,
            out HybridBody dummyGeometricalSet, out PartDocument tempPartDoc)
        {
            int result = 0;

            Log.Information($"CLS IP 25.4mm Distance Check: start creatings Cog points)");

            // Add temp product under root product for calculation CLS IP Cube distance.
            Product tempPart = rootDoc.Product.Products.AddNewComponent("Part", "");
            tempPart.ActivateDefaultShape();
            tempPartDoc = (PartDocument)tempPart.ReferenceProduct.Parent;

            // CREATE THE NECESSARY GEOMETRICAL SETS
            HybridBodies hybridBodies = tempPartDoc.Part.HybridBodies;
            hybridShapeFactory = (HybridShapeFactory)tempPartDoc.Part.HybridShapeFactory;
            dummyGeometricalSet = hybridBodies.Add();
            dummyGeometricalSet.set_Name("IP_Cube_DUMMY_WORKING_ELEMENTS");
            HybridBodies tempGeoSet = dummyGeometricalSet.HybridBodies;

            tempPartDoc.Part.Update();

            string ipNumberForTrend = (isTrend) ? ipPartNumber : null;

            // loop all cubes, could have more than one in an IP
            foreach (Product cube in cubeCheckList)
            {

                Product cubeProd = cube;
                Product primStructProd = null;
                IpvClashResult clashResult = ComputeClash(property, null, ref cubeProd, ref primStructProd, ipNumberForTrend);

                // Compute cube clash with something
                if (null != clashResult.isCubeClashWithSomething && true == clashResult.isCubeClashWithSomething)
                {
                    //clashedCubes.Add(cubeProd);
                    result = 0;
                    Log.Information($"CLS IP 25.4mm Distance Check: Found clashed cube - {cubeProd.get_Name()}");
                }
                else
                {
                    result = 1;
                    string errorMsg = $"A Cube is not clashing with anything";
                    Body cubeBody = GetPart(cubeProd).MainBody;
                    Reference cubeRef = GetPart(cubeProd).CreateReferenceFromObject(cubeBody);
                    string errorImageFolder = CatiaImageAnnotationUtils.CaptureAnnotatedView(null, null, cubeBody, null,
                        cubeRef, ipPartNumber, "CBNotInAir", errorMsg, property);
                    Log.Information($"CLS IP 25.4mm Distance Check: One cube is not clashing with anything - {cubeProd.get_Name()}");
                    break;
                }

                // create Cog point for IP cube in temp part doc
                tempPartDoc.Part.InWorkObject = dummyGeometricalSet;

                HybridShapePointCoord pointOfCog = CreatePartCogPoint(cube, tempPartDoc, hybridShapeFactory, dummyGeometricalSet);

                // get cog coordinates
                object[] cubeCog = new object[3];
                pointOfCog.GetCoordinates(cubeCog);

                // Add points with x, y, and z coordinates
                pointsList.Add(((Double)cubeCog[0], (Double)cubeCog[1], (Double)cubeCog[2]));
            }
            return result;
        }

        private static List<CatiaHnfUtils> GetAllHnfInstancesFromPartDocument(Selection selection, Product secondaryProd, out PartDocument bracketPartDocument, out Part part)
        {
            bracketPartDocument = (PartDocument)secondaryProd.ReferenceProduct.Parent;
            part = bracketPartDocument.Part;
            CatiaHnfUtils hnf = null;

            // SEARCH HolesAndFastener INSTANCES IN PART
            string searchQuery = "(((FreeStyle.Userfeature + 'Part Design'.Userfeature) + 'Generative Shape Design'.Userfeature) + 'Functional Molded Part'.Userfeature),sel";
            selection.Clear();
            selection.Add(part);
            selection.Search(searchQuery);
            List<CatiaHnfUtils> listHnfInstances = new List<CatiaHnfUtils>();
            for (int i = 1; i <= selection.Count2; i++)
            {
                HybridShapeInstance hsi1 = (HybridShapeInstance)selection.Item(i).Value;
                // CREATE HnF CLASS FOR EACH ITEM IN SELECTION
                hnf = new CatiaHnfUtils((AnyObject)selection.Item(i).Value);
                if (!hnf.ToString().ToLower().Contains("bonding_hole")) // A temporary bug-fix solution that will be replaced later.
                {
                    listHnfInstances.Add(hnf);
                }
            }

            selection.Clear();
            return listHnfInstances;
        }

        public static HybridShapeAssemble BuildAssembledHnfHolesSurfaceInPartDocument(PartDocument partDocument, HybridBodies tempHybridBodies,
            List<CatiaHnfUtils> listHnfInstances, bool isBracketType, ref HybridBody hnfHoleSurfacesGeometricalSet, ref HybridBody hnfGeometryExtractionGeometricalSet,
            ref HybridBody hnfHoleSurfacesforPSGeometricalSet)
        {

            // ADD A GEOMETRICAL SET FOR HNF GEOMETRY EXTRACTION IN PART DOCUMENT
            Part part = partDocument.Part;
            HybridBodies hybridBodies = part.HybridBodies;
            hnfGeometryExtractionGeometricalSet = hybridBodies.Add();
            hnfGeometryExtractionGeometricalSet.set_Name("HNF GEOMETRY EXTRACTION");

            if (!isBracketType)
            {
                bool hBodyExists = tempHybridBodies.OfType<HybridBody>().Any(hb => hb.get_Name() == "HNF HOLE SURFACES FOR STRUCTURE");
                if (!hBodyExists)
                {
                    hnfHoleSurfacesforPSGeometricalSet = tempHybridBodies.Add();
                    hnfHoleSurfacesforPSGeometricalSet.set_Name("HNF HOLE SURFACES FOR STRUCTURE");
                }
                else
                {
                    hnfHoleSurfacesforPSGeometricalSet = (HybridBody)tempHybridBodies.GetItem("HNF HOLE SURFACES FOR STRUCTURE");
                }

            }

            bool hybridBodyExists = tempHybridBodies.OfType<HybridBody>().Any(hb => hb.get_Name() == "HNF HOLE SURFACES FOR BRACKET");

            if (!hybridBodyExists)
            {
                hnfHoleSurfacesGeometricalSet = tempHybridBodies.Add();
                hnfHoleSurfacesGeometricalSet.set_Name("HNF HOLE SURFACES FOR BRACKET");
            }
            else
            {
                hnfHoleSurfacesGeometricalSet = (HybridBody)tempHybridBodies.GetItem("HNF HOLE SURFACES FOR BRACKET");
            }


            // FOR EACH HOLE HNF INSTANCE IN LIST, EXTRACT HOLE SURFACE GEOMETRY AND APPEND INTO A LIST
            List<HybridShapeExtrude> listBuiltHnfHoleSurfaces = new List<HybridShapeExtrude>();
            foreach (var hnfInstance in listHnfInstances)
            {
                HybridShapeExtrude hnfHoleSurface = BuildSingleHnfHoleSurface(hnfInstance, partDocument);
                listBuiltHnfHoleSurfaces.Add(hnfHoleSurface);
            }

            // CREATE A JOIN TO ASSEMBLE ALL HOLE SURFACES
            Reference referenceHnfHoleSurface1 = part.CreateReferenceFromObject(listBuiltHnfHoleSurfaces[0]);
            Reference referenceHnfHoleSurface2 = part.CreateReferenceFromObject(listBuiltHnfHoleSurfaces[1]);
            HybridShapeFactory hybSF = (HybridShapeFactory)part.HybridShapeFactory;
            HybridShapeAssemble joinAllHnfHoles = hybSF.AddNewJoin(referenceHnfHoleSurface1, referenceHnfHoleSurface2);

            // FOR EACH HNF HOLE SURFACE IN LIST, APPEND INTO JOIN
            for (int i = 2; i < listBuiltHnfHoleSurfaces.Count; i++)
            {
                Reference referenceHnfHoleSurfaceX = part.CreateReferenceFromObject(listBuiltHnfHoleSurfaces[i]);
                joinAllHnfHoles.AddElement(referenceHnfHoleSurfaceX);
            }

            joinAllHnfHoles.SetManifold(false);
            joinAllHnfHoles.SetConnex(false);
            joinAllHnfHoles.Compute();
            hnfGeometryExtractionGeometricalSet.AppendHybridShape(joinAllHnfHoles);

            return joinAllHnfHoles;

        }

        public static HybridShapeExtrude BuildSingleHnfHoleSurface(CatiaHnfUtils hnf, PartDocument partDocument)
        {
            // GET HNF FASTENER DIAMETER
            double fastenerDiameter = hnf.GetValueOfHnfParameter(CatiaHnfUtils.FASTENER_DIAMETER_PARAMETER_NAME);

            // GET HNF HOLE DEPTH
            double holeDepth = hnf.GetValueOfHnfParameter(CatiaHnfUtils.HOLE_DEPTH_PARAMETER_NAME);

            // CREATE AN EXTRACT OF DRILLING POINT
            AnyObject drillingPointAnyObject = (AnyObject)hnf.GetOutputOfHnf(CatiaHnfUtils.DRILLING_POINT);
            HybridShapeExtract drillingPoint = BuildExtractFromPoint(partDocument, drillingPointAnyObject);

            // CREATE AN EXTRACT OF END POINT
            AnyObject endPointAnyObject = (AnyObject)hnf.GetOutputOfHnf(CatiaHnfUtils.END_POINT);
            HybridShapeExtract endPoint = BuildExtractFromPoint(partDocument, endPointAnyObject);

            // CREATE A LINE BETWEEN DRILLING AND END POINTS
            Line lineBetween = BuildLineBetweenTwoPoints(partDocument, drillingPoint, endPoint);

            // CREATE DRILLING PLANE
            AnyObject drillingAxisAnyObject = (AnyObject)hnf.GetOutputOfHnf(CatiaHnfUtils.DRILLING_AXIS);
            HybridShapePlaneOffset drillingPlane = BuildOffsetPlane(partDocument, drillingAxisAnyObject, 0);

            // CREATE A CIRCLE AT DRILLING PLANE
            HybridShapeCircle circleAtDrillingPlane = BuildCircleOnPlane(partDocument, drillingPlane,
                                                                drillingPoint, fastenerDiameter);

            // CREATE HOLE SURFACE
            HybridShapeExtrude drillingSurface = BuildCircularExtrude(partDocument, circleAtDrillingPlane, lineBetween, holeDepth, 0.5);

            return drillingSurface;
        }

        // Helper methods (you'll need to implement these):
        public static HybridShapeExtract BuildExtractFromPoint(PartDocument partDocument, AnyObject point)
        {
            // Implementation to create an extract of a point from AnyObject
            Part part = partDocument.Part;
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            HybridShapeExtract extractedPoint = hsf.AddNewExtract((Reference)point);
            extractedPoint.Compute();
            return extractedPoint;
        }

        public static Line BuildLineBetweenTwoPoints(PartDocument partDocument, HybridShapeExtract startPoint,
                                HybridShapeExtract endPoint)
        {
            // Implementation to create a line between two points
            Part part = partDocument.Part;
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;

            Reference referencePoint1 = part.CreateReferenceFromObject(startPoint);
            Reference referencePoint2 = part.CreateReferenceFromObject(endPoint);

            HybridShapeLinePtPt lineBetween = hsf.AddNewLinePtPt(referencePoint1, referencePoint2);
            lineBetween.Compute();

            return lineBetween;
        }

        public static HybridShapePlaneOffset BuildOffsetPlane(PartDocument partDocument, AnyObject referencePlaneForOffset,
                                                double offsetValue)
        {
            // Implementation to create a plane offset from an axis
            Part part = partDocument.Part;
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            HybridShapePlaneOffset planeOffset = hsf.AddNewPlaneOffset((Reference)referencePlaneForOffset, offsetValue, true);
            planeOffset.Compute();
            return planeOffset;
        }

        public static HybridShapeCircle BuildCircleOnPlane(PartDocument partDocument, AnyObject plane,
                                    HybridShapeExtract centerPoint, double circleDiameter)
        {
            // Implementation to create a circle on a plane with a given center point and diameter
            Part part = partDocument.Part;
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            Reference referencePlane = part.CreateReferenceFromObject(plane);
            Reference referencePoint = part.CreateReferenceFromObject(centerPoint);
            HybridShapeCircle circle = hsf.AddNewCircleCtrRad(referencePoint, referencePlane, true, circleDiameter / 2);
            circle.Compute();
            return circle;
        }

        public static HybridShapeExtrude BuildCircularExtrude(PartDocument partDocument, HybridShapeCircle circle,
                                                            Line axisLine, double extrudeLength, double extrudeAdditionalLength)
        {
            // Implementation to create a circular extrude surface
            Part part = partDocument.Part;
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;

            Reference referenceCircle = part.CreateReferenceFromObject(circle);
            Reference referenceLine = part.CreateReferenceFromObject(axisLine);

            HybridShapeDirection direction = hsf.AddNewDirection(referenceLine);
            direction.Compute();

            double lengthLim1 = extrudeLength + extrudeAdditionalLength;
            double lengthLim2 = extrudeAdditionalLength;

            HybridShapeExtrude circularExtrude = hsf.AddNewExtrude(referenceCircle, lengthLim1,
                                                                        lengthLim2, direction);
            circularExtrude.Compute();

            return circularExtrude;
        }

        public static bool CheckIfHnfIsStoredInMainBody(CatiaHnfUtils hnf, PartDocument partDocument)
        {
            try
            {
                Part part = partDocument.Part;
                Parameters parameters = part.Parameters;

                string path = parameters.GetNameToUseInRelation(hnf.hsi);

                if (path.Contains("`"))
                {
                    path = path.Replace("`", "");
                }

                string[] pathComponents = path.Split('\\');
                string mainBodyNameFromPath = pathComponents[0];
                Body mainBody = part.MainBody;

                if (mainBodyNameFromPath == mainBody.get_Name())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                return false;
            }
        }

        public static Body BuildPitchEffectiveAreaSolid(Part part, SPAWorkbench spaWorkbench, HybridBody supportingElementsForPDCheckGeoSet,
                                         List<object> listCenterPoints, double effectiveAreaDiameter, Body bodyStructure,
                                         AnyObject axisLine, HybridBody holeSurfacesGeoSet = null)
        {

            PartDocument partDocument = (PartDocument)part.Parent;

            HybridShapeExtract centerPoint1 = BuildExtractFromPoint(partDocument, (AnyObject)listCenterPoints[0]);
            HybridShapeExtract centerPoint2 = BuildExtractFromPoint(partDocument, (AnyObject)listCenterPoints[1]);

            // CREATE PLANES NORMAL TO AXIS LINE AT CENTER POINT 1
            HybridShapePlaneNormal planeNormalToAxisLineAtCp1 = BuildPlaneNormalToLine(part, centerPoint1, axisLine);

            // CREATE A LINE BETWEEN CENTER POINTS
            Line lineBetweenCp1AndCp2 = BuildLineBetweenTwoPoints(partDocument, centerPoint1, centerPoint2);

            // CREATE A CIRCLE CURVE FOR PITCH EFFECTIVE AREA
            HybridShapeCircle circlePitchEffectiveArea = BuildCircleOnPlane(partDocument, planeNormalToAxisLineAtCp1, centerPoint1,
                                                                            effectiveAreaDiameter);

            // MEASURE THE LENGTH OF THE LINE BETWEEN
            double lengthLineBetweenCp1AndCp2 = GetLengthOfObject(part, spaWorkbench, lineBetweenCp1AndCp2);

            // CREATE AN CYLINDER SURFACE FOR PITCH EFFECTIVE AREA
            HybridShapeExtrude extrudePitchEffectiveArea = BuildCircularExtrude(partDocument, circlePitchEffectiveArea,
                                                                                lineBetweenCp1AndCp2,
                                                                                lengthLineBetweenCp1AndCp2, 0.5 * lengthLineBetweenCp1AndCp2);
            supportingElementsForPDCheckGeoSet.AppendHybridShape(extrudePitchEffectiveArea);

            // ADD A NEW BODY FOR PITCH EFFECTIVE AREA
            Body bodyPitchEffectiveArea = AddNewBody(part, "BodySafeZone");

            // CREATE A SOLID BY CLOSING PITCH EFFECTIVE AREA SURFACE
            CloseSurface closeSurfacePitchEffectiveArea = BuildCloseSurface(part, bodyPitchEffectiveArea,
                                                                            extrudePitchEffectiveArea);

            // CREATE AN EXTRACT OF PRIMARY STRUCTURE BODY
            Body bodyDuplicatedPrimaryStructure = BuildDuplicateOfAnExistingBody(part, bodyStructure,
                                                                    "DummyBodyForPitchDistanceCheck");

            // INTERSECT TWO BODIES
            Intersect intersection = BuildIntersectionOfTwoBodies(part, bodyDuplicatedPrimaryStructure,
                                                                bodyPitchEffectiveArea);

            // SPLIT PITCH EFFECTIVE AREA SOLID WITH HOLE SURFACES
            if (holeSurfacesGeoSet != null)
            {
                HybridShapes hybridShapesHoleSurfacesGeoSet = holeSurfacesGeoSet.HybridShapes;
                foreach (HybridShape hybridShapeHoleSurface in hybridShapesHoleSurfacesGeoSet)
                {
                    Split splitBracketWithHnf = SplitSolidWithSurface(part, bodyDuplicatedPrimaryStructure,
                                                                            hybridShapeHoleSurface);
                }
            }
            return bodyDuplicatedPrimaryStructure;
        }

        public static HybridShapePlaneNormal BuildPlaneNormalToLine(Part part, AnyObject point, AnyObject line)
        {
            Reference referencePoint = part.CreateReferenceFromObject(point);
            Reference referenceLine = part.CreateReferenceFromObject(line);

            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            HybridShapePlaneNormal lineNormalToPlane = hsf.AddNewPlaneNormal(referenceLine, referencePoint);
            lineNormalToPlane.Compute();

            return lineNormalToPlane;
        }

        public static double GetLengthOfObject(Part part, SPAWorkbench spaWorkbench, AnyObject anyObject)
        {
            Reference referenceAnyObject = part.CreateReferenceFromObject(anyObject);
            Measurable measurableAnyObject = spaWorkbench.GetMeasurable(referenceAnyObject);
            double lengthAnyObject = (double)Math.Round(measurableAnyObject.Length, 3);
            return lengthAnyObject;
        }

        public static Body AddNewBody(Part part, string name)
        {
            // Adding a new body in the given part.
            Body newBody = part.Bodies.Add();
            newBody.set_Name(name);
            return newBody;
        }

        public static CloseSurface BuildCloseSurface(Part part, Body body, AnyObject surface)
        {
            part.InWorkObject = body;
            ShapeFactory sf = (ShapeFactory)part.ShapeFactory;
            Reference referenceSurface = part.CreateReferenceFromObject(surface);
            CloseSurface closeSurface = sf.AddNewCloseSurface(referenceSurface);
            part.UpdateObject(body);
            return closeSurface;
        }

        public static Body BuildDuplicateOfAnExistingBody(Part part, Body existingBody, string targetBodyName)
        {
            INFITF.Reference referenceExistingBody = part.CreateReferenceFromObject(existingBody);
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            HybridShapeExtract extractExistingBody = hsf.AddNewExtract(referenceExistingBody);
            extractExistingBody.Compute();

            Bodies bodies = part.Bodies;
            Body targetBody = bodies.Add();
            targetBody.set_Name(targetBodyName);

            part.InWorkObject = targetBody;
            INFITF.Reference referenceExtractOfExistingBody = part.CreateReferenceFromObject(extractExistingBody);
            ShapeFactory sf = (ShapeFactory)part.ShapeFactory;
            sf.AddNewCloseSurface(referenceExtractOfExistingBody);
            part.UpdateObject(targetBody);

            return targetBody;
        }

        public static Intersect BuildIntersectionOfTwoBodies(Part part, Body body1, Body body2)
        {
            // Creates a shape factory intersection between given bodies.
            ShapeFactory sf = (ShapeFactory)part.ShapeFactory;
            part.InWorkObject = body1;
            Intersect intersectBodies = sf.AddNewIntersect(body2);
            part.UpdateObject(body1);
            return intersectBodies;
        }

        public static HybridShapeIntersection BuildIntersection(Part part, AnyObject element1, AnyObject element2)
        {
            // Creates a hybrid shape intersection from given elements.
            HybridShapeFactory hybridShapeFactory = (HybridShapeFactory)part.HybridShapeFactory;
            Reference referenceElement1 = part.CreateReferenceFromObject(element1);
            Reference referenceElement2 = part.CreateReferenceFromObject(element2);
            HybridShapeIntersection intersection = hybridShapeFactory.AddNewIntersection(referenceElement1, referenceElement2);
            intersection.Compute();

            return intersection;
        }

        public static Split SplitSolidWithSurface(Part part, Body body, AnyObject surface)
        {
            // Get the shape factory from the part
            ShapeFactory sf = (ShapeFactory)part.ShapeFactory;

            // Create a reference to the given surface
            Reference referenceSurface = part.CreateReferenceFromObject(surface);

            // Set the working object to the given body
            part.InWorkObject = body;

            // Add a new split operation on the positive side of the reference surface
            Split split = sf.AddNewSplit(referenceSurface, CatSplitSide.catPositiveSide);

            // Update the body in the part
            part.UpdateObject(body);

            return split;
        }

        public static List<Face> SearchAndGetAllFacesOfBody(Selection selection, Body body)
        {
            // Searches all faces in the given body and appends them to a list.
            selection.Clear();
            selection.Add(body);
            selection.Search("Topology.Face,sel");
            List<Face> listFaces = new List<Face>();

            for (int i = 0; i < selection.Count2; i++)
            {
                Face selectedFace = (Face)selection.Item2(i + 1).Value;
                listFaces.Add(selectedFace);
            }

            selection.Clear();
            return listFaces;
        }

        public static List<Dictionary<string, object>> FilterCylindricalFaces(List<Face> listFaces, Part part, SPAWorkbench spaWorkbench,
                                                   HybridBody supportingElementsGeoSet, HybridBody axisLinesGeoSet)
        {
            // LOOP THROUGH ALL FACES AND CHECK IF FACE IS CYLINDRICAL HOLE
            List<Dictionary<string, object>> listCylindricalFaces = new List<Dictionary<string, object>>();
            foreach (Face face in listFaces)
            {
                Dictionary<string, object> dictHoleFace = GetFaceProperties(part, spaWorkbench, face,
                                                            supportingElementsGeoSet, axisLinesGeoSet);
                if (dictHoleFace["isCylindricalHole"] is true)
                {
                    listCylindricalFaces.Add(dictHoleFace);
                }
            }
            return listCylindricalFaces;
        }

        public static Dictionary<string, object> GetFaceProperties(Part part, SPAWorkbench spaWorkbench, AnyObject face,
                                            HybridBody holeFaceExtractsGeoSet, HybridBody holeFaceAxisLinesGeoSet)
        {
            Dictionary<string, object> dictFace = new Dictionary<string, object>
            {
                ["isCylindricalHole"] = false,
                ["diameter"] = null,
                ["axisLine"] = null
            };

            try
            {
                // CREATE AN EXTRACT FROM FACE AND APPEND INTO GEOMETRICAL SET
                HybridShapeExtract extractOfFace = BuildExtractFromFace(part, face);
                holeFaceExtractsGeoSet.AppendHybridShape(extractOfFace);

                // CREATE BOUNDARY OF THE EXTRACTED FACES
                HybridShapeBoundary boundaryOfFace = BuildBoundaryOfSurface(part, extractOfFace);

                // TRY TO JOIN BOUNDARY AND UPDATE
                try
                {
                    HybridShapeAssemble join = BuildJoinOfSingleElement(part, boundaryOfFace);
                    part.UpdateObject(join);
                    return dictFace;
                }
                catch (Exception)
                {
                    // THIS EXCEPTION WILL OCCUR IF BOUNDARY IS NOT A SINGLE CLOSED CURVE

                    // TRY TO DISASSEMBLE THE BOUNDARY
                    Array datumsOfBoundary = BuildDatums(part, boundaryOfFace);

                    // IF BOUNDARY IS CONSISTING OF TWO CURVES
                    // CHECK IF THE CURVES HAVE THE SAME LENGTH
                    // ONLY CYLINDRICAL HOLES AND ELLIPTICAL/HOLES CUTOUT EDGES WILL HAVE SAME LENGTHS
                    if (datumsOfBoundary.Length == 2)
                    {
                        double lengthFirstDatum = GetLengthOfObject(part, spaWorkbench, (AnyObject)datumsOfBoundary.GetValue(0));
                        double lengthSecondDatum = GetLengthOfObject(part, spaWorkbench, (AnyObject)datumsOfBoundary.GetValue(1));
                        if (lengthFirstDatum == lengthSecondDatum)
                        {
                            try
                            {
                                // MEASURE THE DIAMETER OF NEAR HOLES
                                double diameterOfNearHole = GetDiameterOfAnyObject(part, spaWorkbench, extractOfFace);
                                dictFace["diameter"] = diameterOfNearHole;
                                dictFace["isCylindricalHole"] = true;

                                // CREATE AN AXIS LINE OF HOLES NEAR TO MOUNTING HOLE
                                HybridShapeAxisLine axisLineOfNearHole = BuildAxisLineOfSurface(part, extractOfFace);
                                holeFaceAxisLinesGeoSet.AppendHybridShape(axisLineOfNearHole);
                                dictFace["axisLine"] = axisLineOfNearHole;
                                return dictFace;
                            }
                            catch (Exception)
                            {
                                return dictFace;
                            }
                        }
                        else
                        {
                            return dictFace;
                        }
                    }
                    else
                    {
                        return dictFace;
                    }
                }
            }
            catch (Exception)
            {
                return dictFace;
            }

        }

        public static HybridShapeExtract BuildExtractFromFace(Part part, AnyObject face)
        {
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            HybridShapeExtract extract = hsf.AddNewExtract((Reference)face);
            extract.PropagationType = 2;
            extract.Compute();
            return extract;
        }

        public static HybridShapeBoundary BuildBoundaryOfSurface(Part part, AnyObject surface)
        {
            // Assuming your Part class has a HybridShapeFactory property named hybridShapeFactory
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;

            // Create a reference from the surface object
            Reference referenceSurface = part.CreateReferenceFromObject(surface);

            // Add a new boundary of the surface using the reference
            HybridShapeBoundary boundary = hsf.AddNewBoundaryOfSurface(referenceSurface);

            // Compute the boundary
            boundary.Compute();
            //boundary.GetType().InvokeMember("Compute", System.Reflection.BindingFlags.InvokeMethod, null, boundary, null);

            return boundary;
        }

        public static HybridShapeAssemble BuildJoinOfSingleElement(Part part, AnyObject anyObject)
        {
            // Get the hybrid_shape_factory from the Part object
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;

            // Create a reference from the AnyObject
            Reference referenceAnyObject = part.CreateReferenceFromObject((Reference)anyObject);

            // Add a new join with the reference object (joining the object with itself)
            HybridShapeAssemble join = hsf.AddNewJoin(referenceAnyObject, referenceAnyObject);

            // Remove the duplicate element (the second element added by joining the object with itself)
            join.RemoveElement(1);

            return join;
        }

        public static Array BuildDatumsFromBody(Part part, Body body, 
            HybridBody dummyDisassemblySet, Product tempPartProd)
        {
            List<object> datumList = new List<object>();
            Array datums = null;

            try
            {
                foreach (Shape shape in body.Shapes)
                {
                    HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
                    Reference referenceAnyObject = part.CreateReferenceFromObject(shape);
                    HybridShapeExtract extract = hsf.AddNewExtract(referenceAnyObject);
                    extract.Compute();
                    Reference referenceExtract = part.CreateReferenceFromObject(extract);
                    dummyDisassemblySet.AppendHybridShape(extract);
                    tempPartProd.Update();

                    //datums = hsf.AddNewDatums(referenceExtract);
                    List<object> tmpDatumList = hsf.AddNewDatums(referenceExtract).Cast<object>().ToList();
                    datumList.AddRange(tmpDatumList);
                    // If you need to get more information about the created datums, you can use the DatumInfo class
                    // DatumInfo datumInfo = GetDatumInfo(datums);
                }

                if (datumList.Count > 0)
                {
                    datums = datumList.ToArray();
                }

            }
            catch
            {
            }

            return datums;
        }

        public static Array BuildDatums(Part part, AnyObject anyObject)
        {
            HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;
            Reference referenceAnyObject = part.CreateReferenceFromObject(anyObject);
            Array datums = hsf.AddNewDatums(referenceAnyObject);
            //List<object> datums = new List<object> { hsf.AddNewDatums(referenceAnyObject) };

            // If you need to get more information about the created datums, you can use the DatumInfo class
            // DatumInfo datumInfo = GetDatumInfo(datums);

            return datums;
        }

        public static double GetDiameterOfAnyObject(Part part, SPAWorkbench spaWorkbench, AnyObject anyObject)
        {
            // Measure the diameter of the given element.
            Reference referenceAnyObject = part.CreateReferenceFromObject(anyObject);
            Measurable measurableAnyObject = spaWorkbench.GetMeasurable(referenceAnyObject);
            double radiusAnyObject = measurableAnyObject.Radius;
            //double radiusAnyObject = (double)measurableAnyObject.GetType().GetProperty("Radius").GetValue(measurableAnyObject, null);
            double diameterAnyObject = 2 * Math.Round(radiusAnyObject, 3);
            return diameterAnyObject;
        }

        public static HybridShapeAxisLine BuildAxisLineOfSurface(Part part, AnyObject surface)
        {
            // Creates an axis line for given surface.
            HybridShapeFactory hybridShapeFactory = (HybridShapeFactory)part.HybridShapeFactory;
            Reference referenceSurface = part.CreateReferenceFromObject(surface);
            HybridShapeAxisLine axisLine = hybridShapeFactory.AddNewAxisLine(referenceSurface);
            axisLine.Compute();
            return axisLine;
        }

        public static bool PerformSinglePitchDistanceCheckBetweenTwoAxisLines(Part part, SPAWorkbench spaWorkbench,
                                                                         double diameter1, double diameter2,
                                                                         AnyObject axisLine1, AnyObject axisLine2,
                                                                         double pitchDistanceCoefficient)
        {
            bool result = false;

            // CALCULATE ALLOWED PITCH DISTANCE
            double averageDiameter = (diameter1 + diameter2) / 2;
            double pitchDistanceLimit = pitchDistanceCoefficient * averageDiameter;

            // MEASURE THE MINIMUM DISTANCE BETWEEN TWO AXIS LINES
            double minDistBetweenAxisLines = GetMinimumDistanceBetweenTwoElements(part, spaWorkbench,
                                                                                   axisLine1, axisLine2);
            // MEASURE THE ANGLE BETWEEN TWO AXIS LINES
            double angleBetweenAxisLines = GetAngleBetweenTwoElements(part, spaWorkbench, axisLine1, axisLine2);
            // AXIS LINES NEED TO BE PARALLEL
            if (Math.Abs(angleBetweenAxisLines % 180) < EPSILON)
            {
                // AXIS LINES NEED TO BE DIFFERENT
                if (Math.Abs(minDistBetweenAxisLines) > EPSILON)
                {
                    // MIN DIST NEEDS TO BE IN ALLOWED RANGE
                    if (minDistBetweenAxisLines >= pitchDistanceLimit)
                    {
                        result = true;
                    }
                    else
                    {
                        result = false;
                    }
                }
                //else
                //{
                //    result = true;
                //}
            }

            return result;
        }

        public static double GetMinimumDistanceBetweenTwoElements(Part part, SPAWorkbench spaWorkbench,
                                                              AnyObject firstElement, AnyObject secondElement)
        {
            try
            {
                Reference referenceFirstElement = part.CreateReferenceFromObject(firstElement);
                Reference referenceSecondElement = part.CreateReferenceFromObject(secondElement);
                Measurable measurableFirstElement = spaWorkbench.GetMeasurable(referenceFirstElement);

                // Ensure the measurable object is not null before proceeding
                if (measurableFirstElement != null)
                {
                    double minimumDistance = measurableFirstElement.GetMinimumDistance(referenceSecondElement);
                    double roundedMinimumDistance = Math.Round(minimumDistance, 3);
                    return roundedMinimumDistance;
                }
                else
                {
                    // Return a default value or handle the error accordingly
                    return 0.0;
                }
            }
            catch (Exception)
            {
                // Return a default value or handle the error accordingly
                return 0.0;
            }
        }

        public static double GetAngleBetweenTwoElements(Part part, SPAWorkbench spaWorkbench,
                                                    AnyObject firstElement, AnyObject secondElement)
        {
            // Create references from the given elements
            Reference referenceFirstElement = part.CreateReferenceFromObject(firstElement);
            Reference referenceSecondElement = part.CreateReferenceFromObject(secondElement);

            // Get the measurable objects from the references
            Measurable measurableFirstElement = spaWorkbench.GetMeasurable(referenceFirstElement);

            // Get the angle between the two measurable elements
            double angle = 0.0;
            if (measurableFirstElement != null)
            {
                angle = measurableFirstElement.GetAngleBetween(referenceSecondElement);
            }

            // Round the angle to 3 decimal places
            double roundedAngle = Math.Round(angle, 3);
            return roundedAngle;
        }

        public static bool CheckIfFaceIsCylindricalOrEllipticalCutOut(Part part, SPAWorkbench spaWorkbench, HybridShapeExtract face)
        {
            try
            {
                Part docPart = part; //part.Part;
                HybridShapeFactory hsf = (HybridShapeFactory)docPart.HybridShapeFactory;

                Measurable measurable = spaWorkbench.GetMeasurable((Reference)face);
                double radius = measurable.Radius;

                HybridShapeExtract extractOfFace = hsf.AddNewExtract((Reference)face);
                extractOfFace.Compute();

                // CREATE BOUNDARY OF THE EXTRACTED FACES
                HybridShapeBoundary boundary = hsf.AddNewBoundaryOfSurface((Reference)extractOfFace);

                // TRY TO JOIN BOUNDARY AND UPDATE
                try
                {
                    HybridShapeAssemble join = hsf.AddNewJoin((Reference)boundary, (Reference)boundary);
                    join.RemoveElement(1);
                    docPart.UpdateObject(join);
                }
                // THIS EXCEPTION WILL OCCUR IF BOUNDARY IS NOT A SINGLE CLOSED CURVE
                catch (Exception)
                {
                    try
                    {
                        // TRY TO DISASSEMBLE THE BOUNDARY
                        Array datumsOfBoundary = hsf.AddNewDatums((Reference)boundary);

                        // IF BOUNDARY IS CONSISTING OF TWO CURVES
                        // CHECK IF THE CURVES HAVE THE SAME LENGTH
                        // ONLY CYLINDRICAL HOLES CUTOUT EDGES WILL HAVE THE SAME LENGTHS
                        if (datumsOfBoundary.Length == 2)
                        {
                            Reference referenceFirstDatum = docPart.CreateReferenceFromObject((AnyObject)datumsOfBoundary.GetValue(0));
                            Measurable measurableFirstDatum = spaWorkbench.GetMeasurable(referenceFirstDatum);
                            double lengthFirstDatum = measurableFirstDatum.Length;
                            double roundLengthFirstDatum = Math.Round(lengthFirstDatum, 3);

                            Reference referenceSecondDatum = docPart.CreateReferenceFromObject((AnyObject)datumsOfBoundary.GetValue(1));
                            Measurable measurableSecondDatum = spaWorkbench.GetMeasurable(referenceSecondDatum);
                            double lengthSecondDatum = measurableSecondDatum.Length;
                            double roundLengthSecondDatum = Math.Round(lengthSecondDatum, 3);

                            if (roundLengthFirstDatum == roundLengthSecondDatum)
                            {
                                return true;
                            }
                            else
                            {
                                try
                                {
                                    _ = hsf.AddNewAxisLine((Reference)extractOfFace);
                                    return true;
                                }
                                catch (Exception)
                                {
                                    return false;
                                }
                            }
                        }
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }

            return false;
        }

        public static bool TrendNodePrePostCheck(bool isVisible)
        {
            bool isVisibilityChanged = false;
            ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            Product desiredNode = CatiaProdUtils.RecursiveFindInst("A350", rootDoc.Product);

            if (desiredNode != null)
            {
                Selection selection = rootDoc.Selection;
                selection.Clear();
                selection.Add(desiredNode);

                // Get the visualization properties of the selected node
                VisPropertySet visProperties = selection.VisProperties;

                // Check the visibility state of the selected node
                CatVisPropertyShow showState;
                visProperties.GetShow(out showState);

                // Toggle the visibility of the node
                if (isVisible && showState == CatVisPropertyShow.catVisPropertyNoShowAttr)
                {
                    selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyShowAttr);
                }
                else if (showState == CatVisPropertyShow.catVisPropertyShowAttr)
                {
                    selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
                    isVisibilityChanged = true;
                }
                selection.Clear();
            }

            return isVisibilityChanged;
        }

        public static bool CheckIfCurveIsClosed(Part part, AnyObject curve)
        {
            // Returns true if given curve is closed. Otherwise, returns false.
            try
            {
                // Get the hybrid shape factory
                HybridShapeFactory hsf = (HybridShapeFactory)part.HybridShapeFactory;

                // Create a reference from the curve
                Reference referenceCurve = part.CreateReferenceFromObject(curve);

                // Create a new fill and add the curve as a bound
                HybridShapeFill fill = hsf.AddNewFill();
                fill.AddBound(referenceCurve);

                // Update the part with the fill operation
                part.UpdateObject(fill);

                // If the code reaches this point, the curve is closed
                return true;
            }
            catch (Exception)
            {
                Log.Information($"Edge Distance Check: one of the curve is not closed");
                return false;
            }
        }

        #endregion


    }
}
