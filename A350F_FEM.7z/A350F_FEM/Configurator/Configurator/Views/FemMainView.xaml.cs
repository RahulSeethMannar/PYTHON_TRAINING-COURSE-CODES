﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Path = System.IO.Path;
using log4net;
using MECMOD;
using System.Runtime.InteropServices;
using Configurator.Commands;

namespace Configurator.Views
{
    /// <summary>
    /// Interaction logic for FemMainView.xaml
    /// </summary>
    public partial class FemMainView : UserControl
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        internal static INFITF.Application CATIA = null;
        


        public FemMainView()
        {
            InitializeComponent();

            CatiaStart catia = new CatiaStart();

            CATIA = CatiaStart.CATIA;


        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            bool isOperationSuccess = false;

            // Check Command.TCL file
            try
            {
                string documentsDir = "c:\\Users\\" + Environment.UserName + "\\Documents";
                string tckFileToCheck1 = documentsDir + "\\command.tcl";
                string tckFileToCheck2 = documentsDir + "\\command1.tcl";
                string tckFileToCheck3 = documentsDir + "\\command2.tcl";

                if (File.Exists(tckFileToCheck1) || File.Exists(tckFileToCheck2) || File.Exists(tckFileToCheck3))
                {
                    ILog logger = LogManager.GetLogger("SampleAppender");
                    log4net.GlobalContext.Properties["LogFileName"] = (documentsDir + "\\Log_Hypermesh_Config.txt");
                    log4net.Config.XmlConfigurator.Configure();

                    log.Info("Log Successfully created");

                    log.Info("SUCCESS : Required command.tcl file exits");

                    // Check and Create Deploy folder
                    log.Info("Check and create Deploy directory");
                    string deployDirPath = documentsDir + "\\Deploy";

                    bool exists = System.IO.Directory.Exists(deployDirPath);
                    if (!exists)
                    {
                        System.IO.Directory.CreateDirectory(deployDirPath);
                    }

                    // Check and Create script file
                    log.Info("Check MeshDialogUi file in the application directory");
                    string strExeFilePath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                    string strDebugPath = System.IO.Path.GetDirectoryName(strExeFilePath);
                    string strWorkPath = System.IO.Path.Combine(strDebugPath, "Resources");
                    string[] inputFiles = System.IO.Directory.GetFiles(strWorkPath);


                    int nbIpFiles = inputFiles.Length, nbTCLFiles = 0;

                    string fileToCopy1 = "";
                    string shearPlateUIFile = "", meshUIFile = "", shearStressCalculationFile = "", viewCreation = "", rollerFile = "", cargoRailFile = "", femAutomationFile = "", GuiUtilitiesFile = "", Property_UpdateFile = "";

                    bool isInputFile2Found = false;
                    string fileToCopy2 = "";
                    if (nbIpFiles > 0)
                    {
                        for (int idx = 0; idx < nbIpFiles; idx++)
                        {
                            fileToCopy1 = inputFiles[idx];
                            string strpropertyUpdateFile = Path.GetFileName(fileToCopy1);
                            if (strpropertyUpdateFile == "Preference_post_tbc.mvw" || fileToCopy1.Contains(".tbc") || strpropertyUpdateFile == "Property_Update.exe" || strpropertyUpdateFile == "A350F_CB_Template_v01.xlsx" || strpropertyUpdateFile == "SR_Template_Creation.exe"/* || strpropertyUpdateFile == "MeshDialogCrossbeam.tcl"*/)
                            {
                                string tclScriptFile = GetTargetFileToCopy(fileToCopy1, deployDirPath, ".0.tcl");

                                log.Info("Copy " + fileToCopy1 + " to " + tclScriptFile);

                                File.Copy(fileToCopy1, tclScriptFile);

                                if (Path.GetFileName(fileToCopy1) == "MeshDialogUi_ShearPlate.tbc")
                                {
                                    shearPlateUIFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "MeshDialogCrossbeam.tbc")
                                {
                                    meshUIFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "ShearStressCalculation.tbc")
                                {
                                    shearStressCalculationFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "ViewCreation.tbc")
                                {
                                    viewCreation = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "MeshDialogUi_CargoRail.tbc")
                                {
                                    cargoRailFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "MeshDialogUi_Roller.tbc")
                                {
                                    rollerFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "FEM_Automation_tbc.tbc")
                                {
                                    femAutomationFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "GuiUtilities.tbc")
                                {
                                    GuiUtilitiesFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "Property_Update.exe")
                                {
                                    Property_UpdateFile = tclScriptFile;
                                    nbTCLFiles++;
                                }

                                //else if (Path.GetFileName(fileToCopy1) == "Preference_tbc.mvw")
                                //{
                                //    GuiUtilitiesFile = tclScriptFile;
                                //    nbTCLFiles++;
                                //}
                                else if (Path.GetFileName(fileToCopy1) == "Preference_post_tbc.mvw")
                                {
                                    GuiUtilitiesFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "CB_Post_Processing.tbc")
                                {
                                    Property_UpdateFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "CR_Post_Processing.tbc")
                                {
                                    Property_UpdateFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "SP_Post_Processing.tbc")
                                {
                                    Property_UpdateFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "tbcmain.tbc")
                                {
                                    Property_UpdateFile = tclScriptFile;
                                    nbTCLFiles++;
                                }
                                else if (Path.GetFileName(fileToCopy1) == "RT_Post_Processing.tbc")
                                {
                                    Property_UpdateFile = tclScriptFile;
                                    nbTCLFiles++;
                                }


                            }
                        }
                    }

                    if (nbIpFiles > 0)
                    {
                        for (int idx = 0; idx < nbIpFiles; idx++)
                        {
                            fileToCopy2 = inputFiles[idx];
                            if (fileToCopy2.Contains(".mvw"))
                            {
                                isInputFile2Found = true;
                                break;
                            }
                        }
                    }

                    if (0 < nbTCLFiles && isInputFile2Found)
                    {
                        //string prefWMVFile = GetTargetFileToCopy(fileToCopy2, deployDirPath, ".0.mvw");

                        //log.Info("Copy " + fileToCopy2 + " to " + prefWMVFile);

                        //File.Copy(fileToCopy2, prefWMVFile);

                        //// Update file names in Preference file
                        //UpdatePreferenceFile(prefWMVFile, viewCreation, shearStressCalculationFile);

                        // prepare userpage.mac
                        try
                        {
                            log.Info("Create userPageFile.mac file");

                            string userPageFile = documentsDir + "\\userpage.mac";

                            if (File.Exists(userPageFile))
                            {
                                log.Info(userPageFile + " : file already exists. Delete existing file");
                                File.Delete(userPageFile);
                            }

                            //string line5 = "\"Create the Midsurface Mesh\",\"EvalTcl\"," + "\"" + shearPlateUIFile + "\"" + ")";
                            //string line8 = "\"Create the Midsurface Mesh\",\"EvalTcl\"," + "\"" + meshUIFile + "\"" + ")";
                            //string line10 = "\"Create the Midsurface Mesh\",\"EvalTcl\"," + "\"" + cargoRailFile + "\"" + ")";
                            //string line12 = "\"Create the Midsurface Mesh\",\"EvalTcl\"," + "\"" + rollerFile + "\"" + ")";
                            string[] lines = { "*createbuttongroup(0, 0, \"FEM Automation\", 4, 5, 5, BUTTON,\"FEM Automation.\",\"EvalTcl\"," + "\"" + femAutomationFile + "\"" + ")" };

                            File.WriteAllLines(userPageFile, lines);
                            log.Info("SUCCESS : userPageFile.mac file created in : " + documentsDir);
                            isOperationSuccess = true;
                            log.Info("Operation successful");
                        }
                        catch
                        {
                            log.Error("Error in creating userPageFile.mac ");
                        }
                    }
                    else
                    {
                        log.Error("One or more .tcl files missing in the input directory : " + strWorkPath);
                    }
                }
                else
                {
                    log.Error("command.tcl file is not found");
                }
            }
            catch
            {
                log.Error("Error in finishing the configuration");
            }

            if (isOperationSuccess)
            {
                MessageBox.Show("Operation Successful. The tool is deployed in the utility tab");
            }
            else
            {
                log.Error("Error in finishing the configuration");
                MessageBox.Show("Operation failed, check log for more details");
            }

            // Console app
            // System.Environment.Exit(1);
        }

        private void Window_Closed(object sender, System.EventArgs e)
        {
            //parentWindow.Visibility = Visibility.Visible;
        }

        void CheckFileAndRename(ref string iFileToCheck, string[] iListFiles, ref int fileVersion, string iExtension)
        {
            if (iListFiles.Contains(iFileToCheck))
            {
                string extensionStr = fileVersion.ToString() + iExtension;

                // increase the counter
                log.Info(Path.GetFileName(iFileToCheck) + " file already exists. creating a new version");
                fileVersion++;
                iFileToCheck = iFileToCheck.Replace(extensionStr, "") + fileVersion.ToString() + iExtension;

                CheckFileAndRename(ref iFileToCheck, iListFiles, ref fileVersion, iExtension);
            }
        }

        string GetTargetFileToCopy(string fileToCopy, string deployDirPath, string iExtension)
        {
            string targetFileName = Path.GetFileName(fileToCopy);

            log.Info("SUCCESS : " + targetFileName + " file found in input directory : " + fileToCopy);

            int fileVersion = 1;
            string tclScriptFile = "";
            string[] files = System.IO.Directory.GetFiles(deployDirPath);

            bool isCreateNewVersion = false;
            int nbFiles = files.Length;
            if (nbFiles > 0)
            {
                string currentFile = "";
                for (int fileIdx = 0; fileIdx < nbFiles; fileIdx++)
                {
                    currentFile = files[fileIdx];

                    if (currentFile.Contains(targetFileName))
                    {
                        File.Delete(currentFile);
                        string extensionStr = fileVersion.ToString() + iExtension;
                        if (currentFile.Contains(extensionStr))
                        {
                            currentFile = currentFile.Replace(extensionStr, "") + fileVersion.ToString() + iExtension;
                        }
                        else
                        {
                            currentFile = currentFile.Replace(".tcl", "") + fileVersion.ToString() + iExtension;
                        }

                        CheckFileAndRename(ref currentFile, files, ref fileVersion, iExtension);
                        // *** to replace the version
                        // isCreateNewVersion = true;
                        break;
                    }
                }
                tclScriptFile = currentFile;
            }

            if (false == isCreateNewVersion)
            {
                tclScriptFile = deployDirPath + "\\" + targetFileName;
            }

            return tclScriptFile;
        }

        private void UpdatePreferenceFile(string prefWMVFile, string viewCreationFile, string shearStressCalculationFile)
        {
            string[] lines = System.IO.File.ReadAllLines(prefWMVFile);
            int lineCount = 0;
            foreach (string line in lines)
            {
                if (line.Contains("ViewCreationFile"))
                {
                    string newLine1 = line.Replace("ViewCreationFile", viewCreationFile.Replace("\\", "/"));
                    lines[lineCount] = newLine1;
                }
                if (line.Contains("ShearStressCalculationFile"))
                {
                    string newLine2 = line.Replace("ShearStressCalculationFile", shearStressCalculationFile.Replace("\\", "/"));
                    lines[lineCount] = newLine2;
                }

                lineCount++;
            }

            File.Delete(prefWMVFile);
            File.WriteAllLines(prefWMVFile, lines);
        }
       
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {      

                INFITF.Selection objSelEdgefillet = CATIA.ActiveDocument.Selection;

                PartDocument partDoc = (PartDocument)CATIA.Application.ActiveDocument;

                objSelEdgefillet.Search("Name=*EDGE*FILLET*,all");

                if (objSelEdgefillet.Count > 0)
                {
                    MessageBoxResult boxResult = MessageBox.Show("Total number of egde fillets found : " + objSelEdgefillet.Count.ToString() + "\n\nDo you want to continue the clean up operation?", "Stress - Clean Up Tool", MessageBoxButton.OKCancel);

                    if (boxResult == MessageBoxResult.OK)
                    {
                        objSelEdgefillet.Delete();
                        MessageBox.Show("Clean up process completed successfully.", "Stress - Clean Up Tool");
                    }
                }
                else
                {
                    MessageBox.Show("No edge fillets found to clean up.", "Stress - Clean Up Tool");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Clean up process failed...!", "Stress - Clean Up Tool");
            }
        }
    }
}
