﻿using System;

namespace A350F_CommonLibs.Stores
{
    public class NotificationStoreBase
    {
        private int _progressValue;
        private string _footerInfo;

        public event Action CurrentProgressChanged;
        public event Action CurrentFooterInfoChanged;

        /// <summary>
        /// Control the progressbar value 
        /// </summary>
        public int ProgressValue
        {
            get
            {
                return _progressValue;
            }
            set
            {
                _progressValue = value;
                OnCurrentProgressChanged();
            }
        }

        /// <summary>
        /// Control the footer information
        /// </summary>
        public string FooterInfo
        {
            get
            {
                return _footerInfo;
            }
            set
            {
                _footerInfo = value;
                OnCurrentFooterInfoChanged();
            }
        }

        private void OnCurrentProgressChanged()
        {
            CurrentProgressChanged?.Invoke();
        }

        private void OnCurrentFooterInfoChanged()
        {
            CurrentFooterInfoChanged?.Invoke();
        }
    }
}
