﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using INFITF;

using ProductStructureTypeLib;

using SPATypeLib;

namespace A350F_CommonLibs.CatiaUtils
{
    public static class CatiaProdUtils
    {
        public static ProductDocument AddNewProduct(string productPartNumber = "", bool openNewWindow = false)
        {
            ProductDocument productDoc = null;
            ProductDocument rootDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            Product rootProd = CatiaCommonUtils.GetActiveRootProd();
            Product newProduct = null;

            if (rootProd != null && rootDoc != null)
            {
                try
                {
                    newProduct = rootProd.Products.AddNewComponent("Product", productPartNumber);
                }
                catch (Exception)
                {
                    newProduct = rootProd.Products.AddNewComponent("Product", "");
                }

                if (openNewWindow)
                {
                    Selection selection = rootDoc.Selection;
                    selection.Clear();
                    selection.Add(newProduct);
                    CatiaCommonUtils.GetCatia().StartCommand("Open in New Window");
                    selection.Delete();
                    selection.Clear();
                    productDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
                }
                else
                {
                    productDoc = (ProductDocument)newProduct.ReferenceProduct.Parent;
                }
            }
            return productDoc;
        }

        /*public static void SelectAndReframeWithPartNumber(string partNumber)
        {
            INFITF.Application catiaInst = CatiaCommonUtils.GetCatia();
            if(null != catiaInst && null != catiaInst.ActiveDocument)
            {
                Selection mySelection = catiaInst.ActiveDocument.Selection;
                mySelection.Clear();
                Product foundProd = FindFirstProductInActiveDocument(partNumber);

                if (null != foundProd)
                {
                    mySelection.Add(foundProd);
                }
                catiaInst.StartCommand("Reframe On");
                catiaInst.StartCommand("Center graph");
            }
        }*/

        /// <summary>
        /// Recursive method to calcualte transformation matrix for the input product regarding the 
        /// root product.
        /// </summary>
        /// <param name="prod">In: The current product</param>
        /// <param name="rootProd">In: The root product for Trafo calculation</param>
        /// <param name="absoluteTrafo">Out: The calculated absoulte Transformation matrix</param>
        /// <param name="path">Out: The calculation path in string format form input product to the root product</param>
        public static void GetAbsTrafo(Product prod, Product rootProd, ref double[] absoluteTrafo, ref string path, bool untilCi = false)
        {

            path = prod.get_Name() + "/" + path;

            if (prod.get_Name().Equals(rootProd.get_Name()) || untilCi && prod.get_Nomenclature().Equals("ADAP-CI"))
            {
                absoluteTrafo = new double[12] { 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0 };
            }
            else
            {
                Console.WriteLine(prod.get_Name());

                // From Catia, we will get trafo with length 12, the last row 0 0 0 1 is excluded
                object[] localTrafoObjArray = new object[12];
                List<double> localTrafoList = new List<double>();

                prod.Position.GetComponents(localTrafoObjArray);
                foreach (object pos in localTrafoObjArray)
                {
                    localTrafoList.Add((double)pos);
                }

                double[] relativeTrafo = localTrafoList.GetRange(0, 12).ToArray();

                // Parent instance
                double[] parentTrafo = new double[12];
                Product parentProd = (Product)prod.Parent;
                if (null != parentProd)
                {
                    GetAbsTrafo(parentProd, rootProd, ref parentTrafo, ref path, untilCi);
                }

                CatiaMathUtils.TrafoMatrixProduct(parentTrafo, relativeTrafo, ref absoluteTrafo);
            }
        }

        /// <summary>
        /// Recursive method to find all instances of product with given part number
        /// </summary>
        /// <param name="partNumber">in: The part number of the instances to be found</param>
        /// <param name="parent">in: Set null as init value, parameter for recursive call</param>
        /// <param name="path">in: Set empty as init value, parameter for recursive call</param>
        /// <param name="instList">out: result instance list. Can't input with null value</param>
        /// <param name="pathList">out: result path list, one to one relationship to instList. Can't input with null value</param>
        public static void FindAllInstances(string partNumber, Product parent, string path,
            ref List<Product> instList, ref List<string> pathList, bool changeMode = true, bool preCheck = false)
        {
            if (instList is null || pathList is null)
            {
                return;
            }

            if (parent is null)
            {
                if (preCheck)
                {
                    parent = CatiaCommonUtils.GetActiveRootProd(changeMode, partNumber);
                }
                else
                {
                    parent = CatiaCommonUtils.GetActiveRootProd(changeMode);
                }

                if (parent is null)
                {
                    return;
                }
                path = parent.get_Name();
            }
            else
            {
                path += "/" + parent.get_Name();
            }

            foreach (Product childProd in parent.Products)
            {
                if (childProd is null) continue;

                if (childProd.get_Name().ToLower().Contains(partNumber.ToLower()))
                {
                    instList.Add(childProd);
                    pathList.Add(path + "/" + childProd.get_Name());
                }
                else
                {
                    FindAllInstances(partNumber, childProd, path, ref instList, ref pathList);
                }
            }
        }
        public static Product FindFirstInActiveDocumentWithPartNumber(string partNumber)
        {
            Product foundProd = null;

            // Get root product and load all child document, otherwise 
            // we will get exception during get_partnumber()
            Product rootProd = CatiaCommonUtils.GetActiveRootProd(true);

            if (null != rootProd)
            {
                foundProd = RecursiveFindProd(partNumber, rootProd, true);
                if (null != foundProd)
                {
                    return foundProd;
                }
            }
            return foundProd;
        }

        public static Product GetParentProduct(Product product)
        {
            if (product.Parent is Product)
            {
                return (Product)product.Parent;
            }
            else if (product.Parent is Products)
            {
                Products parentProduct = (Products)product.Parent;

                if (parentProduct.Parent is Product)
                {
                    return (Product)parentProduct.Parent;
                }
                
            }

            return null;
        }

        public static List<Product> GetAllChildNodesExcludeFilters(Product product, List<string> filterList)
        {
            List<Product> childNodes = new List<Product>();

            if (product is null)
            {
                return childNodes;
            }

            foreach (Product childProd in product.Products)
            {
                if (childProd is null)
                {
                    continue;
                }

                string partNumber = childProd.get_PartNumber();
                if (!filterList.Contains(partNumber.ToLower(), StringComparer.OrdinalIgnoreCase))
                {
                    childNodes.Add(childProd);
                }

                childNodes.AddRange(GetAllChildNodesExcludeFilters(childProd, filterList));
            }

            return childNodes;
        }

        public static Product FindFirstProductInActiveDocument(string partNumber)
        {
            Product foundProd = null;

            // Get root product and load all child document, otherwise 
            // we will get exception during get_partnumber()
            Product rootProd = CatiaCommonUtils.GetActiveRootProd(true);

            if (null != rootProd)
            {
                foundProd = RecursiveFindProd(partNumber, rootProd);
                if (null != foundProd)
                {
                    return foundProd;
                }
            }
            return foundProd;
        }

        private static Product RecursiveFindProd(string partNumber, Product parentProd, bool usePartNumber = false)
        {
            foreach (Product childProd in parentProd.Products)
            {
                if (childProd is null)
                {
                    continue;
                }

                Product foundProd = null;
                foundProd = FindProductWithPartNumberOrInstanceName(partNumber, usePartNumber, childProd);

                if (foundProd is null)
                {
                    foundProd = RecursiveFindProd(partNumber, childProd, usePartNumber);
                }

                if (null != foundProd)
                {
                    return foundProd;
                }
            }
            return null;
        }

        private static Product FindProductWithPartNumberOrInstanceName(string partNumber, bool usePartNumber, Product childProd)
        {
            if (!usePartNumber)
            {
                if (childProd.get_Name().Contains(partNumber))
                {
                    return childProd;
                }
            }
            else
            {
                // user part number to find the product, for unloaded products, we may get exception
                try
                {
                    if (childProd.get_PartNumber().Equals(partNumber))
                    {
                        return childProd;
                    }
                }
                catch
                {
                }
            }

            return null;
        }

        public static Product RecursiveFindInst(string name, Product parentProd)
        {
            foreach (Product childProd in parentProd.Products)
            {
                if (null == childProd) continue;

                if (childProd.get_Name().ToLower().StartsWith(name.ToLower()))
                {
                    return childProd;
                }

                Product foundProd = RecursiveFindInst(name, childProd);
                if (null != foundProd)
                {
                    return foundProd;
                }
            }
            return null;
        }

        //Active Main Product
        public static void ActiveMainProduct()
        {
            INFITF.Application catiaInst = CatiaCommonUtils.GetCatia();
            if (null != catiaInst)
            {
                catiaInst.ActiveDocument.Selection.Clear();
                ProductDocument activeDoc = (ProductDocument)catiaInst.ActiveDocument;
                Product prod = activeDoc.Product;
                catiaInst.ActiveDocument.Selection.Add(prod);
                catiaInst.StartCommand("FrmActivate");
                catiaInst.ActiveDocument.Selection.Clear();
            }
        }

        public static IList<Product> GetFathers(Product product)
        {
            IList<Product> fathers = new List<Product>();
            if (product is null || product.Parent is null)
            {
                return fathers;
            }

            Queue<Product> queue = new Queue<Product>();
            queue.Enqueue(product);

            while (queue.Count > 0)
            {
                Product currentProduct = queue.Dequeue();
                //TracesSrv.writeDebug($"Searching parent for:{currentProduct.get_Name()}");
                if (currentProduct.Parent is Products)
                {
                    Products products = currentProduct.Parent as Products;
                    if (products.Parent is Product)
                    {
                        currentProduct = products.Parent as Product;
                        queue.Enqueue(currentProduct);
                        fathers.Add(currentProduct);
                    }
                }
                else if (currentProduct.Parent is Product)
                {
                    Product parentProduct = currentProduct.Parent as Product;
                    if (parentProduct.GetHashCode() != currentProduct.GetHashCode())
                    {
                        queue.Enqueue(parentProduct);
                        fathers.Add(parentProduct);
                    }
                }
            }
            return fathers;
        }

        public static double[] GetProductCogPosition(string partNumber)
        {
            double[] cog = { 0, 0, 0 };

            if (!String.IsNullOrWhiteSpace(partNumber))
            {
                Product prod = FindFirstProductInActiveDocument(partNumber);
                cog = GetProductCogPosition(prod);
            }

            return cog;
        }

        internal static double[] GetProductCogPosition(Product prod)
        {
            double[] cog = { 0, 0, 0 };

            if (prod != null)
            {
                // Catia get cog with smaller scale, we need to multiple with 1000 to 
                // get the same scale in mm as the center position for cylinder edges.
                // Here we get absolut position, no transform is needed.
                Inertia inertia = (Inertia)prod.GetTechnologicalObject("Inertia");
                object[] myCoord = new object[3];
                inertia.GetCOGPosition(myCoord);
                cog[0] = (Double)myCoord[0] * 1000;
                cog[1] = (Double)myCoord[1] * 1000;
                cog[2] = (Double)myCoord[2] * 1000;
            }

            return cog;
        }
    }
}
