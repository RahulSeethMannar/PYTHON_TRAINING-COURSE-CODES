﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using A350F_CommonLibs.Commands;

using Configurator.Stores;

namespace Configurator.Commands
{
    class FemNavigateLoginCommand : CommandBase
    {
        private FemNavigationStore _navigationStore;

        public FemNavigateLoginCommand(FemNavigationStore navigationStore)
        {
            _navigationStore = navigationStore;
        }

        public override void Execute(object parameter)
        {
            _navigationStore.OnReturnToMainViewChanges();
        }

    }
}
