﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Configurator.Models
{
    public class Table
    {
        public string Name { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        public bool Visible { get; set; }
        public string Content { get; set; }

    }
}
