﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Dapper;

namespace A350F_CommonLibs.Services.InputProviders.Dapper
{
    public static class TypeMapper
    {

        public static void Initialize(string @namespace)
        {
            var types = from assem in AppDomain.CurrentDomain.GetAssemblies().ToList()
                        from type in assem.GetTypes()
                        where type.IsClass && type.Namespace == @namespace
                        select type;

            types.ToList().ForEach(type =>
            {
                if (SqlMapper.GetTypeMap(type) is DefaultTypeMap)
                {
                    var mapper = (SqlMapper.ITypeMap)Activator
                        .CreateInstance(typeof(ColumnAttributeTypeMapper<>)
                                        .MakeGenericType(type));
                    SqlMapper.SetTypeMap(type, mapper);
                }

            });
        }
    }
}
