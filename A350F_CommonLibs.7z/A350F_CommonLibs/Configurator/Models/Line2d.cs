﻿using MECMOD;
using System.Linq;

namespace A350F_CommonLibs.Configurator.Models
{
    public class Line2d
    {
        public Line2D ActualLine { get; internal set; } = null;
        public double X { get; internal set; } = 0;
        public double Y { get; internal set; } = 0;
        public Point2d StartPoint2D { get; internal set; } = null;
        public Point2d EndPoint2D { get; internal set; } = null;
        public Point2d MidPoint2D { get; internal set; } = null;


        public Line2d(Line2D line2D)
        {
            ActualLine = line2D;
            CollectLineInfo(line2D);
        }

        private void CollectLineInfo(Line2D line2D)
        {
            double[] midpoint = new double[2];
            object[] arrPtCoordinates = new object[2];
            double[] arrPtCoordinatesStart = null, arrPtCoordinatesEnd = null;
            line2D.StartPoint.GetCoordinates(arrPtCoordinates); arrPtCoordinatesStart = arrPtCoordinates.Cast<double>().ToArray();
            line2D.EndPoint.GetCoordinates(arrPtCoordinates); arrPtCoordinatesEnd = arrPtCoordinates.Cast<double>().ToArray();
            for (int idx = 0; idx < midpoint.Length; idx++) midpoint[idx] = (arrPtCoordinatesStart[idx] + arrPtCoordinatesEnd[idx]) / 2;

            StartPoint2D = new Point2d(line2D.StartPoint);
            EndPoint2D = new Point2d(line2D.EndPoint);
            MidPoint2D = new Point2d(midpoint);
        }

        public bool IsHorizontal()
        {
            if (ActualLine is null) return false;
            return StartPoint2D.Y == EndPoint2D.Y;
        }

        public bool IsVertical()
        {
            if (ActualLine is null) return false;
            return StartPoint2D.X == EndPoint2D.X;
        }
    }
}
