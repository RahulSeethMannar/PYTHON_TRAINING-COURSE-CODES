﻿
namespace A350F_CommonLibs.Configurator.Constants
{
    public static class DrawingTypes
    {
        public const string UnIdentified = "UnIdentified";
        public const string NotDefined = "Not Defined";
        public const string SinglePart = "Single Part";
        public const string Assembly = "Assembly";
        public const string DesignSolution = "Design Solution";
        public const string Installation = "Installation";
    }

    public static class DrawingTypesAbbreviation
    {
        public const string SinglePart = "SP";
        public const string Assembly = "ASSY";
        public const string DesignSolution = "DS";
        public const string DS = "DS";
        public const string DT = "DT";
        public const string Part = "Part";
        public const string Installation = "INST";
        public const string NotDefined = "Not Defined";
    }

    public static class Nomenclatures
    {
        public const string SinglePart = "ADAP-PART";
        public const string Assembly = "ADAP-ASSY";
        public const string DesignSolution = "ADAP-DS";
        public const string NotDefined = "Not Defined";
    }
}
