﻿using A350F_CommonLibs.Configurator.Models;
using A350F_CommonLibs.Configurator.Constants;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Newtonsoft.Json;
using System.Linq;

namespace A350F_CommonLibs.Configurator.Models
{
    public class TemplateDetails
    {
        public string FileVersion { get; set; } = UI_Inputs.JsonFileVersion;
        public bool UpdateSelected { get; set; } = false;
        public bool CreateSelected { get; set; } = false;
        public ProjectDetail ProjectDetail { get; set; } = new ProjectDetail();
        public TitleBlockDetail TitleblockDetails { get; set; } = new TitleBlockDetail();
        public ViewItem TreeviewDetail { get; set; } = new ViewItem() { };
        public List<object> ListDrawingsCreated { get; set; } = new List<object>();

        #region Constructor
        public TemplateDetails()
        {
            ProjectDetail.SheetNumber = ProjectDetail.SheetCount = "01";
        }
        #endregion

        #region GetAllViews
        public ObservableCollection<ViewItem> GetAllViews()
        {
            if (this.TreeviewDetail is null) return null;
            ObservableCollection<ViewItem> recordedViews = null;

            if (this.TreeviewDetail.ViewItems is null)
            {
                this.TreeviewDetail.ItemName = TreeIDs.TreeViewRootElementName;
                this.TreeviewDetail.ItemType = TreeIDs.TreeViewRootElementType;
                if (this.TreeviewDetail.ViewItems is null)
                    this.TreeviewDetail.ViewItems = new ObservableCollection<ViewItem>();
                this.TreeviewDetail.ViewItems.Add(new ViewItem(name: IDs.Sheet + " 01",
                                                       sheetSize: UI_Inputs.DefaultSheetSize,
                                                       itemType: IDs.Sheet,
                                                       DeleteButtonIsVisible: 0));
            }

            try
            {
                List<ViewItem> viewDetails = new List<ViewItem>();
                foreach (ViewItem st in this.TreeviewDetail.ViewItems)
                    viewDetails.AddRange(st.ViewItems);
                recordedViews = new ObservableCollection<ViewItem>(viewDetails);
            }
            catch (Exception ex) { }
            return recordedViews;
        }
        #endregion

        #region GetAllViews
        public ObservableCollection<ViewItem> GetAllViews(ViewItem viewItem)
        {
            if (viewItem is null) return null;
            ObservableCollection<ViewItem> recordedViews = null;

            if (viewItem.ViewItems is null)
            {
                viewItem.ItemName = TreeIDs.TreeViewRootElementName;
                viewItem.ItemType = TreeIDs.TreeViewRootElementType;
                if (viewItem.ViewItems is null)
                    viewItem.ViewItems = new ObservableCollection<ViewItem>();
                viewItem.ViewItems.Add(new ViewItem(name: IDs.Sheet + " 01",
                                                       sheetSize: UI_Inputs.DefaultSheetSize,
                                                       itemType: IDs.Sheet,
                                                       DeleteButtonIsVisible: 0));
            }

            try
            {
                List<ViewItem> viewDetails = new List<ViewItem>();
                foreach (ViewItem st in viewItem.ViewItems)
                    CollectAllViewsFrom(st, ref viewDetails);
                viewDetails = viewDetails.Distinct().ToList();
                recordedViews = new ObservableCollection<ViewItem>(viewDetails);
            }
            catch (Exception ex) { }
            return recordedViews;
        }

        private void CollectAllViewsFrom(ViewItem viewItem, ref List<ViewItem> listViewItems)
        {
            if (viewItem is null) return;
            foreach (ViewItem st in viewItem.ViewItems)
            {
                if ((viewItem.IsPrimaryView() && !viewItem.IsBackgroundView()) || viewItem.IsSecondaryView())
                    listViewItems.Add(viewItem);
                CollectAllViewsFrom(st, ref listViewItems);
            }
        }

        #endregion

        #region GetClone
        public TemplateDetails GetClone()
        {
            return Clone();
        }
        #endregion

        #region Clone
        public TemplateDetails Clone()
        {
            TemplateDetails clone = null;

            try
            {
                string allLines = JsonConvert.SerializeObject(this, Formatting.Indented);
                clone = JsonConvert.DeserializeObject<TemplateDetails>(allLines);
            }
            catch (Exception ex) { clone = null; }

            if (clone is null)
            {
                clone = new TemplateDetails();
                List<ViewItem> viewItems = new List<ViewItem>() { this.TreeviewDetail };
                clone.CreateSelected = this.CreateSelected;
                clone.UpdateSelected = this.UpdateSelected;
                clone.ProjectDetail = this.ProjectDetail.Clone();
                clone.TitleblockDetails = this.TitleblockDetails.Clone();
                clone.TreeviewDetail = viewItems[0];
            }

            clone.ListDrawingsCreated = new List<object>(this.ListDrawingsCreated);

            return clone;
        }
        #endregion

    }
}
