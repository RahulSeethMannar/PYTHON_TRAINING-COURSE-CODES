﻿using System.Collections.Generic;

namespace A350F_CommonLibs.Services.Results
{
    public class UnexpectedResult<T> : ResultBase<T>
    {
        private List<string> _errors;

        public UnexpectedResult()
        {
            _errors = new List<string> { "There was an unexpected problem happend." };
        }

        public override ResultType ResultType => ResultType.Unexpected;

        public override List<string> Errors
        {
            get
            {
                return _errors;
            }
            set
            {
                _errors = value;
            }
        }

        public override T Data => default;
    }
}
