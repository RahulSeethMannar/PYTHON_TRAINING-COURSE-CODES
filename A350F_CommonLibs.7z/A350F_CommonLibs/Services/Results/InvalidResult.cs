﻿using System.Collections.Generic;

namespace A350F_CommonLibs.Services.Results
{
    public class InvalidResult<T> : ResultBase<T>
    {
        private readonly T _data;
        private List<string> _errors;

        public InvalidResult(T data, int internalErrorId = 0)
        {
            _internalErrorId = internalErrorId;
            _data = data;
            _errors = new List<string> { "Error happens during process." };
        }

        public InvalidResult()
        {
            _internalErrorId = 0;
            _data = default;
            _errors = new List<string> { "Error happens during process." };
        }

        public override ResultType ResultType => ResultType.Invalid;

        public override List<string> Errors
        {
            get
            {
                return _errors;
            }
            set
            {
                _errors = value;
            }
        }

        public override T Data => _data;
            
    }
}
