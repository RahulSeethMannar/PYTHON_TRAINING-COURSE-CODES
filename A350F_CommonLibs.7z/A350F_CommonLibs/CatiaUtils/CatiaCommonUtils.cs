﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

using INFITF;

using MECMOD;

using ProductStructureTypeLib;

using Serilog;

namespace A350F_CommonLibs.CatiaUtils
{
    public class CatiaCommonUtils
    {
        public static Boolean IsCatiaExists()
        {
            try
            {
                Application CatiaApp = (Application)Marshal.GetActiveObject("Catia.Application");
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static Application GetCatia()
        {
            try
            {
                Application CatiaApp = (Application)Marshal.GetActiveObject("Catia.Application");
                return CatiaApp;
            }
            catch
            {
                return null;
            }
        }

        public static string GetNameActiveDoc()
        {
            Application catiaInst = GetCatia();
            if (catiaInst != null)
            {
                if (catiaInst.Documents.Count > 0)
                {
                    return catiaInst.ActiveDocument.get_Name();
                }
                else
                {
                    return "No Document found in Catia";
                }
            }
            else
            {
                return "No running Catia found";
            }
        }

        public static bool CanGetActiveDoc()
        {
            return !(GetActiveDoc() is null);
        }

        public static Document GetActiveDoc()
        {
            Application catiaInst = GetCatia();
            if (catiaInst != null)
            {
                if (catiaInst.Documents.Count > 0)
                {
                    try
                    {
                        return catiaInst.ActiveDocument;
                    }
                    catch
                    {
                        return null;
                    }
                }
            }
            return null;
        }

        public static bool CanGetActiveRootProd(bool isLoadChildDocument = false)
        {
            return !(GetActiveRootProd(isLoadChildDocument) is null);
        }

        public static Product GetActiveRootProd(bool isLoadChildDocument = true, string childInstName = "")
        {
            Document activeDoc = GetActiveDoc();
            if (activeDoc is ProductDocument)
            {
                Product rootProd = (activeDoc as ProductDocument).Product;
                if (isLoadChildDocument)
                {
                    //rootProd.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                }
                return rootProd;
            }
            else
            {
                return GetActiveRootFromWindows(isLoadChildDocument, childInstName);
            }
        }

        private static Product GetActiveRootFromWindows(bool isLoadChildDocument, string childInstName)
        {
            Application catiaInst = GetCatia();
            Windows windows = catiaInst.Windows;

            if (windows.Count == 0 || String.IsNullOrEmpty(childInstName))
            {
                return null;
            }

            foreach (Window win in windows)
            {
                win.Activate();

                if (!(catiaInst.ActiveDocument is ProductDocument))
                {
                    continue;
                }

                Product rootProd = (catiaInst.ActiveDocument as ProductDocument).Product;
                if (CatiaProdUtils.RecursiveFindInst(childInstName, rootProd) is null)
                {
                    continue;
                }

                if (isLoadChildDocument)
                {
                    //rootProd.ApplyWorkMode(CatWorkModeType.DEFAULT_MODE);
                }
                return rootProd;
            }

            return null;
        }

        public static Selection GetSelection()
        {
            return GetActiveDoc()?.Selection;
        }

        public static bool CatiaPreChecks(ref string result)
        {
            if (!CatiaCommonUtils.IsCatiaExists())
            {
                result = $"3D Check Pre-Check Error: No running Catia found";
                return false;
            }

            if (!CatiaCommonUtils.CanGetActiveDoc())
            {
                result = $"3D Check Pre-Check Error: No Document found in Catia";
                return false;
            }

            if (!CatiaCommonUtils.CanGetActiveRootProd())
            {
                result = $"3D Check Pre-Check Error: No Root-Product found in Catia";
                return false;
            }

            Application catia = CatiaCommonUtils.GetCatia();
            String activeWorkbench = catia.GetWorkbenchId();
            if (activeWorkbench != "Assembly" && activeWorkbench != "DMUNavigator")
            {
                try
                {
                    catia.StartWorkbench("DMUNavigator");
                }
                catch
                {
                    try
                    {
                        catia.StartWorkbench("Assembly");
                    }
                    catch
                    {
                        result = $"Not able to change workbench to DMUNavigator or Assembly";
                        return false;
                    }
                }
            }
            return true;
        }

        public static void UpdateSearchOrder(string roaPathValue)
        {
            Application catiaInst = GetCatia();
            string searchOrder = catiaInst.get_FileSearchOrder();
            string[] pathList = roaPathValue.Split(';');
            foreach (string path in pathList)
            {
                if (!searchOrder.ToLower().Contains(path.ToLower()))
                {
                    searchOrder = $"{searchOrder};{path}";
                }
            }
            catiaInst.set_FileSearchOrder(searchOrder);
        }

        public static void GetPartDocumentFromProduct(Product inputProd, ref PartDocument outDoc)
        {
            if (inputProd != null)
            {
                try
                {
                    outDoc = (PartDocument)inputProd.ReferenceProduct.Parent;
                }
                catch (Exception e)
                {
                    Log.Warning($"Can't get PartDocument from Product {inputProd.get_Name()} - {e.ToString()}");
                }
            }
        }
    }
}
