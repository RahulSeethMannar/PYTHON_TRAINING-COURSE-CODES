﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Configurator.Constans
{
    public static class DraftingOptionsNames
    {
        public const string DrwPreventGVS = "DrwPreventGVS";//Changing View properties
        public const string GenAxisCreate = "GenAxisCreate"; //Axis
        public const string GenCenterCreate = "GenCenterCreate";//CenterLine
        public const string GenFilCreate = "GenFilCreate";//Fillets
        public const string Gen3DColors = "Gen3DColors"; //3D colors
        public const string GenWireFrame = "GenWireFrame"; //3D wireFrame
        public const string GenWireFrameMod = "GenWireFrameMod";
        public const string DrwProject3DPts = "DrwProject3DPts"; //3D Point
        public const string GenApplyUncut = "GenApplyUncut"; //3D Spec
        public const string GenThreadCreate = "GenThreadCreate";// Thread
        public const string GenHiddenLines = "GenHiddenLines"; //Hidden Lines 
        public const string DrwGenerationModeVal = "DrwGenerationModeVal";  //catExactMode
    }
}
