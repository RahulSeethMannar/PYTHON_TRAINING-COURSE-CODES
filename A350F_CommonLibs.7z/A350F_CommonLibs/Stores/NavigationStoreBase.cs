﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using A350F_CommonLibs.Models;
using A350F_CommonLibs.ViewModels;

namespace A350F_CommonLibs.Stores
{
    public class NavigationStoreBase
    {

        #region Private member variables
        private ViewModelBase _currentViewModel;
        #endregion

        #region Properties for MVVM bindings
        public event Action CurrentViewModelChanged;
        public event Action ReturnToMainViewChanged;
        public event Action NavigateToConfiguratorChanged;

        public void OnReturnToMainViewChanges()
        {
            ReturnToMainViewChanged?.Invoke();
        }

        public void OnNavigateToConfiguratorChanged()
        {
            NavigateToConfiguratorChanged?.Invoke();
        }

        public ViewModelBase CurrentViewModel
        {
            get => _currentViewModel;
            set
            {
                _currentViewModel = value;
                OnCurrentViewModelChanged();
            }
        }
        public ViewModelBase HomeViewModel { get; set; }
        public UserProfile UserProfile { get; set; }
        #endregion

        #region ReturnToMainViewChanged event registration and handling
        /// <summary>
        /// To be called during the initialization of the child view model.
        /// This will register on ReturnToMainViewChanged event on child ViewModel
        /// </summary>
        /// <param name="childMainViewModel">ViewModel class of child component</param>
        public void RegisterChildExitEvent(ViewModelBase childMainViewModel)
        {
            childMainViewModel.NavigationStore.ReturnToMainViewChanged += MainViewModel_returnToMainViewChanged;
        }



        /// <summary>
        /// Handler function to set view model back to loginViewModel and inform UI to refresh
        /// </summary>
        private void MainViewModel_returnToMainViewChanged()
        {
            _currentViewModel = HomeViewModel;
            OnCurrentViewModelChanged();
        }

        /// <summary>
        /// <c>OnCurrentDisplayTabChanged</c> send event to subscribed methods. <br />
        /// This is used to notify view model to refresh the tab UI when we change
        /// the value in navigation store.
        /// </summary>
        public void OnCurrentViewModelChanged()
        {
            CurrentViewModelChanged?.Invoke();
        }
        #endregion
    }
}
