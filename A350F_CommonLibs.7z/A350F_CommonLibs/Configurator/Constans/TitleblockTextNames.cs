﻿
namespace A350F_CommonLibs.Configurator.Constants
{
    public static class TitleblockTextNames
    {
        public const string CopyrightYear = "AUKTbkText_ENG_MAP_COPYRIGHT";
        public const string DrawingNumber = "AUKTbkText_ENG_ALL_DRAWINGNUMBER";
        public const string SheetNumber = "AUKTbkText_ENG_ALL_SHEET";
        public const string SheetSize = "AUKTbkText_ENG_ALL_SIZE";
        public const string SheetScale = "AUKTbkText_ENG_ALL_SCALE";
        public const string LimitsNotStated = "AUKTbkText_ENG_ALL_ABD0001_SUFFIX";
        public const string SurfaceFinish = "AUKTbkText_ENG_ALL_SURFACE_FINISH";
        public const string IdentificationMarking = "AUKTbkText_ENG_ALL_IDENTIFICATION";
        public const string IdentificationMarkingPref = "AUKTbkText_ENG_ALL_IDENTIFICATION_PREF";
        public const string DO_Origin = "AUKTbkText_ENG_ALL_DO_ORIGIN_SITE";
        public const string EngTitle = "AUKTbkText_ENG_ALL_TITLE";
        public const string LocalTitle = "AUKTbkText_ENG_ALL_LOCAL_TITLE";

    }
}