﻿namespace A350F_CommonLibs.Commands
{
    public class ExitProgramCommand : CommandBase
    {
        public ExitProgramCommand() { }

        public override void Execute(object parameter)
        {
            System.Windows.Application.Current.Shutdown();
        }

        public override bool CanExecute(object parameter)
        {
            return base.CanExecute(parameter);
        }
    }
}
