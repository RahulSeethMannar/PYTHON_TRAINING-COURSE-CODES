﻿using A350F_CommonLibs.Configurator.Constants;
using INFITF;
using MECMOD;
using ProductStructureTypeLib;
using System;

namespace A350F_CommonLibs.Configurator
{
    public class ProductDetail
    {
        public string FileName { get; set; }
        public string FileType { get; set; }
        public string PartNumber { get; set; }
        public string Definition { get; set; }
        public string Nomenclature { get; set; }

        private Product _product = null;
        private Document _document = null;

        public ProductDetail(Product product, INFITF.Window window)
        {
            this._product = product;
            if (product != null)
            {
                this._document = product.Parent as Document;
                string fileName = System.IO.Path.GetFileNameWithoutExtension(window?.get_Caption());
                string fileType = System.IO.Path.GetExtension(_document.FullName);
                fileType = fileType.StartsWith(".") ? fileType.Substring(1) : fileType;
                if (String.IsNullOrEmpty(fileType))
                {
                    if (_document is ProductDocument)
                        fileType = IDs.FileTypes.CATProduct;
                    if (_document is PartDocument)
                        fileType = IDs.FileTypes.CATPart;
                }
                this.FileName = fileName;
                this.FileType = fileType;
                this.PartNumber = product.get_PartNumber();
                this.Definition = product.get_Definition();
                this.Nomenclature = product.get_Nomenclature();
            }
        }

        public Document GetDocument()
        {
            return _document;
        }

        public Product GetProduct()
        {
            return _product;
        }

        public Product GetParentProduct()
        {
            return _product.Parent as Product;
        }

        public Product Get_Parents_Parent_Product()
        {
            return GetParentProduct().Parent as Product;
        }
    }
}