﻿using A350F_CommonLibs.Utils;
using DRAFTINGITF;

namespace A350F_CommonLibs.Configurator.Constants
{
    public class IDs
    {
        public static class FolderNames
        {
            public const string JsonConfigurationFolderName = "TemplateConfiguration2D";
            public const string DrawingTemplatesFolderName = "2D_DRW_Template";
        }

        public static class FolderPaths
        {
            public static string JsonConfiguration2D => System.IO.Path.Combine(CommonUtils.ToolLibFolder, IDs.FolderNames.JsonConfigurationFolderName);
            public static string DrawingTemplates => System.IO.Path.Combine(CommonUtils.ToolLibFolder, IDs.FolderNames.DrawingTemplatesFolderName);

        }

        public class CsvFilePaths
        {
            public static string BracketsData => GetFilePathFor(CsvFilesNames.BracketsData, FilesExtensions.Csv);
            public static string ZStrut_AssemblyList => GetFilePathFor(CsvFilesNames.ZStrut_AssemblyList, FilesExtensions.Csv);

            private static string GetFilePathFor(string fileName, string fileExtension)
            {
                fileExtension = fileExtension.StartsWith(".") ? "" : "." + fileExtension;
                string filePath = System.IO.Path.Combine(CommonUtils.ToolLibFolder, IDs.FolderNames.DrawingTemplatesFolderName, fileName, fileExtension);
                return filePath;
            }
        }

        public static class CsvFilesNames
        {
            public const string BracketsData = "BracketsData";
            public const string ZStrut_AssemblyList = "ZStrut_AssemblyList";
        }

        public static class FileTypes
        {
            public static readonly string Unknown = "Unknown";
            public static readonly string Json = "Json";
            public static readonly string Csv = "Csv";
            public static readonly string CATProduct = "CATProduct";
            public static readonly string CATPart = "CATPart";
            public static readonly string CATDrawing = "CATDrawing";
        }

        public static class FilesExtensions
        {
            public static readonly string Json = "." + FileTypes.Json;
            public static readonly string Csv = "." + FileTypes.Csv;
            public static readonly string CATProduct = "." + FileTypes.CATProduct;
            public static readonly string CATPart = "." + FileTypes.CATPart;
            public static readonly string CATDrawing = "." + FileTypes.CATDrawing;
        }

        public static class _2DComponentsNames
        {
            public const string AFL_Symbol = "AFL_Symbol";
            public const string PH = "P/H-";
            public const string StampLabel = "Stamp_Label";
            public const string Bonding = "Bonding";
            public const string BondingSymbol = "BondingSymbol";
            public const string Bonding_CPL = "Bonding_CPL";
            public const string BondingTable = "BondingTable";
            public const string Marking_Hidden = "Marking_Hidden";
            public const string Bonding_CPL_2 = "Bonding_CPL_CB";
            public const string Bonding_CPL_3 = "Bonding_CPL_Type1";
            public const string ViewFace = "ViewFace";

            public const string Grounding = "Bonding";
            public const string ICYPart = "ICYPart";
            public const string InterchangeabilityPart = "Interchangeability Part";
            public const string LabelMarking = "Label Marking";
            public const string LabelMarkingPart = "Label Marking Part";
            public const string DRILLING = "DRILLING";
            public const string Drilling = "Drilling";
            public const string STAMP = "STAMP";
            public const string PduStamp = "PDU Stamp";
            public const string MASKING = "_MASKING";
            public const string Fasteners = "Fasteners";
            public const string FastenerPlus = "FastenerPlus";
            public const string FastenerPlus_ = "FastenerPlus_";
            public const string FastenerPlusCounterSunk = "FastenerPlusCounterSunk";

            public const string EN = "EN";
            public const string NAS = "NAS";
            public const string DatumSymbolName = "0 Punkt";
            public const string Punkt = "Punkt";
            public const string Fixier = "Fixier";
            public const string Fixierpunkt = "Fixierpunkt";
            public const string Variante = "Variante";
        }

        public static class Abbreviations
        {
            public static readonly string FN = "FN";
            public static readonly string GN = "GN";
            public static readonly string Comp2D = "Comp2D";
        }
        public static class ContextMenus
        {
            public static readonly string View = "ContextMenuView";
            public static readonly string Sheet = "ContextMenuSheet";
            public static readonly string Feature = "ContextMenuFeature";
        }

        public static class SheetSizeNames
        {
            public const string A4 = "A4";
        }

        public static class Nodes
        {
            public static readonly string BFH = "BFH";
            public static readonly string GND = "GND";
            public static readonly string LTG = "LTG";
        }

        public static class FrameTypes
        {
            public static readonly int PartNumberCallout = 15;
            public static readonly int PartNumberCalloutOpp = 69;
        }

        public const string Underscore = "_";
        public const string Hiphon = "-";
        public const string Space = " ";
        public const string Colon = ":";
        public const string ForwardSlash = "/";

        public const string Accenture = "Accenture";
        public const string Empty = "Empty";
        public const string NotSpecified = "Not Specified";
        public const string NotToScale = "NOT TO SCALE";
        public const string AFL_Symbol = "AFL_Symbol";
        public const string PH = "P/H-";
        public const string StampLabel = "Stamp_Label";
        public const string Bonding = "Bonding";
        public const string Bonding_ASSY = "BONDING_ASSY";
        public const string Bonding_CPL = "Bonding_CPL";
        public const string BondingTable = "BondingTable";
        public const string Marking_Hidden = "Marking_Hidden";
        public const string Bonding_CPL_2 = "Bonding_CPL_CB";
        public const string Bonding_CPL_3 = "Bonding_CPL_Type1";
        public const string ViewFace = "ViewFace";
        public const string SUFFIX = "SUFFIX";
        public const string ASSY = "ASSY";
        public const string Grounding = "Bonding";
        public const string ICYPart = "ICYPart";
        public const string InterchangeabilityPart = "Interchangeability Part";
        public const string LabelMarking = "Label Marking";
        public const string LabelMarkingPart = "Label Marking Part";
        public const string DRILLING = "DRILLING";
        public const string Drilling = "Drilling";
        public const string STAMP = "STAMP";
        public const string PduStamp = "PDU Stamp";
        public const string MASKING = "_MASKING";
        public const string Fasteners = "Fasteners";
        public const string FastenerPlus = "FastenerPlus";
        public const string FastenerPlus_ = "FastenerPlus_";
        public const string FastenerPlusCounterSunk = "FastenerPlusCounterSunk";

        public const string Sheet = "Sheet";
        public const string Table = "Table";
        public const string SummarySheet = "Summary Sheet";
        public const string Features = "Features";
        public const string PrimaryViews = "PrimaryViews";
        public const string SecondaryViews = "SecondaryViews";

        public const string Issue = "ISSUE";
        public const string DefaultIssue = "A00";
        public const string DefaultVariantNumber = "000";
        public const string NA = "NA";
        public const string New = "New";
        public const string EN = "EN";
        public const string NAS = "NAS";
        public const string AutomaticNaming = "AutomaticNaming";
        public const string DatumSymbolName = "0 Punkt";
        public const string Punkt = "Punkt";
        public const string Fixier = "Fixier";
        public const string Fixierpunkt = "Fixierpunkt";
        public const string Variante = "Variante";
        public const string CbAssyText = "cbAssyText";
        public const string Number = "Number";
        public const string Points = "Points";
        public const string Text = "Text";

        public const string SA = "SA";
        public const string XWB = "XWB";

        public const string Json = "json";
        public const string ToolingHole = "ToolingHole-";
        public const string LightningHoles = "LightningHoles-";

        public const string Configurator2D = "Configurator2D";
        public const string JsonConfigurationFolderName = FolderNames.JsonConfigurationFolderName;
        public const string DrawingTemplatesFolderName = FolderNames.DrawingTemplatesFolderName;

        public const string Programs = "Programs";
        public const string Sections = "Sections";
        public const string ATAChapters = "ATAChapters";
        public const string DrawingTypes = "DrawingTypes";
        public const string PartFamilies = "PartFamilies";
        public const string SheetSizes = "SheetSizes";
        public const string DOs = "DOs";
        public const string Limits = "Limits";
        public const string Surfaces = "Surfaces";
        public const string IdentificationMarkingPrefs = "IdentificationMarkingPrefs";
        public const string IdentificationMarkingTextLocations = "IdentificationMarkingTextLocations";


        public const string TITLE = "TITLE";
        public const string SIZE = "SIZE";
        public const string HtzAssy = "htzAssy";

        public const string DraftingOptions = "DraftingOptions";

        public const string ThisSheetRefersTo = "THIS SHEET REFERS TO ";

        public const string DisassembledBondingGeoSetName = "DisassembledBondingSurfaces";

        public const string PartNumberCalloutTextPrefix = "PartNumberCallout";
        public const string PartNumberCalloutTextName = PartNumberCalloutTextPrefix + "_HTZ_Variant";
        public const string PartNumberCalloutTextNameOpp = PartNumberCalloutTextName + "_OH";


        public const int NumberOfDecimalsInViewScaleRaio = 5;
        public const double DefaultGapBetweenViewsForAutoPlacement = 5;
    }

    public class TreeIDs
    {
        public const string Root = "Drawing Sheets";
        public const string TreeViewRootElementName = Root;
        public const string TreeViewRootElementType = "TreeViewRootElement";
        public const string Sheet = "Sheet";
    }

    public class ViewShapes
    {
        public const string Profile = "Profile";
        public const string Circular = "Circular";
        public const string Exact = "Exact";
    }

    public class SectionViewProfileType
    {
        public const string Offset = "Offset";
        public const string Aligned = "Aligned";
    }

}
