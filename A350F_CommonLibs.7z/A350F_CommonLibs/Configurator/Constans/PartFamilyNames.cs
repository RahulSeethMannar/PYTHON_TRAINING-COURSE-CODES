﻿namespace A350F_CommonLibs.Configurator.Constants
{
    public static class PartFamilyNames
    {
        public const string Crossbeam = "Crossbeam";

        public const string CargoRail = "CargoRail";
        public const string SingleCargoRail = "SingleCargoRail";
        public const string DoubleCargoRail = "DoubleCargoRail";

        public const string RollerTracks = "RollerTracks";

        public const string ShearPlate = "ShearPlate";
        public const string InnerShearPlate = "InnerShearPlate";
        public const string OuterShearPlate = "OuterShearPlate";

        public const string PduAssembly = "PDU-Assembly";
        public const string ShearWeb = "ShearWeb";
        public const string Seatrail = "Seatrail";

        public const string X_Paddles = "X-Paddles";

        public const string Z_Struts = "Z-Struts";
        public const string X_Frame = "X-Frame";

        public const string UnIdentified = "UnIdentified";
    }
}
