﻿using MECMOD;
using System.Linq;

namespace A350F_CommonLibs.Configurator.Models
{
    public class Point2d
    {
        public Point2D ActualPoint { get; internal set; } = null;
        public double X { get; internal set; } = 0;
        public double Y { get; internal set; } = 0;
        public double[] Position { get; internal set; } = new double[0];

        public Point2d(Point2D point2D)
        {
            ActualPoint = point2D;
            object[] arrPtCoordinates = new object[2];
            point2D?.GetCoordinates(arrPtCoordinates);
            SetPosition(arrPtCoordinates);
        }

        public Point2d(double[] arrPosition)
        {
            ActualPoint = null;
            SetPosition(arrPosition);
        }

        private void SetPosition(object[] arrPosition)
        {
            SetPosition(arrPosition?.Cast<double>()?.ToArray());
        }
        private void SetPosition(double[] arrPosition)
        {
            Position = arrPosition;
            SetPosition(arrPosition[0], arrPosition[1]);
        }
        private void SetPosition(double x, double y)
        {
            X = x;
            Y = y;
        }

    }
}
