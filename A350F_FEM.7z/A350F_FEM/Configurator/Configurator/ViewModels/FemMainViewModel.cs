﻿using System.Windows.Input;

using A350F_CommonLibs.ViewModels;

using Configurator.Commands;
using Configurator.Stores;

namespace Configurator.ViewModels
{
    public class FemMainViewModel : MainViewModelBase
    {

        private FemNavigationStore _nagivationStore;
        public ICommand BackToLoginCommand { get; }

        public FemMainViewModel()
            : base("UserManualUrlFem")
        {
            SubApplicationName = " - Stress V3";
            SubApplicationImage = "pack://application:,,,/A350F_CommonLibs;component/Resources/Images/StressFem.png";
            _nagivationStore = new FemNavigationStore();
            NavigationStore = _nagivationStore;
            DisplayName = UserProfile.UserName;
            BackToLoginCommand = new FemNavigateLoginCommand(_nagivationStore);
        }
    }
}
