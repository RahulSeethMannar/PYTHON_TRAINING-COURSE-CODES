﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using INFITF;

using MECMOD;

using NavigatorTypeLib;

using ProductStructureTypeLib;

using Serilog;

using SPATypeLib;

using static A350F_CommonLibs.CatiaUtils.CatiaIpvUtils;

namespace A350F_CommonLibs.CatiaUtils
{
    public class CatiaImageAnnotationUtils
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="secondaryProd">A product to set transparent, image will be reframed on this if reframeOnBodyIfNeeded is null</param>
        /// <param name="secondBody">A part body to set transparent</param>
        /// <param name="reframeOnBodyIfNeeded">Used for reframe on to center the error image if needed</param>
        /// <param name="bodyForText">The object for placing annotation text, could only be Product or Reference of Part Body</param>
        /// <param name="ipPartNumber">used to create the subfolder and image file name</param>
        /// <param name="type">A part of the error image file name</param>
        /// <param name="annotationText">The error text to be shown</param>
        /// <returns>The folder location where the error images are creaetd</returns>
        public static string CaptureAnnotatedView(Body primBody, Body secondBody, Body cubeBody, AnyObject reframeOnBodyIfNeeded , AnyObject bodyForText, 
            string ipPartNumber, string type, string annotationText, IpvCheckProperty property) //HybridBody centerPtHbBody
        {
            Viewer3D currentViewer = (Viewer3D)CatiaCommonUtils.GetCatia().ActiveWindow.ActiveViewer;
            Viewpoint3D viewPoint = currentViewer.Viewpoint3D;

            Object[] origin = new Object[3];
            Object[] sideDir = new Object[3];
            Object[] upDir = new Object[3];
            viewPoint.GetOrigin(origin);
            viewPoint.GetSightDirection(sideDir);
            viewPoint.GetUpDirection(upDir);
            double near = currentViewer.NearLimit;
            double far = currentViewer.FarLimit;
            CatClippingMode clippingMode = currentViewer.ClippingMode;
            double focusDist = viewPoint.FocusDistance;
            currentViewer.ClippingMode = CatClippingMode.catClippingModeClear;

            // pass object to set transparency
            selectToTransperent(primBody);
            if (secondBody is null)
            {
                selectToTransperent(property.TempDatumProduct);
            }
            else
            {
                selectToTransperent(secondBody);
            }
            selectToTransperent(cubeBody);
            selectToTransperent(reframeOnBodyIfNeeded);
            //string drumPartNumber = drumPart.get_Name();
            //CatiaProdUtils.SelectAndReframeWithPartNumber(drumPartNumber);
            string imageFolder;
            string imagePath;
            CaptureErrorImage(ipPartNumber, type, out imageFolder, out imagePath);
            PrintErrorMessageOnImage(imagePath, annotationText);
            AddAnnotationText(bodyForText, annotationText);

            property.ErrorImageLocalPath.Add(imagePath);

            currentViewer.Viewpoint3D = viewPoint;
            viewPoint.PutOrigin(origin);
            viewPoint.PutSightDirection(sideDir);
            viewPoint.PutUpDirection(upDir);
            viewPoint.FocusDistance = focusDist;
            try
            {
                currentViewer.NearLimit = near;
            }
            catch
            {

            }
            try
            {
                currentViewer.FarLimit = far;
            }
            catch
            {

            }

            currentViewer.ClippingMode = clippingMode;
            currentViewer.Update();

            return imageFolder;
        }

        public static void selectToTransperent(AnyObject oBody, bool isReframeOn = true)
        {
            if (oBody is null)
            {
                return;
            }
            Document Doc = CatiaCommonUtils.GetActiveDoc();
            Selection sel = Doc.Selection;
            sel.Add((AnyObject)oBody);
            //object[] filter = { "Body" };
            //sel.SelectElement2(filter, "Please select the part need to be transparent", false);
            if (isReframeOn)
            {
                Application catiaInst = CatiaCommonUtils.GetCatia();
                catiaInst.StartCommand("Reframe On");
            }
            //catiaInst.StartCommand("Center Graph");
            sel.VisProperties.SetVisibleOpacity(220, 1);
            sel.Clear();
        }

        public static void CaptureErrorImage(string ipPartNumber, string type, out string imageFolder, out string imagePath)
        {
            // Generate a unique file name
            //string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string localAppDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string dateString = DateTime.Now.ToString("yyyyMMddhhmmss");
            imageFolder = Path.Combine(localAppDataPath, "RainbowFloorGrid", "Images", ipPartNumber);
            imagePath = Path.Combine(imageFolder, $"ErrorImage_{ipPartNumber}_{type}_{dateString}.jpg");
            Application catiaInst = CatiaCommonUtils.GetCatia();
            SpecsAndGeomWindow activeWindow = (SpecsAndGeomWindow)catiaInst.ActiveWindow;
            Viewer3D viewer3D1 = (Viewer3D)activeWindow.ActiveViewer;
            // Hide the specification tree using the SpecsAndGeomWindow
            activeWindow.Layout = CatSpecsAndGeomWindowLayout.catWindowGeomOnly;

            //Viewer3D viewer3D1 = (Viewer3D)activeWindow.ActiveViewer;
            //Viewpoint3D viewpoint3D1 = viewer3D1.Viewpoint3D;
            //viewpoint3D1.ProjectionMode = INFITF.CatProjectionMode.catProjectionConic;
            ProductDocument activeProductDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            Marker3Ds oMarker = (Marker3Ds)activeProductDoc.Product.GetTechnologicalObject("Marker3Ds");
            Document Doc = CatiaCommonUtils.GetActiveDoc();
            Selection sel = Doc.Selection;
            //object[] filter = { "Body" };
            //sel.SelectElement2(filter, "Please select the part need to be transparent", false);
            foreach (Marker3D m in oMarker)
            {
                sel.Clear();
                var visProp = sel.VisProperties;
                sel.Add(m);
                visProp.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            }
            sel.Clear();

            // Try to zoom out the view to get a better view
            Viewer3D viewerorig = (Viewer3D)catiaInst.ActiveWindow.ActiveViewer;
            if (type.ToLower().Contains("notinair") || type.ToLower().Contains("wd"))
            {
                viewerorig.ZoomOut();
                viewerorig.ZoomOut();
            }

            viewerorig.ZoomOut();
            viewerorig.ZoomOut();

            catiaInst.StartCommand("Multi-View");
            Viewer3D viewer = (Viewer3D)catiaInst.ActiveWindow.ActiveViewer;
            Directory.CreateDirectory(imageFolder);
            viewer.CaptureToFile(CatCaptureFormat.catCaptureFormatJPEG, imagePath);

            // Switch to single view
            catiaInst.StartCommand("Multi-View");
            catiaInst.StartCommand("* iso");
            activeWindow.Layout = CatSpecsAndGeomWindowLayout.catWindowSpecsAndGeom;


            Viewer3D viewer1 = (Viewer3D)catiaInst.ActiveWindow.ActiveViewer;
            activeWindow.ActiveViewer.Update();
            //viewer3D1.Reframe();

            //Window myWindow = catiaInst.ActiveWindow;
            //var viewers = myWindow.Viewers;
            //var firstViewer = viewers.Item(1);
            //firstViewer.Activate();            
        }

        private static void PrintErrorMessageOnImage(string imagePath, string errorMsg)
        {
            // Load the captured image and add Error message
            Image image;
            using (FileStream fs = new FileStream(imagePath, FileMode.Open))
            {
                image = Image.FromStream(fs);
                using (Graphics graphics = Graphics.FromImage(image))
                {
                    // Add text to the image
                    using (Font font = new Font("Arial", 25, FontStyle.Bold))
                    {
                        using (Brush brush = new SolidBrush(Color.Red))
                        {
                            float maxTextWidth = image.Width - 20; // Maximum allowed width for the text

                            // Adjust the font size if the text exceeds the available width
                            float fontSize = font.Size;
                            while (graphics.MeasureString(errorMsg, new Font(font.FontFamily, fontSize)).Width > maxTextWidth)
                            {
                                fontSize -= 1;
                                if (fontSize <= 0)
                                {
                                    // The text cannot fit within the available width even with the smallest font size
                                    // Handle this case as desired (e.g., truncate the text or display an error)
                                    break;
                                }
                            }

                            // Calculate the position to keep the text within the image
                            float x = 10;
                            float y = 10;
                            if (x + maxTextWidth > image.Width)
                                x = image.Width - maxTextWidth;
                            if (y + fontSize > image.Height)
                                y = image.Height - fontSize;

                            // Draw the scaled text within the image
                            graphics.DrawString(errorMsg, new Font(font.FontFamily, fontSize), brush, new PointF(x, y));
                        }
                    }
                }
                fs.Close();
            }
            image.Save(imagePath, System.Drawing.Imaging.ImageFormat.Jpeg);

        }

        public static void AddAnnotationText(AnyObject textHoverBody, string errorMsg)
        {
            ProductDocument activeProductDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();

            // get cog to put annotation text
            SPAWorkbench SPAWkBnch = (SPAWorkbench)activeProductDoc.GetWorkbench("SPAWorkbench");

            object[] annotationPosition = new object[3];
             if (textHoverBody is Product)
            {
                Product prodForText = (Product)textHoverBody;
                Inertia inertia = (Inertia)prodForText.GetTechnologicalObject("Inertia");
                object[] myCoord = new object[3];
                inertia.GetCOGPosition(myCoord);

                annotationPosition[0] = (double)myCoord[0] * 1000;
                annotationPosition[1] = (double)myCoord[1] * 1000;
                annotationPosition[2] = (double)myCoord[2] * 1000;
            }
            else if (textHoverBody is Reference)
            {
                Measurable oMeasurable = SPAWkBnch.GetMeasurable((Reference)textHoverBody);
                try
                {
                    oMeasurable.GetCOG(annotationPosition);
                }
                catch
                {
                    try
                    {
                        oMeasurable.GetCenter(annotationPosition);
                    }
                    catch
                    {
                        try
                        {
                            oMeasurable.GetPoint(annotationPosition);
                        }
                        catch
                        {
                            object[] axisSystem = new object[12];
                            oMeasurable.GetAxisSystem(axisSystem);
                            annotationPosition[0] = axisSystem[0];
                            annotationPosition[1] = axisSystem[1];
                            annotationPosition[2] = axisSystem[2];
                        }
                    }
                }
            }
            else
            {
                Log.Error("Annotation Createion: Error by calculating the position for the annotation text.");
                return;
            }

            // get point coordinated to put annotation text
            /*Point mesPoint = centerPtHbBody.HybridShapes.Item(2) as Point;
            object[] annotationPosition = new object[3];
            mesPoint.GetCoordinates(annotationPosition);*/

            //text wrap needed for longer text messages
            string wrappedText = GetWrapedText(errorMsg);

            //ProductDocument activeProductDoc = (ProductDocument)CatiaCommonUtils.GetActiveDoc();
            Marker3Ds oMarker = (Marker3Ds)activeProductDoc.Product.GetTechnologicalObject("Marker3Ds");
            Application catiaInst = CatiaCommonUtils.GetCatia();
            Document Doc = CatiaCommonUtils.GetActiveDoc();
            Selection sel = Doc.Selection;
            //object[] filter = { "Body" };
            //sel.SelectElement2(filter, "Please select the part need to be transparent", false);
            foreach (Marker3D m in oMarker)
            {
                sel.Clear();
                var visProp = sel.VisProperties;
                sel.Add(m);
                visProp.SetShow(CatVisPropertyShow.catVisPropertyShowAttr);
            }
            Marker3D oMarker3D = oMarker.Add3DText(annotationPosition, wrappedText, annotationPosition, activeProductDoc.Product);
            //oMarker3D.set_Name(errorMsg); //name to be changed later  
            oMarker3D.TextSize = 5;
            sel.Clear();
        }

        private static string GetWrapedText(string inputString)
        {
            int maxLength = 35; // Maximum length of each line

            string[] words = inputString.Split(' '); // Split the input string into words

            StringBuilder result = new StringBuilder();

            int lineLength = 0;
            foreach (string word in words)
            {
                if (lineLength + word.Length + 1 > maxLength) // If adding the word exceeds the maximum length
                {
                    result.AppendLine(); // Start a new line
                    lineLength = 0;
                }

                result.Append(word + " "); // Add the word to the result string
                lineLength += word.Length + 1; // Update the line length
            }

            string output = result.ToString().Trim();
            return output;
        }
    }
}
