﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A350F_CommonLibs.Models
{
    public class UserProfile
    {
        public string UserProfileId { get; set; } = "00000000-0000-0000-0000-000000000000";
        public string UserProfileName { get; set; } = "";
        public string UserName { get; set; } = "";
        public string Role { get; set; } = "";
        public string Scope { get; set; } = "";
        public string SearchProfileId { get; set; } = "";
    }
}
