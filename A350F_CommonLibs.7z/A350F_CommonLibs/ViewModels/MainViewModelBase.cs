﻿using System.Windows.Input;

using A350F_CommonLibs.Commands;
using A350F_CommonLibs.Models;

namespace A350F_CommonLibs.ViewModels
{
    /// <summary>
    /// Base class for all main view models
    /// </summary>
    public class MainViewModelBase : ViewModelBase
    {
        private string _subApplicationName;
        private string _subApplicationImage;
        private string _displayName;
        public static UserProfile UserProfile { get; set; }

        public ICommand ExitProgramCommand { get; }
        public ICommand OpenUserManualCommand { get; }

        public string UserManualUrlKey { get; internal set; }
        public string UserManualUrlKey2dCreation { get; internal set; }
        public string UserManualUrlKey2dCheck { get; internal set; }
        public string UserManualUrlKey2dConfigurator { get; internal set; }
        public bool IsUserManual2D { get; internal set; }
        public bool IsUserManualGeneral { get; internal set; }

        public string SubApplicationName
        {
            get
            {
                return _subApplicationName;
            }
            set
            {
                _subApplicationName = value;
                OnPropertyChanged(nameof(SubApplicationName));
            }
        }
        public string SubApplicationImage
        {
            get
            {
                return _subApplicationImage;
            }
            set
            {
                _subApplicationImage = value;
                OnPropertyChanged(nameof(SubApplicationImage));
            }
        }

        public MainViewModelBase(string userManualUrlKey)
        {
            UserManualUrlKey = userManualUrlKey;
            UserManualUrlKey2dCheck = "UserManualUrl2dCheck";
            UserManualUrlKey2dCreation = "UserManualUrl2dCreation";
            UserManualUrlKey2dConfigurator = "UserManualUrl2dConfigurator";

            //if (!string.IsNullOrWhiteSpace(userManualUrlKey) && userManualUrlKey.StartsWith("UserManualUrl2d"))
            //{
            IsUserManual2D = false;
            IsUserManualGeneral = true;
            //}
            //else
            //{
            //    IsUserManual2D = false;
            //    IsUserManualGeneral = true;
            //}

            ExitProgramCommand = new ExitProgramCommand();
            OpenUserManualCommand = new OpenUserManualCommand();
        }

        public string DisplayName
        {
            get
            {
                return _displayName;
            }
            set
            {
                _displayName = value;
                OnPropertyChanged(nameof(DisplayName));
            }
        }
    }
}
