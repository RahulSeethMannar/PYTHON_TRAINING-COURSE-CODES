﻿
using System.Windows;

using Serilog;

namespace A350F_CommonLibs.Dialogs
{
    public class BaseDialog : IDialog
    {
        public virtual MessageBoxResult ShowInfoMessageBox(string message)
        {
            Log.Information(message);
            return MessageBox.Show(message, "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        public virtual MessageBoxResult ShowInfoMessageBoxYesNo(string message)
        {
            Log.Information(message);
            return MessageBox.Show(message, "Info", MessageBoxButton.YesNo, MessageBoxImage.Information);
        }

        public virtual MessageBoxResult ShowErrorMessageBox(string message)
        {
            Log.Information(message);
            return MessageBox.Show(message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
